package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseUser
import com.example.data.model.Comment
import com.example.data.model.CreatorLevel
import com.example.data.model.CreatorMonetizationState
import com.example.data.model.AppLanguage
import com.example.data.model.BlockedUser
import com.example.data.model.NotificationPreferences
import com.example.data.model.PrivacySettings
import com.example.data.model.NotificationItem
import com.example.data.model.NotificationType
import com.example.data.model.Post
import com.example.data.model.Story
import com.example.data.model.UserProfile
import com.example.data.model.Video
import com.example.data.model.WithdrawalMethod
import com.example.data.repository.VidBookRepository
import com.example.copyright.model.CopyrightScanEvidence
import com.example.copyright.model.CopyrightStatus
import com.example.copyright.model.CopyrightNotice
import com.example.copyright.model.UserCopyrightStatus
import com.example.ui.screens.ChannelInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ScreenTab {
    HOME,
    VIDEOS,
    REELS,
    NOTIFICATIONS,
    PROFILE
}

enum class FeedPreference(val titleBn: String, val titleEn: String) {
    ALL("সব পোস্ট", "All Posts"),
    VIDEOS_ONLY("শুধু ভিডিও", "Videos Only"),
    FRIENDS_ONLY("শুধু বন্ধুদের পোস্ট", "Friends' Posts Only");

    val title: String get() = titleBn
    fun getTitle(lang: AppLanguage) = if (lang == AppLanguage.BN) titleBn else titleEn
}

class VidBookViewModel(application: Application) : AndroidViewModel(application) {

    val repository = VidBookRepository(application)
    val authManager get() = repository.authManager

    // App Navigation State
    private val _currentTab = MutableStateFlow(ScreenTab.HOME)
    val currentTab: StateFlow<ScreenTab> = _currentTab.asStateFlow()

    // Feed Preferences (All posts, Only videos, Only friends' posts)
    private val _feedPreference = MutableStateFlow(FeedPreference.ALL)
    val feedPreference: StateFlow<FeedPreference> = _feedPreference.asStateFlow()

    fun setFeedPreference(pref: FeedPreference) {
        _feedPreference.value = pref
        showSnackbar("ফিড প্রেফারেন্স: ${pref.title} সেট করা হয়েছে")
    }

    // Notifications Setting
    private val _notificationsEnabled = MutableStateFlow(true)
    val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled.asStateFlow()

    fun setNotificationsEnabled(enabled: Boolean) {
        _notificationsEnabled.value = enabled
        showSnackbar(if (enabled) "🔔 নোটিফিকেশন চালু করা হয়েছে" else "🔕 নোটিফিকেশন বন্ধ করা হয়েছে")
    }

    fun toggleNotificationsEnabled() {
        setNotificationsEnabled(!_notificationsEnabled.value)
    }

    // ==========================================
    // 7 Real VidBook Settings States & Functions
    // ==========================================

    // 1. Privacy Settings
    private val _privacySettings = MutableStateFlow(repository.getPrivacySettings())
    val privacySettings: StateFlow<PrivacySettings> = _privacySettings.asStateFlow()

    fun updatePrivacySettings(settings: PrivacySettings) {
        viewModelScope.launch {
            repository.savePrivacySettings(settings)
            _privacySettings.value = settings
            showSnackbar("প্রাইভেসি সেটিংস Firestore-এ সেভ হয়েছে")
        }
    }

    // 2. Language Change (Bangla / English)
    private val _appLanguage = MutableStateFlow(repository.getAppLanguage())
    val appLanguage: StateFlow<AppLanguage> = _appLanguage.asStateFlow()

    fun setAppLanguage(lang: AppLanguage) {
        repository.saveAppLanguage(lang)
        _appLanguage.value = lang
        showSnackbar(if (lang == AppLanguage.BN) "অ্যাপের ভাষা 'বাংলা' করা হয়েছে" else "App language set to English")
    }

    // 3. Data Saver Mode
    private val _isDataSaverEnabled = MutableStateFlow(repository.getDataSaverMode())
    val isDataSaverEnabled: StateFlow<Boolean> = _isDataSaverEnabled.asStateFlow()

    fun setDataSaverEnabled(enabled: Boolean) {
        repository.saveDataSaverMode(enabled)
        _isDataSaverEnabled.value = enabled
        showSnackbar(if (enabled) "ডেটা সেভার মোড চালু: ভিডিও কম কোয়ালিটি ও ছবি কম সাইজে লোড হবে" else "ডেটা সেভার মোড বন্ধ")
    }

    // 4. Block List
    private val _blockedUsers = MutableStateFlow(repository.getBlockedUsers())
    val blockedUsers: StateFlow<List<BlockedUser>> = _blockedUsers.asStateFlow()

    fun blockUser(user: BlockedUser) {
        viewModelScope.launch {
            repository.blockUser(user)
            _blockedUsers.value = repository.getBlockedUsers()
            showSnackbar("${user.name} কে ব্লক করা হয়েছে (ফিডে আর দেখা যাবে না)")
        }
    }

    fun unblockUser(userId: String) {
        viewModelScope.launch {
            repository.unblockUser(userId)
            _blockedUsers.value = repository.getBlockedUsers()
            showSnackbar("ইউজারকে আনব্লক করা হয়েছে")
        }
    }

    // 5. Notification Customization Preferences
    private val _notificationPreferences = MutableStateFlow(repository.getNotificationPreferences())
    val notificationPreferences: StateFlow<NotificationPreferences> = _notificationPreferences.asStateFlow()

    fun updateNotificationPreferences(prefs: NotificationPreferences) {
        repository.saveNotificationPreferences(prefs)
        _notificationPreferences.value = prefs
        showSnackbar("নোটিফিকেশন প্রেফারেন্স সেভ হয়েছে")
    }

    // 6. Cache Calculation & Clean
    private val _appCacheSizeBytes = MutableStateFlow(repository.getAppCacheSize())
    val appCacheSizeBytes: StateFlow<Long> = _appCacheSizeBytes.asStateFlow()

    fun refreshCacheSize() {
        _appCacheSizeBytes.value = repository.getAppCacheSize()
    }

    fun clearAppCache() {
        val freed = repository.clearAppCache()
        _appCacheSizeBytes.value = 0L
        showSnackbar("Cache পরিষ্কার হয়েছে")
    }

    // 7. Delete Account
    fun deleteAccount(onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            val res = repository.deleteAccount()
            if (res.isSuccess) {
                _isSettingsScreenOpen.value = false
                _isMonetizationScreenOpen.value = false
                _isCopyrightNoticeScreenOpen.value = false
                _activePlayingVideo.value = null
                _activeChannelId.value = null
                _activeViewingPost.value = null
                tabBackStack.clear()
                _currentTab.value = ScreenTab.HOME
                showSnackbar("আপনার অ্যাকাউন্ট এবং সমস্ত ডেটা সফলভাবে মুছে ফেলা হয়েছে")
                onComplete()
            } else {
                showSnackbar("অ্যাকাউন্ট মোছা যায়নি: ${res.exceptionOrNull()?.message}")
            }
        }
    }

    // Settings Screen Visibility
    private val _isSettingsScreenOpen = MutableStateFlow(false)
    val isSettingsScreenOpen: StateFlow<Boolean> = _isSettingsScreenOpen.asStateFlow()

    fun setSettingsScreenOpen(open: Boolean) {
        _isSettingsScreenOpen.value = open
        if (open) refreshCacheSize()
    }

    // Dark Mode Toggle
    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    // Search & Filter State
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("সবগুলো")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    // Active Video Player State
    private val _activePlayingVideo = MutableStateFlow<Video?>(null)
    val activePlayingVideo: StateFlow<Video?> = _activePlayingVideo.asStateFlow()

    // Active Story Viewer State
    private val _viewingStory = MutableStateFlow<Story?>(null)
    val viewingStory: StateFlow<Story?> = _viewingStory.asStateFlow()

    // Active Comments Target (Post or Video)
    private val _activeCommentsTarget = MutableStateFlow<Pair<String, String>?>(null) // Pair(id, title)
    val activeCommentsTarget: StateFlow<Pair<String, String>?> = _activeCommentsTarget.asStateFlow()

    private val _activeCommentsList = MutableStateFlow<List<Comment>>(emptyList())
    val activeCommentsList: StateFlow<List<Comment>> = _activeCommentsList.asStateFlow()

    // Pre-Upload Copyright Scanning State
    private val _isScanningCopyright = MutableStateFlow(false)
    val isScanningCopyright: StateFlow<Boolean> = _isScanningCopyright.asStateFlow()

    private val _scanProgress = MutableStateFlow(0f)
    val scanProgress: StateFlow<Float> = _scanProgress.asStateFlow()

    private val _scanStage = MutableStateFlow("Checking video rights and duplicate content...")
    val scanStage: StateFlow<String> = _scanStage.asStateFlow()

    private val _copyrightEvidence = MutableStateFlow<CopyrightScanEvidence?>(null)
    val copyrightEvidence: StateFlow<CopyrightScanEvidence?> = _copyrightEvidence.asStateFlow()

    // Dialogs State
    private val _isUploadDialogOpen = MutableStateFlow(false)
    val isUploadDialogOpen: StateFlow<Boolean> = _isUploadDialogOpen.asStateFlow()

    private val _isAuthDialogOpen = MutableStateFlow(false)
    val isAuthDialogOpen: StateFlow<Boolean> = _isAuthDialogOpen.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    // StreamVault Server Configuration
    private val _streamVaultBaseUrl = MutableStateFlow(repository.getStreamVaultBaseUrl())
    val streamVaultBaseUrl: StateFlow<String> = _streamVaultBaseUrl.asStateFlow()

    fun updateStreamVaultUrl(newUrl: String) {
        val trimmed = newUrl.trim()
        val finalUrl = if (trimmed.endsWith("/")) trimmed else "$trimmed/"
        repository.updateStreamVaultBaseUrl(finalUrl)
        _streamVaultBaseUrl.value = repository.getStreamVaultBaseUrl()
        showSnackbar("StreamVault সার্ভার IP সফলভাবে সেভ করা হয়েছে!")
    }

    // User Profile
    val currentUser: StateFlow<UserProfile?> = repository.authManager.currentUserState

    // Feeds from Repository
    val stories: StateFlow<List<Story>> = repository.activeStories.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val posts: StateFlow<List<Post>> = repository.allPosts.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val filteredPosts: StateFlow<List<Post>> = combine(posts, feedPreference, _blockedUsers) { allPosts, pref, blocked ->
        val blockedIds = blocked.map { it.id }.toSet()
        val unblocked = allPosts.filter { it.authorId !in blockedIds }
        when (pref) {
            FeedPreference.ALL -> unblocked
            FeedPreference.VIDEOS_ONLY -> unblocked.filter { it.videoUrl != null || it.content.contains("ভিডিও") }
            FeedPreference.FRIENDS_ONLY -> unblocked.filter { it.isAuthorVerified || it.likesCount > 0 }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val reels: StateFlow<List<Video>> = combine(repository.shorts, _blockedUsers) { shorts, blocked ->
        val blockedIds = blocked.map { it.id }.toSet()
        shorts.filter { it.channelId !in blockedIds }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val notifications: StateFlow<List<NotificationItem>> = repository.allNotifications.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Copyright Status & Notices (Real 3-Strike System & YouTube-style Notice Center)
    val userCopyrightStatus: StateFlow<UserCopyrightStatus> = repository.userCopyrightStatus.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = UserCopyrightStatus()
    )

    val copyrightNotices: StateFlow<List<CopyrightNotice>> = repository.copyrightNotices.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _isCopyrightNoticeScreenOpen = MutableStateFlow(false)
    val isCopyrightNoticeScreenOpen: StateFlow<Boolean> = _isCopyrightNoticeScreenOpen.asStateFlow()

    fun openCopyrightNoticeScreen() {
        _isCopyrightNoticeScreenOpen.value = true
    }

    fun closeCopyrightNoticeScreen() {
        _isCopyrightNoticeScreenOpen.value = false
    }

    fun submitCopyrightNoticeDispute(noticeId: String, reason: String) {
        viewModelScope.launch {
            repository.submitCopyrightNoticeDispute(noticeId, reason)
            showSnackbar("আপনার আপিল সফলভাবে জমা হয়েছে। পর্যালোচনার ফলাফল শীঘ্রই জানানো হবে।")
        }
    }

    // Monetization System & Level System
    val monetizationState: StateFlow<CreatorMonetizationState> = repository.monetizationState.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = CreatorMonetizationState()
    )

    private val _isMonetizationScreenOpen = MutableStateFlow(false)
    val isMonetizationScreenOpen: StateFlow<Boolean> = _isMonetizationScreenOpen.asStateFlow()

    fun openMonetizationScreen() {
        _isMonetizationScreenOpen.value = true
    }

    fun closeMonetizationScreen() {
        _isMonetizationScreenOpen.value = false
    }

    fun requestWithdrawal(method: WithdrawalMethod, amount: Double, destination: String) {
        viewModelScope.launch {
            val result = repository.requestWithdrawal(method, amount, destination)
            showSnackbar(result.second)
        }
    }

    // Active Post Detail View (Facebook Style navigation from Notifications & Home)
    private val _activeViewingPost = MutableStateFlow<Post?>(null)
    val activeViewingPost: StateFlow<Post?> = _activeViewingPost.asStateFlow()

    fun openPostDetail(post: Post) {
        _activeViewingPost.value = post
    }

    fun closePostDetail() {
        _activeViewingPost.value = null
    }

    fun handleNotificationClick(notification: NotificationItem) {
        viewModelScope.launch {
            repository.markNotificationAsRead(notification.id)
        }

        when (notification.type) {
            NotificationType.LIKE -> {
                // Like notification: Open that post (or video if targetId points to video)
                val targetId = notification.targetId
                val matchedPost = if (!targetId.isNullOrBlank()) posts.value.find { it.id == targetId } else null
                if (matchedPost != null) {
                    openPostDetail(matchedPost)
                } else {
                    val matchedVideo = if (!targetId.isNullOrBlank()) {
                        filteredVideos.value.find { it.id == targetId } ?: reels.value.find { it.id == targetId }
                    } else null
                    if (matchedVideo != null) openVideoDetail(matchedVideo)
                }
            }
            NotificationType.COMMENT -> {
                // Comment notification: Open that post with comments section open
                val targetId = notification.targetId
                val matchedPost = if (!targetId.isNullOrBlank()) posts.value.find { it.id == targetId } else null
                if (matchedPost != null) {
                    openPostDetail(matchedPost)
                    openComments(matchedPost.id, matchedPost.content.take(30))
                } else {
                    val matchedVideo = if (!targetId.isNullOrBlank()) {
                        filteredVideos.value.find { it.id == targetId }
                    } else null
                    if (matchedVideo != null) {
                        openVideoDetail(matchedVideo)
                        openComments(matchedVideo.id, matchedVideo.title)
                    }
                }
            }
            NotificationType.NEW_VIDEO -> {
                // New Video notification: Open that video
                val targetId = notification.targetId
                val matchedVideo = if (!targetId.isNullOrBlank()) {
                    filteredVideos.value.find { it.id == targetId } ?: reels.value.find { it.id == targetId }
                } else null
                if (matchedVideo != null) {
                    openVideoDetail(matchedVideo)
                } else {
                    setTab(ScreenTab.VIDEOS)
                }
            }
            NotificationType.FOLLOW, NotificationType.SUBSCRIBE -> {
                // Follow notification: Open that user's Channel
                val channelId = notification.targetId
                if (!channelId.isNullOrBlank()) {
                    openChannel(channelId)
                }
            }
            NotificationType.SYSTEM -> {
                showSnackbar(notification.message)
            }
            NotificationType.COPYRIGHT -> {
                openCopyrightNoticeScreen()
            }
        }
    }

    // Filtered Video Feed
    val filteredVideos: StateFlow<List<Video>> = combine(
        repository.longVideos,
        _selectedCategory,
        _searchQuery,
        _blockedUsers
    ) { videoList, category, query, blocked ->
        val blockedIds = blocked.map { it.id }.toSet()
        videoList.filter { video ->
            video.channelId !in blockedIds &&
            (category == "সবগুলো" || video.category == category) &&
            (query.isBlank() ||
                video.title.contains(query, ignoreCase = true) ||
                video.channelName.contains(query, ignoreCase = true) ||
                video.description.contains(query, ignoreCase = true))
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // User Actions & Tab Backstack
    private val tabBackStack = mutableListOf<ScreenTab>()

    fun setTab(tab: ScreenTab) {
        if (_currentTab.value != tab) {
            tabBackStack.add(_currentTab.value)
            _currentTab.value = tab
        }
    }

    /**
     * Handles system back press across all screens, dialogs, overlays, and tabs.
     * Returns true if handled internally; returns false if already on Home with nothing open (minimize app).
     */
    fun handleBackPress(): Boolean {
        if (_isSettingsScreenOpen.value) {
            _isSettingsScreenOpen.value = false
            return true
        }
        if (_isAuthDialogOpen.value) {
            _isAuthDialogOpen.value = false
            return true
        }
        if (_isUploadDialogOpen.value) {
            _isUploadDialogOpen.value = false
            return true
        }
        if (_activeViewingPost.value != null) {
            _activeViewingPost.value = null
            return true
        }
        if (_isMonetizationScreenOpen.value) {
            _isMonetizationScreenOpen.value = false
            return true
        }
        if (_isCopyrightNoticeScreenOpen.value) {
            _isCopyrightNoticeScreenOpen.value = false
            return true
        }
        if (_activeCommentsTarget.value != null) {
            _activeCommentsTarget.value = null
            return true
        }
        if (_viewingStory.value != null) {
            _viewingStory.value = null
            return true
        }
        if (_activeChannelId.value != null) {
            _activeChannelId.value = null
            return true
        }
        if (_activePlayingVideo.value != null) {
            _activePlayingVideo.value = null
            return true
        }
        while (tabBackStack.isNotEmpty()) {
            val previousTab = tabBackStack.removeAt(tabBackStack.lastIndex)
            if (previousTab != _currentTab.value) {
                _currentTab.value = previousTab
                return true
            }
        }
        if (_currentTab.value != ScreenTab.HOME) {
            _currentTab.value = ScreenTab.HOME
            return true
        }
        return false
    }

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun openVideoDetail(video: Video) {
        _activePlayingVideo.value = video
        incrementViewCount(video.id)
    }

    fun incrementViewCount(videoId: String) {
        // Immediate UI update for the active video
        _activePlayingVideo.value = _activePlayingVideo.value?.let {
            if (it.id == videoId) it.copy(viewsCount = it.viewsCount + 1) else it
        }

        viewModelScope.launch {
            repository.incrementViews(videoId)
        }
    }

    fun closeVideoDetail() {
        _activePlayingVideo.value = null
    }

    // Active Channel Screen Navigation
    private val _activeChannelId = MutableStateFlow<String?>(null)
    val activeChannelId: StateFlow<String?> = _activeChannelId.asStateFlow()

    fun openChannel(channelId: String) {
        _activeChannelId.value = channelId
    }

    fun closeChannel() {
        _activeChannelId.value = null
    }

    fun getChannelInfo(channelId: String): ChannelInfo {
        val allVids = filteredVideos.value
        val matchingVideo = allVids.find { it.channelId == channelId }
        val matchingPost = posts.value.find { it.authorId == channelId }
        val isSub = matchingVideo?.isSubscribed ?: false
        val current = currentUser.value

        val isMyChannel = (channelId == current?.id && !current?.id.isNullOrBlank())

        val name = when {
            isMyChannel -> current?.name?.takeIf { it.isNotBlank() } ?: "আমার চ্যানেল"
            matchingVideo != null -> matchingVideo.channelName
            matchingPost != null -> matchingPost.authorName
            else -> "ক্রিয়েটর চ্যানেল"
        }

        val avatar = when {
            isMyChannel -> current?.avatarUrl ?: ""
            matchingVideo != null -> matchingVideo.channelAvatar
            matchingPost != null -> matchingPost.authorAvatar
            else -> ""
        }

        val cover = when {
            isMyChannel -> current?.coverUrl ?: ""
            else -> ""
        }

        return ChannelInfo(
            id = channelId,
            name = name,
            avatarUrl = avatar,
            coverUrl = cover,
            isVerified = if (isMyChannel) (current?.isVerified ?: false) else (matchingVideo?.isChannelVerified ?: false),
            subscribersCount = if (isMyChannel) (current?.subscribersCount ?: 0) else (matchingVideo?.viewsCount?.toInt() ?: 0),
            isSubscribed = isSub
        )
    }

    fun getVideosForChannel(channelId: String): List<Video> {
        val allVids = filteredVideos.value
        val directMatches = allVids.filter { it.channelId == channelId }
        if (directMatches.isNotEmpty()) return directMatches

        return if (channelId == "ch_natok") {
            allVids.filter { it.category == "নাটক" }
        } else {
            allVids.take(4)
        }
    }

    fun openStory(story: Story) {
        _viewingStory.value = story
        viewModelScope.launch {
            repository.markStorySeen(story.id)
        }
    }

    fun closeStory() {
        _viewingStory.value = null
    }

    fun openComments(targetId: String, title: String) {
        _activeCommentsTarget.value = Pair(targetId, title)
        viewModelScope.launch {
            repository.getCommentsForTarget(targetId).collect { comments ->
                _activeCommentsList.value = comments
            }
        }
    }

    fun closeComments() {
        _activeCommentsTarget.value = null
    }

    fun setUploadDialogOpen(open: Boolean) {
        _isUploadDialogOpen.value = open
    }

    fun setAuthDialogOpen(open: Boolean) {
        _isAuthDialogOpen.value = open
    }

    fun showSnackbar(msg: String) {
        _snackbarMessage.value = msg
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    // Interaction Handlers
    fun togglePostLike(post: Post) {
        viewModelScope.launch {
            repository.togglePostLike(post.id, post.isLiked, post.likesCount)
        }
    }

    fun toggleVideoLike(video: Video) {
        viewModelScope.launch {
            repository.toggleVideoLike(video.id, video.isLiked, video.likesCount)
            _activePlayingVideo.value = _activePlayingVideo.value?.let {
                if (it.id == video.id) it.copy(isLiked = !video.isLiked, likesCount = if (!video.isLiked) video.likesCount + 1 else video.likesCount - 1) else it
            }
        }
    }

    fun toggleChannelSubscribe(channelId: String, currentSubscribed: Boolean) {
        viewModelScope.launch {
            repository.toggleSubscription(channelId, currentSubscribed)
            _activePlayingVideo.value = _activePlayingVideo.value?.let {
                if (it.channelId == channelId) it.copy(isSubscribed = !currentSubscribed) else it
            }
            showSnackbar(if (!currentSubscribed) "চ্যানেল সাবস্ক্রাইব করা হয়েছে!" else "আনসাবস্ক্রাইব করা হয়েছে")
        }
    }

    // Follow State Tracking: Set of followed user IDs and real-time follower counts
    private val _followedUserIds = MutableStateFlow<Set<String>>(emptySet())
    val followedUserIds: StateFlow<Set<String>> = _followedUserIds.asStateFlow()

    private val _userFollowersCountMap = MutableStateFlow<Map<String, Int>>(emptyMap())
    val userFollowersCountMap: StateFlow<Map<String, Int>> = _userFollowersCountMap.asStateFlow()

    /**
     * Toggles follow status for a user.
     * Follow: follower count +1, Unfollow: follower count -1.
     * Updates Firebase Firestore and updates UI immediately.
     */
    fun toggleFollow(userId: String) {
        val isCurrentlyFollowing = _followedUserIds.value.contains(userId)
        val newFollowState = !isCurrentlyFollowing
        val delta = if (newFollowState) 1 else -1

        // Update followed users set immediately
        _followedUserIds.value = if (newFollowState) {
            _followedUserIds.value + userId
        } else {
            _followedUserIds.value - userId
        }

        // Update follower count map immediately for UI
        val currentCount = _userFollowersCountMap.value[userId]
            ?: currentUser.value?.takeIf { it.id == userId }?.followersCount
            ?: 0
        val updatedCount = (currentCount + delta).coerceAtLeast(0)
        _userFollowersCountMap.value = _userFollowersCountMap.value + (userId to updatedCount)

        viewModelScope.launch {
            repository.toggleFollow(userId, isCurrentlyFollowing)
            showSnackbar(if (newFollowState) "ইউজারকে ফলো করা হয়েছে (+১ ফলোয়ার)" else "আনফলো করা হয়েছে (-১ ফলোয়ার)")
        }
    }

    fun createPost(content: String, imageUri: String?) {
        viewModelScope.launch {
            repository.createPost(content, imageUri)
            _activePlayingVideo.value = null
            _searchQuery.value = ""
            _currentTab.value = ScreenTab.HOME
            showSnackbar("পোস্ট সফলভাবে প্রকাশিত হয়েছে!")
            setUploadDialogOpen(false)
        }
    }

    fun uploadVideo(
        title: String,
        description: String,
        category: String,
        videoUri: String,
        thumbnailUri: String,
        isShort: Boolean
    ) {
        viewModelScope.launch {
            repository.uploadVideo(title, description, category, videoUri, thumbnailUri, isShort)
            _activePlayingVideo.value = null
            _searchQuery.value = ""
            _selectedCategory.value = "সবগুলো"
            if (isShort) {
                _currentTab.value = ScreenTab.REELS
            } else {
                _currentTab.value = ScreenTab.VIDEOS
            }
            showSnackbar(if (isShort) "শর্ট ভিডিও আপলোড সম্পন্ন হয়েছে" else "ভিডিও আপলোড সম্পন্ন হয়েছে")
            clearCopyrightScan()
            setUploadDialogOpen(false)
        }
    }

    suspend fun performPreUploadCopyrightScan(videoUri: String, videoTitle: String): CopyrightScanEvidence {
        _isScanningCopyright.value = true
        _scanProgress.value = 0.05f
        _scanStage.value = "যাচাইকরণ হচ্ছে..."
        _copyrightEvidence.value = null

        val result = repository.scanCandidateVideo(
            videoUriOrPath = videoUri,
            videoTitle = videoTitle.ifBlank { "Unspecified Candidate Title" },
            onProgress = { stage, progress ->
                _scanStage.value = stage
                _scanProgress.value = progress
            }
        )

        _copyrightEvidence.value = result
        _isScanningCopyright.value = false
        _scanProgress.value = 1.0f

        return result
    }

    fun scanVideoForCopyright(videoUri: String, videoTitle: String) {
        if (videoUri.isBlank()) return
        viewModelScope.launch {
            performPreUploadCopyrightScan(videoUri, videoTitle)
        }
    }

    fun clearCopyrightScan() {
        _isScanningCopyright.value = false
        _scanProgress.value = 0f
        _scanStage.value = "Checking video rights and duplicate content..."
        _copyrightEvidence.value = null
    }

    fun submitCopyrightDispute(evidence: CopyrightScanEvidence, reason: String) {
        viewModelScope.launch {
            repository.submitDispute(evidence, reason)
            showSnackbar("কপিরাইট আপিল জমা হয়েছে। মডারেশন টিম ২৪ ঘণ্টার মধ্যে পর্যালোচনা করবে।")
        }
    }

    fun addStory(mediaUrl: String, caption: String) {
        viewModelScope.launch {
            repository.addStory(mediaUrl, caption)
            showSnackbar("স্টোরি যোগ করা হয়েছে (২৪ ঘণ্টা থাকবে)")
        }
    }

    fun addComment(text: String) {
        val target = _activeCommentsTarget.value ?: return
        if (text.isBlank()) return
        viewModelScope.launch {
            repository.addComment(target.first, text)
            showSnackbar("মন্তব্য প্রকাশিত হয়েছে")
        }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsAsRead()
            showSnackbar("সকল নোটিফিকেশন পড়া হয়েছে")
        }
    }

    fun onGoogleSignInSuccess(user: FirebaseUser) {
        viewModelScope.launch {
            val profile = repository.createOrUpdateUserProfile(user)
            val name = profile?.name?.takeIf { it.isNotBlank() } ?: user.displayName ?: ""
            showSnackbar("Google দিয়ে সফলভাবে লগইন হয়েছে! স্বাগতম $name")
            setAuthDialogOpen(false)
            _isMonetizationScreenOpen.value = false
            _isCopyrightNoticeScreenOpen.value = false
            _activePlayingVideo.value = null
            _activeChannelId.value = null
            _activeViewingPost.value = null
            tabBackStack.clear()
            _currentTab.value = ScreenTab.HOME
        }
    }

    fun onFirebaseUserSignedIn(user: FirebaseUser?) {
        if (user != null) {
            onGoogleSignInSuccess(user)
        }
    }

    fun logout() {
        repository.authManager.logout()
        showSnackbar("লগআউট সম্পন্ন হয়েছে")
    }

    fun updateProfile(name: String, bio: String) {
        repository.authManager.updateProfile(name, bio)
        showSnackbar("প্রোফাইল আপডেট হয়েছে")
    }

    fun updateFullProfile(
        name: String,
        username: String,
        bio: String,
        avatarUri: String? = null,
        coverUri: String? = null
    ) {
        viewModelScope.launch {
            showSnackbar("প্রোফাইল আপডেট হচ্ছে...")
            repository.updateFullProfile(name, username, bio, avatarUri, coverUri)
            showSnackbar("প্রোফাইল সফলভাবে আপডেট হয়েছে!")
        }
    }

    fun updateAvatarPhoto(avatarUri: String) {
        viewModelScope.launch {
            showSnackbar("প্রোফাইল ছবি আপলোড হচ্ছে...")
            repository.updateAvatarPhoto(avatarUri)
            showSnackbar("প্রোফাইল ছবি সফলভাবে পরিবর্তিত হয়েছে!")
        }
    }

    fun updateCoverPhoto(coverUri: String) {
        viewModelScope.launch {
            showSnackbar("কভার ছবি আপলোড হচ্ছে...")
            repository.updateCoverPhoto(coverUri)
            showSnackbar("কভার ছবি সফলভাবে পরিবর্তিত হয়েছে!")
        }
    }
}
