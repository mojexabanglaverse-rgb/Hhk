package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DataSaverOn
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.PersonRemove
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.example.data.model.AppLanguage
import com.example.data.model.BlockedUser
import com.example.data.model.FollowPermission
import com.example.data.model.NotificationPreferences
import com.example.data.model.PostVisibility
import com.example.data.model.PrivacySettings
import com.example.data.model.ProfileVisibility
import com.example.ui.theme.VidBookBlue
import com.example.ui.theme.VidBookRed
import com.example.ui.util.AppStrings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    privacySettings: PrivacySettings,
    onUpdatePrivacySettings: (PrivacySettings) -> Unit,
    appLanguage: AppLanguage,
    onSetAppLanguage: (AppLanguage) -> Unit,
    isDataSaverEnabled: Boolean,
    onSetDataSaverEnabled: (Boolean) -> Unit,
    blockedUsers: List<BlockedUser>,
    onUnblockUser: (String) -> Unit,
    onBlockUser: (BlockedUser) -> Unit,
    notificationPreferences: NotificationPreferences,
    onUpdateNotificationPreferences: (NotificationPreferences) -> Unit,
    cacheSizeBytes: Long,
    onClearCache: () -> Unit,
    onDeleteAccount: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    var showDeleteAccountDialog by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("settings_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = AppStrings.get(appLanguage, "সেটিংস", "Settings"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 19.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("settings_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = AppStrings.back(appLanguage)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            // 1. 🔒 Privacy Settings
            item {
                PrivacySettingsSection(
                    settings = privacySettings,
                    onUpdateSettings = onUpdatePrivacySettings,
                    appLanguage = appLanguage
                )
            }

            // 2. 🌐 Language Settings
            item {
                LanguageSettingsSection(
                    currentLanguage = appLanguage,
                    onLanguageSelected = onSetAppLanguage
                )
            }

            // 3. 📱 Data Saver Mode
            item {
                DataSaverSection(
                    isEnabled = isDataSaverEnabled,
                    onToggle = onSetDataSaverEnabled,
                    appLanguage = appLanguage
                )
            }

            // 4. 🚫 Block List
            item {
                BlockListSection(
                    blockedUsers = blockedUsers,
                    onUnblockUser = onUnblockUser,
                    appLanguage = appLanguage
                )
            }

            // 5. 🔕 Notification Customization
            item {
                NotificationCustomizationSection(
                    preferences = notificationPreferences,
                    onUpdatePreferences = onUpdateNotificationPreferences,
                    appLanguage = appLanguage
                )
            }

            // 6. 📊 Clear Cache
            item {
                ClearCacheSection(
                    cacheSizeBytes = cacheSizeBytes,
                    onClearCache = onClearCache,
                    appLanguage = appLanguage
                )
            }

            // 7. 🔑 Delete Account
            item {
                DeleteAccountSection(
                    onRequestDelete = { showDeleteAccountDialog = true },
                    appLanguage = appLanguage
                )
            }

            item { Spacer(modifier = Modifier.height(32.dp)) }
        }
    }

    // Delete Account Confirmation Dialog
    if (showDeleteAccountDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAccountDialog = false },
            icon = {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE53935).copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = Color(0xFFE53935),
                        modifier = Modifier.size(28.dp)
                    )
                }
            },
            title = {
                Text(
                    text = AppStrings.get(appLanguage, "অ্যাকাউন্ট স্থায়ীভাবে মুছে ফেলতে চান?", "Permanently delete account?"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Text(
                    text = AppStrings.get(
                        appLanguage,
                        "আপনি কি নিশ্চিত? Firebase Auth ও Firestore থেকে আপনার অ্যাকাউন্ট, পোস্ট, ভিডিও ও সকল ডেটা চিরতরে মুছে যাবে। এই কাজটি আর পূর্বাবস্থায় ফিরিয়ে আনা সম্ভব নয়।",
                        "Are you sure? Your account, posts, videos, and all data will be permanently removed from Firebase Auth and Firestore. This action cannot be undone."
                    ),
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteAccountDialog = false
                        onDeleteAccount()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("confirm_delete_account_btn")
                ) {
                    Text(
                        text = AppStrings.get(appLanguage, "হ্যাঁ, মুছে দিন", "Yes, Delete"),
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showDeleteAccountDialog = false },
                    modifier = Modifier.testTag("cancel_delete_account_btn")
                ) {
                    Text(AppStrings.cancel(appLanguage))
                }
            },
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.testTag("delete_account_dialog")
        )
    }
}

// ==========================================
// 1. 🔒 Privacy Settings Section
// ==========================================
@Composable
private fun PrivacySettingsSection(
    settings: PrivacySettings,
    onUpdateSettings: (PrivacySettings) -> Unit,
    appLanguage: AppLanguage
) {
    var isExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth().testTag("privacy_settings_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(VidBookBlue.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = VidBookBlue,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = AppStrings.privacySettingsTitle(appLanguage),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = AppStrings.get(appLanguage, "পোস্ট, প্রোফাইল ও ফলোয়ার গোপনীয়তা (Firestore সেভ)", "Post, profile & follower privacy (Firestore synced)"),
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = VidBookBlue
                )
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 16.dp)) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(12.dp))

                    // A. আমার পোস্ট কে দেখবে: Public / শুধু ফলোয়ার / শুধু আমি
                    Text(
                        text = AppStrings.get(appLanguage, "আমার পোস্ট কে দেখবে:", "Who can see my posts:"),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = VidBookBlue
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        PostVisibility.values().forEach { option ->
                            val isSelected = settings.postsVisibility == option
                            OutlinedButton(
                                onClick = { onUpdateSettings(settings.copy(postsVisibility = option)) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) VidBookBlue else MaterialTheme.colorScheme.outlineVariant
                                ),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (isSelected) VidBookBlue.copy(alpha = 0.12f) else Color.Transparent
                                )
                            ) {
                                Text(
                                    text = if (appLanguage == AppLanguage.BN) option.titleBn else option.titleEn,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) VidBookBlue else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // B. আমাকে কে ফলো করতে পারবে: সবাই / কেউ না
                    Text(
                        text = AppStrings.get(appLanguage, "আমাকে কে ফলো করতে পারবে:", "Who can follow me:"),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = VidBookBlue
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FollowPermission.values().forEach { option ->
                            val isSelected = settings.whoCanFollowMe == option
                            OutlinedButton(
                                onClick = { onUpdateSettings(settings.copy(whoCanFollowMe = option)) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) VidBookBlue else MaterialTheme.colorScheme.outlineVariant
                                ),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (isSelected) VidBookBlue.copy(alpha = 0.12f) else Color.Transparent
                                )
                            ) {
                                Text(
                                    text = if (appLanguage == AppLanguage.BN) option.titleBn else option.titleEn,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) VidBookBlue else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // C. আমার প্রোফাইল কে দেখবে: সবাই / শুধু ফলোয়ার
                    Text(
                        text = AppStrings.get(appLanguage, "আমার প্রোফাইল কে দেখবে:", "Who can see my profile:"),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = VidBookBlue
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ProfileVisibility.values().forEach { option ->
                            val isSelected = settings.profileVisibility == option
                            OutlinedButton(
                                onClick = { onUpdateSettings(settings.copy(profileVisibility = option)) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) VidBookBlue else MaterialTheme.colorScheme.outlineVariant
                                ),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (isSelected) VidBookBlue.copy(alpha = 0.12f) else Color.Transparent
                                )
                            ) {
                                Text(
                                    text = if (appLanguage == AppLanguage.BN) option.titleBn else option.titleEn,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) VidBookBlue else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = AppStrings.get(appLanguage, "✓ পরিবর্তনসমূহ সরাসরি Firebase Firestore-এ সিঙ্ক হয়", "✓ Changes are synced directly to Firebase Firestore"),
                        fontSize = 11.sp,
                        color = Color(0xFF2E7D32),
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

// ==========================================
// 2. 🌐 Language Settings Section
// ==========================================
@Composable
private fun LanguageSettingsSection(
    currentLanguage: AppLanguage,
    onLanguageSelected: (AppLanguage) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().testTag("language_settings_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF00897B).copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = null,
                        tint = Color(0xFF00897B),
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = AppStrings.languageSettingsTitle(currentLanguage),
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = AppStrings.get(currentLanguage, "পুরো অ্যাপের ভাষা সাথে সাথে পরিবর্তন হবে", "Instantly changes app language"),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Bangla Option
                LanguageOptionCard(
                    title = "বাংলা (Bengali)",
                    subtitle = AppStrings.get(currentLanguage, "ডিফল্ট ভাষা", "Default Language"),
                    isSelected = currentLanguage == AppLanguage.BN,
                    onClick = { onLanguageSelected(AppLanguage.BN) },
                    modifier = Modifier.weight(1f)
                )

                // English Option
                LanguageOptionCard(
                    title = "English",
                    subtitle = AppStrings.get(currentLanguage, "ইংরেজি ভাষা", "English Language"),
                    isSelected = currentLanguage == AppLanguage.EN,
                    onClick = { onLanguageSelected(AppLanguage.EN) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun LanguageOptionCard(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(
            1.5.dp,
            if (isSelected) Color(0xFF00897B) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
        ),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0xFF00897B).copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = isSelected,
                onClick = onClick,
                colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF00897B))
            )
            Spacer(modifier = Modifier.width(6.dp))
            Column {
                Text(
                    text = title,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 13.sp,
                    color = if (isSelected) Color(0xFF00897B) else MaterialTheme.colorScheme.onSurface
                )
                Text(text = subtitle, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

// ==========================================
// 3. 📱 Data Saver Mode Section
// ==========================================
@Composable
private fun DataSaverSection(
    isEnabled: Boolean,
    onToggle: (Boolean) -> Unit,
    appLanguage: AppLanguage
) {
    Card(
        modifier = Modifier.fillMaxWidth().testTag("data_saver_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE65100).copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.DataSaverOn,
                        contentDescription = null,
                        tint = Color(0xFFE65100),
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = AppStrings.dataSaverTitle(appLanguage),
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = AppStrings.get(
                            appLanguage,
                            "চালু করলে ভিডিও কম কোয়ালিটিতে চলবে এবং ছবি কম সাইজে লোড হবে।",
                            "Streams videos in lower quality and loads compressed images to save data."
                        ),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 16.sp
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Switch(
                checked = isEnabled,
                onCheckedChange = onToggle,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = Color(0xFFE65100)
                ),
                modifier = Modifier.testTag("data_saver_switch")
            )
        }
    }
}

// ==========================================
// 4. 🚫 Block List Section
// ==========================================
@Composable
private fun BlockListSection(
    blockedUsers: List<BlockedUser>,
    onUnblockUser: (String) -> Unit,
    appLanguage: AppLanguage
) {
    var isExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth().testTag("block_list_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFC62828).copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Block,
                            contentDescription = null,
                            tint = Color(0xFFC62828),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = AppStrings.blockListTitle(appLanguage),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = AppStrings.get(
                                appLanguage,
                                "ব্লক করা ইউজারের পোস্ট/ভিডিও ফিডে দেখাবে না (${blockedUsers.size} জন)",
                                "Blocked users won't appear in your feed (${blockedUsers.size} blocked)"
                            ),
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = Color(0xFFC62828)
                )
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 14.dp)) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(10.dp))

                    if (blockedUsers.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = AppStrings.get(appLanguage, "আপনার ব্লক লিস্টে কেউ নেই।", "No users currently blocked."),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        blockedUsers.forEach { user ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AsyncImage(
                                        model = user.avatarUrl.ifBlank { "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&q=80" },
                                        contentDescription = null,
                                        modifier = Modifier.size(36.dp).clip(CircleShape),
                                        contentScale = ContentScale.Crop
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(text = user.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                        Text(text = user.username, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                OutlinedButton(
                                    onClick = { onUnblockUser(user.id) },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = VidBookBlue)
                                ) {
                                    Text(AppStrings.get(appLanguage, "আনব্লক", "Unblock"), fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 5. 🔕 Notification Customization Section
// ==========================================
@Composable
private fun NotificationCustomizationSection(
    preferences: NotificationPreferences,
    onUpdatePreferences: (NotificationPreferences) -> Unit,
    appLanguage: AppLanguage
) {
    var isExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth().testTag("notification_customization_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF6A1B9A).copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = null,
                            tint = Color(0xFF6A1B9A),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = AppStrings.notifCustomizationTitle(appLanguage),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = AppStrings.get(appLanguage, "লাইক, কমেন্ট, ফলো ও নতুন ভিডিও অ্যালার্ট", "Likes, comments, follows & video alerts"),
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = Color(0xFF6A1B9A)
                )
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 14.dp)) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(10.dp))

                    NotificationSettingToggleItem(
                        title = AppStrings.get(appLanguage, "লাইক নোটিফিকেশন", "Like Notifications"),
                        subtitle = AppStrings.get(appLanguage, "পোস্টে নতুন লাইক আসলে নোটিফিকেশন পাবেন", "Notify when someone likes your post"),
                        checked = preferences.likeNotifications,
                        onCheckedChange = { onUpdatePreferences(preferences.copy(likeNotifications = it)) }
                    )

                    NotificationSettingToggleItem(
                        title = AppStrings.get(appLanguage, "কমেন্ট নোটিফিকেশন", "Comment Notifications"),
                        subtitle = AppStrings.get(appLanguage, "পোস্টে নতুন মন্তব্য আসলে নোটিফিকেশন পাবেন", "Notify when someone comments on your post"),
                        checked = preferences.commentNotifications,
                        onCheckedChange = { onUpdatePreferences(preferences.copy(commentNotifications = it)) }
                    )

                    NotificationSettingToggleItem(
                        title = AppStrings.get(appLanguage, "ফলো নোটিফিকেশন", "Follow Notifications"),
                        subtitle = AppStrings.get(appLanguage, "নতুন কেউ ফলো বা ফ্রেন্ড রিকোয়েস্ট পাঠালে", "Notify on new followers or friend requests"),
                        checked = preferences.followNotifications,
                        onCheckedChange = { onUpdatePreferences(preferences.copy(followNotifications = it)) }
                    )

                    NotificationSettingToggleItem(
                        title = AppStrings.get(appLanguage, "নতুন ভিডিও নোটিফিকেশন", "New Video Notifications"),
                        subtitle = AppStrings.get(appLanguage, "সাবস্ক্রাইব করা চ্যানেলে নতুন ভিডিও প্রকাশ হলে", "Notify when subscribed channels publish new videos"),
                        checked = preferences.newVideoNotifications,
                        onCheckedChange = { onUpdatePreferences(preferences.copy(newVideoNotifications = it)) }
                    )
                }
            }
        }
    }
}

@Composable
private fun NotificationSettingToggleItem(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontWeight = FontWeight.Medium, fontSize = 13.sp)
            Text(text = subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.size(width = 36.dp, height = 24.dp),
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF6A1B9A))
        )
    }
}

// ==========================================
// 6. 📊 Clear Cache Section
// ==========================================
@Composable
private fun ClearCacheSection(
    cacheSizeBytes: Long,
    onClearCache: () -> Unit,
    appLanguage: AppLanguage
) {
    val cacheDisplay = formatBytes(cacheSizeBytes, appLanguage)

    Card(
        modifier = Modifier.fillMaxWidth().testTag("clear_cache_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(VidBookBlue.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CleaningServices,
                            contentDescription = null,
                            tint = VidBookBlue,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = AppStrings.clearCacheTitle(appLanguage),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = AppStrings.get(
                                appLanguage,
                                "বর্তমানে ব্যবহৃত ক্যাশ সাইজ: $cacheDisplay",
                                "Current cache size: $cacheDisplay"
                            ),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = VidBookBlue
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onClearCache,
                modifier = Modifier.fillMaxWidth().testTag("clear_cache_action_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = VidBookBlue),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(imageVector = Icons.Default.CleaningServices, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = AppStrings.get(appLanguage, "Cache পরিষ্কার করুন ($cacheDisplay খালি হবে)", "Clear Cache ($cacheDisplay will be freed)"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}

// ==========================================
// 7. 🔑 Delete Account Section
// ==========================================
@Composable
private fun DeleteAccountSection(
    onRequestDelete: () -> Unit,
    appLanguage: AppLanguage
) {
    Card(
        modifier = Modifier.fillMaxWidth().testTag("delete_account_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE).copy(alpha = 0.6f)),
        border = BorderStroke(1.dp, Color(0xFFEF5350).copy(alpha = 0.4f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE53935).copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteForever,
                        contentDescription = null,
                        tint = Color(0xFFE53935),
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = AppStrings.deleteAccountTitle(appLanguage),
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color(0xFFC62828)
                    )
                    Text(
                        text = AppStrings.get(
                            appLanguage,
                            "Firebase থেকে অ্যাকাউন্ট ও সমস্ত পোস্ট, ভিডিও চিরতরে মুছে যাবে",
                            "Permanently deletes account, posts & videos from Firebase"
                        ),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onRequestDelete,
                modifier = Modifier.fillMaxWidth().testTag("delete_account_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(imageVector = Icons.Default.PersonRemove, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = AppStrings.get(appLanguage, "অ্যাকাউন্ট সম্পূর্ণ মুছে ফেলুন", "Delete Account Completely"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color.White
                )
            }
        }
    }
}

private fun formatBytes(bytes: Long, lang: AppLanguage): String {
    if (bytes <= 0) return if (lang == AppLanguage.BN) "০ KB" else "0 KB"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val formatted = if (mb >= 1.0) {
        String.format("%.1f MB", mb)
    } else {
        String.format("%.0f KB", kb)
    }
    return AppStrings.formatDigits(formatted, lang)
}
