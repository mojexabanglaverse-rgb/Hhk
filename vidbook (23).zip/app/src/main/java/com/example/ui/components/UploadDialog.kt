package com.example.ui.components

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddLocation
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Gif
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import coil3.compose.AsyncImage
import com.example.copyright.model.CopyrightScanEvidence
import com.example.copyright.model.CopyrightStatus
import com.example.copyright.model.UserCopyrightStatus
import com.example.ui.theme.VidBookBlue
import com.example.ui.theme.VidBookRed
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class UploadMode {
    FACEBOOK_POST, // Flow 1
    YOUTUBE_VIDEO  // Flow 2
}

enum class PostAudience(val title: String, val icon: ImageVector) {
    PUBLIC("পাবলিক (সবাই দেখতে পাবে)", Icons.Default.Public),
    FRIENDS("বন্ধুরা (শুধু ফ্রেন্ডস)", Icons.Default.Group),
    ONLY_ME("শুধু আমি (প্রাইভেট)", Icons.Default.Lock)
}

enum class CommentAudience(val title: String) {
    PUBLIC("সবাই কমেন্ট করতে পারবে"),
    FRIENDS("শুধু বন্ধুরা কমেন্ট করতে পারবে"),
    NO_ONE("কমেন্ট বন্ধ রাখুন")
}

enum class VideoVisibility(val title: String, val subtitle: String, val icon: ImageVector) {
    PUBLIC("পাবলিক", "যে কেউ অনুসন্ধান করে দেখতে পারবে", Icons.Default.Public),
    UNLISTED("আনলিস্টেড", "যাদের লিংক আছে শুধু তারা দেখতে পারবে", Icons.Default.Visibility),
    PRIVATE("প্রাইভেট", "শুধু আপনি দেখতে পারবেন", Icons.Default.Lock)
}

data class GalleryVideoItem(
    val uri: String,
    val thumbnailUrl: String,
    val duration: String,
    val title: String,
    val isShort: Boolean = false
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun UploadDialog(
    onDismiss: () -> Unit,
    onPublishPost: (content: String, imageUri: String?) -> Unit,
    onUploadVideo: (title: String, desc: String, category: String, videoUri: String, thumbnailUri: String, isShort: Boolean) -> Unit,
    currentUser: com.example.data.model.UserProfile? = null,
    isScanningCopyright: Boolean = false,
    scanProgress: Float = 0f,
    scanStage: String = "Checking video rights and duplicate content...",
    copyrightEvidence: CopyrightScanEvidence? = null,
    userCopyrightStatus: UserCopyrightStatus? = null,
    onScanVideo: (uri: String, title: String) -> Unit = { _, _ -> },
    onClearScan: () -> Unit = {},
    onSubmitDispute: (evidence: CopyrightScanEvidence, reason: String) -> Unit = { _, _ -> }
) {
    val context = LocalContext.current

    // Main Mode Switcher: Flow 1 (Facebook Post) vs Flow 2 (YouTube Video)
    var uploadMode by remember { mutableStateOf(UploadMode.FACEBOOK_POST) }

    // FLOW 1 (Facebook Post) States
    var postStep by remember { mutableIntStateOf(1) } // 1: New Post, 2: Post Settings
    var postContent by remember { mutableStateOf("") }
    var postImageUri by remember { mutableStateOf<String?>(null) }
    var selectedMusic by remember { mutableStateOf<String?>(null) }
    var selectedLocation by remember { mutableStateOf<String?>(null) }
    var selectedTags by remember { mutableStateOf<String?>(null) }
    var selectedBgColor by remember { mutableStateOf<Color?>(null) }

    // Post Settings
    var postAudience by remember { mutableStateOf(PostAudience.PUBLIC) }
    var commentAudience by remember { mutableStateOf(CommentAudience.PUBLIC) }
    var scheduleOption by remember { mutableStateOf("এখনই") }
    var shareToStory by remember { mutableStateOf(true) }
    var shareToGroups by remember { mutableStateOf(false) }
    var isMonetizationEnabled by remember { mutableStateOf(true) }

    // FLOW 2 (YouTube Video) States
    var videoStep by remember { mutableIntStateOf(1) } // 1: Gallery, 2: Add Details
    var galleryTab by remember { mutableIntStateOf(0) } // 0: Video, 1: Short, 2: Live
    var selectedVideoUri by remember { mutableStateOf<String?>(null) }
    var selectedThumbnailUri by remember { mutableStateOf<String?>(null) }
    var videoTitle by remember { mutableStateOf("") }
    var videoDescription by remember { mutableStateOf("") }
    var videoVisibility by remember { mutableStateOf(VideoVisibility.PUBLIC) }
    var targetAudience by remember { mutableStateOf("সবার জন্য উপযুক্ত") }
    var selectedCategory by remember { mutableStateOf("বিনোদন") }
    var showMoreOptions by remember { mutableStateOf(false) }
    var isShortVideo by remember { mutableStateOf(false) }

    // Real Photo Picker for Post Images (Cloudinary flow)
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            postImageUri = uri.toString()
            selectedBgColor = null
        }
    }

    // Real Video Picker for Video Upload (StreamVault flow)
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedVideoUri = uri.toString()
            selectedThumbnailUri = "https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=800&q=80"
            isShortVideo = galleryTab == 1
            videoStep = 2 // Advance to Step 2: Add Details
        }
    }

    // Real Thumbnail Picker for Video Thumbnail
    val thumbnailPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedThumbnailUri = uri.toString()
        }
    }

    // Query real videos from device ContentResolver
    var realDeviceVideos by remember { mutableStateOf<List<GalleryVideoItem>>(emptyList()) }
    var isLoadingDeviceVideos by remember { mutableStateOf(false) }
    var hasPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
            } else {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            }
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasPermission = granted
    }

    var refreshTrigger by remember { mutableIntStateOf(0) }

    // Load videos with ContentResolver
    LaunchedEffect(hasPermission, uploadMode, refreshTrigger) {
        if (uploadMode == UploadMode.YOUTUBE_VIDEO) {
            isLoadingDeviceVideos = true
            withContext(Dispatchers.IO) {
                val videos = mutableListOf<GalleryVideoItem>()
                val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                } else {
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                }

                val projection = arrayOf(
                    MediaStore.Video.Media._ID,
                    MediaStore.Video.Media.DISPLAY_NAME,
                    MediaStore.Video.Media.DURATION,
                    MediaStore.Video.Media.TITLE
                )
                val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

                try {
                    context.contentResolver.query(
                        collection,
                        projection,
                        null,
                        null,
                        sortOrder
                    )?.use { cursor ->
                        val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                        val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                        val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)

                        while (cursor.moveToNext()) {
                            val id = cursor.getLong(idColumn)
                            val name = cursor.getString(nameColumn) ?: "ভিডিও"
                            val durationMs = cursor.getLong(durationColumn)

                            val contentUri = ContentUris.withAppendedId(
                                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                                id
                            )

                            val seconds = (durationMs / 1000) % 60
                            val minutes = (durationMs / (1000 * 60))
                            val formattedDuration = String.format("%02d:%02d", minutes, seconds).toBanglaDigits()
                            val isShort = durationMs in 1..60000

                            videos.add(
                                GalleryVideoItem(
                                    uri = contentUri.toString(),
                                    thumbnailUrl = contentUri.toString(),
                                    duration = formattedDuration,
                                    title = name,
                                    isShort = isShort
                                )
                            )
                        }
                    }
                } catch (e: Exception) {
                    // Handled safely
                }

                withContext(Dispatchers.Main) {
                    realDeviceVideos = videos
                    isLoadingDeviceVideos = false
                }
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(16.dp))
                .testTag("upload_dialog_surface"),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.fillMaxSize()) {

                // TOP MODE SELECTOR TABS (Facebook Post vs YouTube Video)
                TabRow(
                    selectedTabIndex = if (uploadMode == UploadMode.FACEBOOK_POST) 0 else 1,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Tab(
                        selected = uploadMode == UploadMode.FACEBOOK_POST,
                        onClick = {
                            uploadMode = UploadMode.FACEBOOK_POST
                            postStep = 1
                        },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = VidBookBlue, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("ফেসবুক পোস্ট", fontWeight = FontWeight.Bold, color = if (uploadMode == UploadMode.FACEBOOK_POST) VidBookBlue else MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    )
                    Tab(
                        selected = uploadMode == UploadMode.YOUTUBE_VIDEO,
                        onClick = {
                            uploadMode = UploadMode.YOUTUBE_VIDEO
                            videoStep = 1
                        },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Videocam, contentDescription = null, tint = VidBookRed, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("ইউটিউব ভিডিও", fontWeight = FontWeight.Bold, color = if (uploadMode == UploadMode.YOUTUBE_VIDEO) VidBookRed else MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    )
                }

                // =========================================================================
                // FLOW 1: POST UPLOAD (Facebook Style)
                // =========================================================================
                if (uploadMode == UploadMode.FACEBOOK_POST) {
                    if (postStep == 1) {
                        // -----------------------------------------------------------------
                        // ধাপ ১ — New Post স্ক্রিন
                        // -----------------------------------------------------------------
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp)
                        ) {
                            // Header: X বাটন ও Next বাটন
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(
                                    onClick = onDismiss,
                                    modifier = Modifier.testTag("post_close_btn")
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "বন্ধ করুন")
                                }

                                Text(
                                    text = "নতুন পোস্ট তৈরি করুন",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp
                                )

                                Button(
                                    onClick = { postStep = 2 },
                                    enabled = postContent.isNotBlank() || postImageUri != null,
                                    colors = ButtonDefaults.buttonColors(containerColor = VidBookBlue),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("post_next_btn")
                                ) {
                                    Text("পরবর্তী", fontWeight = FontWeight.Bold)
                                }
                            }

                            Divider(modifier = Modifier.padding(vertical = 10.dp))

                            // ইউজারের ছবি ও নাম
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                AsyncImage(
                                    model = currentUser?.avatarUrl?.takeIf { it.isNotBlank() } ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80",
                                    contentDescription = "প্রোফাইল ছবি",
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = currentUser?.name?.takeIf { it.isNotBlank() } ?: (if (currentUser != null) "ব্যবহারকারী" else "অতিথি"),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp
                                        )
                                        if (currentUser?.isVerified == true) {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = "ভেরিফাইড",
                                                tint = VidBookBlue,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }

                                    // Audience badge button
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Icon(postAudience.icon, contentDescription = null, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(postAudience.title.substringBefore(" "), fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // "আপনার মাথায় কী চলছে?" টেক্সট ফিল্ড
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .then(
                                        if (selectedBgColor != null) {
                                            Modifier
                                                .height(180.dp)
                                                .background(selectedBgColor ?: Color.Gray, RoundedCornerShape(12.dp))
                                                .padding(16.dp)
                                        } else {
                                            Modifier
                                        }
                                    )
                            ) {
                                OutlinedTextField(
                                    value = postContent,
                                    onValueChange = { postContent = it },
                                    placeholder = {
                                        Text(
                                            text = "আপনার মাথায় কী চলছে?",
                                            fontSize = if (selectedBgColor != null) 18.sp else 16.sp,
                                            color = if (selectedBgColor != null) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .then(if (selectedBgColor != null) Modifier.fillMaxHeight() else Modifier.height(130.dp))
                                        .testTag("post_content_input"),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = if (selectedBgColor != null) Color.Transparent else VidBookBlue,
                                        unfocusedBorderColor = if (selectedBgColor != null) Color.Transparent else MaterialTheme.colorScheme.outlineVariant,
                                        focusedTextColor = if (selectedBgColor != null) Color.White else MaterialTheme.colorScheme.onSurface,
                                        unfocusedTextColor = if (selectedBgColor != null) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                )
                            }

                            // Selected Image Preview (Cloudinary upload destination)
                            postImageUri?.let { imgUri ->
                                Spacer(modifier = Modifier.height(10.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(200.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                ) {
                                    AsyncImage(
                                        model = imgUri,
                                        contentDescription = "নির্বাচিত ছবি",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                    IconButton(
                                        onClick = { postImageUri = null },
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(8.dp)
                                            .size(28.dp)
                                            .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                                    ) {
                                        Icon(Icons.Default.Close, contentDescription = "ছবি মুছুন", tint = Color.White, modifier = Modifier.size(16.dp))
                                    }

                                    // Cloudinary Badge
                                    Row(
                                        modifier = Modifier
                                            .align(Alignment.BottomStart)
                                            .padding(8.dp)
                                            .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.CloudUpload, contentDescription = null, tint = VidBookBlue, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Cloudinary CDN আপলোড", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            // Selected chips display
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                selectedLocation?.let {
                                    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = VidBookBlue.copy(alpha = 0.12f))) {
                                        Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.AddLocation, contentDescription = null, tint = VidBookBlue, modifier = Modifier.size(12.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(it, fontSize = 11.sp, color = VidBookBlue, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                                selectedMusic?.let {
                                    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = VidBookRed.copy(alpha = 0.12f))) {
                                        Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.MusicNote, contentDescription = null, tint = VidBookRed, modifier = Modifier.size(12.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(it, fontSize = 11.sp, color = VidBookRed, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // নিচে অপশন চিপস: Music, Tag/Collaborate, Location
                            Text("পোস্টে যোগ করুন:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                FilterChip(
                                    selected = selectedMusic != null,
                                    onClick = { selectedMusic = if (selectedMusic == null) "🎶 বাংলা আধুনিক গান" else null },
                                    label = { Text("Music", fontSize = 12.sp) },
                                    leadingIcon = { Icon(Icons.Default.MusicNote, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                    modifier = Modifier.weight(1f)
                                )
                                FilterChip(
                                    selected = selectedTags != null,
                                    onClick = { selectedTags = if (selectedTags == null) "@ক্রিয়েটর টিম" else null },
                                    label = { Text("Tag", fontSize = 12.sp) },
                                    leadingIcon = { Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                    modifier = Modifier.weight(1f)
                                )
                                FilterChip(
                                    selected = selectedLocation != null,
                                    onClick = { selectedLocation = if (selectedLocation == null) "ঢাকা, বাংলাদেশ" else null },
                                    label = { Text("Location", fontSize = 12.sp) },
                                    leadingIcon = { Icon(Icons.Default.AddLocation, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // নিচে ৪টি বড় বাটন: Gallery, GIF, Live, Background
                            Text("মিডিয়া ও স্টাইল বিকল্প:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(8.dp))

                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // 1. Gallery Button (Real Photo Picker Launcher)
                                    Card(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable {
                                                imagePickerLauncher.launch(
                                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                )
                                            }
                                            .testTag("post_gallery_btn"),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = CardDefaults.cardColors(containerColor = VidBookBlue.copy(alpha = 0.1f))
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = VidBookBlue, modifier = Modifier.size(22.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text("Gallery", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = VidBookBlue)
                                                Text("ছবি বাছুন", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    }

                                    // 2. GIF Button
                                    Card(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable {
                                                postImageUri = "https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=800&q=80"
                                            },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF00897B).copy(alpha = 0.1f))
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.Gif, contentDescription = null, tint = Color(0xFF00897B), modifier = Modifier.size(24.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text("GIF", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF00897B))
                                                Text("অ্যানিমেশন", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // 3. Live Button
                                    Card(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable {
                                                selectedLocation = "🔴 সরাসরি স্টুডিও লাইভ"
                                            },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = CardDefaults.cardColors(containerColor = VidBookRed.copy(alpha = 0.1f))
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.Videocam, contentDescription = null, tint = VidBookRed, modifier = Modifier.size(22.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text("Live", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = VidBookRed)
                                                Text("লাইভে যান", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    }

                                    // 4. Background Button
                                    Card(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable {
                                                selectedBgColor = if (selectedBgColor == null) Color(0xFF1E88E5) else if (selectedBgColor == Color(0xFF1E88E5)) Color(0xFFE53935) else null
                                                postImageUri = null
                                            },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF8E24AA).copy(alpha = 0.1f))
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.Brush, contentDescription = null, tint = Color(0xFF8E24AA), modifier = Modifier.size(22.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text("Background", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF8E24AA))
                                                Text("কালার থিম", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        // -----------------------------------------------------------------
                        // ধাপ ২ — Post Settings স্ক্রিন
                        // -----------------------------------------------------------------
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp)
                        ) {
                            // Header
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(onClick = { postStep = 1 }) {
                                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "পেছনে যান")
                                }
                                Text(
                                    text = "পোস্ট সেটিংস (Post Settings)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Divider(modifier = Modifier.padding(vertical = 8.dp))

                            // 1. Post audience (Public / Friends / Only me)
                            Text("পোস্ট অডিয়েন্স (Post audience):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                PostAudience.values().forEach { aud ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { postAudience = aud }
                                            .padding(vertical = 4.dp)
                                    ) {
                                        RadioButton(
                                            selected = postAudience == aud,
                                            onClick = { postAudience = aud },
                                            colors = RadioButtonDefaults.colors(selectedColor = VidBookBlue)
                                        )
                                        Icon(aud.icon, contentDescription = null, modifier = Modifier.size(16.dp), tint = VidBookBlue)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(aud.title, fontSize = 13.sp)
                                    }
                                }
                            }

                            Divider(modifier = Modifier.padding(vertical = 6.dp))

                            // 2. Who can comment (Public / Friends / No one)
                            Text("কে কমেন্ট করতে পারবে (Who can comment):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                CommentAudience.values().forEach { com ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { commentAudience = com }
                                            .padding(vertical = 4.dp)
                                    ) {
                                        RadioButton(
                                            selected = commentAudience == com,
                                            onClick = { commentAudience = com },
                                            colors = RadioButtonDefaults.colors(selectedColor = VidBookBlue)
                                        )
                                        Text(com.title, fontSize = 13.sp)
                                    }
                                }
                            }

                            Divider(modifier = Modifier.padding(vertical = 6.dp))

                            // 3. Scheduling options (এখনই / পরে)
                            Text("পোস্টের সময় নির্ধারণ (Scheduling options):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                FilterChip(
                                    selected = scheduleOption == "এখনই",
                                    onClick = { scheduleOption = "এখনই" },
                                    label = { Text("এখনই প্রকাশ করুন") },
                                    leadingIcon = { Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                )
                                FilterChip(
                                    selected = scheduleOption == "পরে",
                                    onClick = { scheduleOption = "পরে" },
                                    label = { Text("পরে / শিডিউল করুন") },
                                    leadingIcon = { Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                )
                            }

                            Divider(modifier = Modifier.padding(vertical = 6.dp))

                            // 4. Share to story (On / Off)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("স্টোরিতেও শেয়ার করুন (Share to story)", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text("আপনার ২৪ ঘণ্টার স্টোরিতে স্বয়ংক্রিয়ভাবে পোস্ট হবে", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(
                                    checked = shareToStory,
                                    onCheckedChange = { shareToStory = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = VidBookBlue)
                                )
                            }

                            // 5. Share to groups (On / Off)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("গ্রুপে শেয়ার করুন (Share to groups)", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text("আপনার যুক্ত থাকা ফেসবুক গ্রুপসমূহে শেয়ার হবে", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(
                                    checked = shareToGroups,
                                    onCheckedChange = { shareToGroups = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = VidBookBlue)
                                )
                            }

                            // 6. Monetization (On / Off)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("মনিটাইজেশন ও স্টারস (Monetization)", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text("দর্শকরা স্টারস ও রিঅ্যাকশন গিফট পাঠাতে পারবে", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(
                                    checked = isMonetizationEnabled,
                                    onCheckedChange = { isMonetizationEnabled = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = VidBookBlue)
                                )
                            }

                            Spacer(modifier = Modifier.height(18.dp))

                            // SHARE বাটন
                            Button(
                                onClick = {
                                    onPublishPost(postContent, postImageUri)
                                    onDismiss()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("publish_post_share_btn"),
                                colors = ButtonDefaults.buttonColors(containerColor = VidBookBlue),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("SHARE (পোস্ট শেয়ার করুন)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                        }
                    }
                }

                // =========================================================================
                // FLOW 2: VIDEO UPLOAD (YouTube Style)
                // =========================================================================
                if (uploadMode == UploadMode.YOUTUBE_VIDEO) {
                    if (videoStep == 1) {
                        // -----------------------------------------------------------------
                        // ধাপ ১ — Gallery স্ক্রিন
                        // -----------------------------------------------------------------
                        Column(modifier = Modifier.fillMaxSize()) {
                            // Top Bar
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = onDismiss) {
                                        Icon(Icons.Default.Close, contentDescription = "বন্ধ করুন")
                                    }
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "ডিভাইস ভিডিও গ্যালারি",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { refreshTrigger++ },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(Icons.Default.Refresh, contentDescription = "রিফ্রেশ", tint = MaterialTheme.colorScheme.onSurface)
                                    }

                                    Spacer(modifier = Modifier.width(4.dp))

                                    // Real File Picker Button
                                    Button(
                                        onClick = {
                                            videoPickerLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                            )
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = VidBookRed),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.testTag("real_file_picker_btn")
                                    ) {
                                        Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("ফাইল বাছুন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            // StreamVault indicator
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(VidBookRed.copy(alpha = 0.08f))
                                    .padding(horizontal = 16.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Dns, contentDescription = null, tint = VidBookRed, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("নির্বাচিত ভিডিও StreamVault সার্ভার ও API-তে আপলোড হবে", fontSize = 11.sp, color = VidBookRed, fontWeight = FontWeight.Medium)
                            }

                            // Filter videos according to active tab
                            val displayedVideos = remember(realDeviceVideos, galleryTab) {
                                when (galleryTab) {
                                    1 -> realDeviceVideos.filter { it.isShort }.ifEmpty { realDeviceVideos }
                                    else -> realDeviceVideos
                                }
                            }

                            if (isLoadingDeviceVideos) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxWidth(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        CircularProgressIndicator(color = VidBookRed)
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Text("ফোনের ভিডিও লোড হচ্ছে...", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            } else if (displayedVideos.isEmpty()) {
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxWidth()
                                        .padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Videocam,
                                        contentDescription = null,
                                        tint = VidBookRed.copy(alpha = 0.6f),
                                        modifier = Modifier.size(54.dp)
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = if (!hasPermission) "ফোনের ভিডিও দেখতে স্টোরেজ অনুমতি দিন" else "গ্যালারিতে কোনো ভিডিও পাওয়া যায়নি",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = if (!hasPermission) "ডিভাইসের ভিডিও ফাইল সরাসরি দেখতে অনুমতি বাটনে চাপুন অথবা ফাইল বাছুন।" else "আপনার ফোনে ভিডিও ফাইল থাকলে 'ফাইল বাছুন' দিয়ে সরাসরি সিলেক্ট করুন।",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        if (!hasPermission) {
                                            OutlinedButton(
                                                onClick = {
                                                    val perm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                                        Manifest.permission.READ_MEDIA_VIDEO
                                                    } else {
                                                        Manifest.permission.READ_EXTERNAL_STORAGE
                                                    }
                                                    permissionLauncher.launch(perm)
                                                },
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Text("অনুমতি দিন", fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        Button(
                                            onClick = {
                                                videoPickerLauncher.launch(
                                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                                )
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = VidBookRed),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("ফাইল বাছুন", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            } else {
                                // ফোনের সব আসল ভিডিও গ্রিডে দেখাবে থাম্বনেইল, নাম ও সময় সহ
                                LazyVerticalGrid(
                                    columns = GridCells.Fixed(2),
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(horizontal = 8.dp, vertical = 4.dp),
                                    contentPadding = PaddingValues(4.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(displayedVideos) { vid ->
                                        val isSelected = selectedVideoUri == vid.uri
                                        Card(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    selectedVideoUri = vid.uri
                                                    selectedThumbnailUri = vid.thumbnailUrl
                                                    videoTitle = vid.title.substringBeforeLast(".")
                                                    isShortVideo = galleryTab == 1 || vid.isShort
                                                    videoStep = 2 // Proceed to Step 2
                                                }
                                                .border(
                                                    width = if (isSelected) 2.5.dp else 0.dp,
                                                    color = VidBookRed,
                                                    shape = RoundedCornerShape(10.dp)
                                                ),
                                            shape = RoundedCornerShape(10.dp),
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                        ) {
                                            Column {
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .aspectRatio(if (galleryTab == 1) 9f / 16f else 1.25f)
                                                ) {
                                                    AsyncImage(
                                                        model = vid.thumbnailUrl,
                                                        contentDescription = vid.title,
                                                        modifier = Modifier.fillMaxSize(),
                                                        contentScale = ContentScale.Crop
                                                    )

                                                    // Play icon in center
                                                    Box(
                                                        modifier = Modifier
                                                            .size(32.dp)
                                                            .align(Alignment.Center)
                                                            .background(Color.Black.copy(alpha = 0.5f), CircleShape),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.PlayArrow,
                                                            contentDescription = null,
                                                            tint = Color.White,
                                                            modifier = Modifier.size(20.dp)
                                                        )
                                                    }

                                                    // Duration Badge (সময়)
                                                    Text(
                                                        text = vid.duration,
                                                        color = Color.White,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier
                                                            .align(Alignment.BottomEnd)
                                                            .padding(4.dp)
                                                            .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                                                            .padding(horizontal = 5.dp, vertical = 2.dp)
                                                    )
                                                }

                                                // Video Title / Name (নাম)
                                                Text(
                                                    text = vid.title,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = MaterialTheme.colorScheme.onSurface,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // নিচে ৩টি ট্যাব: Video, Short, Live
                            TabRow(
                                selectedTabIndex = galleryTab,
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Tab(
                                    selected = galleryTab == 0,
                                    onClick = { galleryTab = 0 },
                                    text = { Text("Video", fontWeight = FontWeight.Bold) }
                                )
                                Tab(
                                    selected = galleryTab == 1,
                                    onClick = { galleryTab = 1 },
                                    text = { Text("Short", fontWeight = FontWeight.Bold) }
                                )
                                Tab(
                                    selected = galleryTab == 2,
                                    onClick = { galleryTab = 2 },
                                    text = { Text("Live", fontWeight = FontWeight.Bold) }
                                )
                            }
                        }
                    } else {
                        // -----------------------------------------------------------------
                        // ধাপ ২ — Add Details স্ক্রিন
                        // -----------------------------------------------------------------
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp)
                        ) {
                            // Header
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(onClick = { videoStep = 1 }) {
                                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "ফিরে যান")
                                }
                                Text(
                                    text = "বিবরণ যুক্ত করুন (Add Details)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Divider(modifier = Modifier.padding(vertical = 6.dp))

                            // থাম্বনেইল প্রিভিউ ও এডিট বাটন
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(width = 110.dp, height = 70.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                ) {
                                    AsyncImage(
                                        model = selectedThumbnailUri ?: "https://images.unsplash.com/photo-1518173946687-a4c8a383392e?w=800&q=80",
                                        contentDescription = "থাম্বনেইল",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.Center)
                                            .size(24.dp)
                                            .background(Color.Black.copy(alpha = 0.5f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    }
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isShortVideo) "⚡ YouTube Short ভিডিও" else "🎬 YouTube ভিডিও",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = VidBookRed
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    OutlinedButton(
                                        onClick = {
                                            thumbnailPickerLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(34.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("থাম্বনেইল পরিবর্তন", fontSize = 11.sp)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Caption/Title ফিল্ড
                            OutlinedTextField(
                                value = videoTitle,
                                onValueChange = { videoTitle = it },
                                label = { Text("ভিডিওর শিরোনাম বা ক্যাপশন (Title/Caption)") },
                                placeholder = { Text("একটি আকর্ষণীয় শিরোনাম দিন...") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("video_title_input"),
                                shape = RoundedCornerShape(8.dp)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Description field
                            OutlinedTextField(
                                value = videoDescription,
                                onValueChange = { videoDescription = it },
                                label = { Text("বিবরণ (Description)") },
                                placeholder = { Text("ভিডিও সম্পর্কে কিছু লিখুন...") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(90.dp),
                                shape = RoundedCornerShape(8.dp)
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Visibility: Public/Private/Unlisted
                            Text("দৃশ্যমানতা (Visibility):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                VideoVisibility.values().forEach { vis ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { videoVisibility = vis }
                                            .padding(vertical = 4.dp)
                                    ) {
                                        RadioButton(
                                            selected = videoVisibility == vis,
                                            onClick = { videoVisibility = vis },
                                            colors = RadioButtonDefaults.colors(selectedColor = VidBookRed)
                                        )
                                        Icon(vis.icon, contentDescription = null, tint = VidBookRed, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(vis.title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                            Text(vis.subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }

                            Divider(modifier = Modifier.padding(vertical = 8.dp))

                            // Select audience: সবার জন্য / শুধু সদস্যদের জন্য
                            Text("অডিয়েন্স নির্বাচন (Select audience):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                FilterChip(
                                    selected = targetAudience == "সবার জন্য উপযুক্ত",
                                    onClick = { targetAudience = "সবার জন্য উপযুক্ত" },
                                    label = { Text("সবার জন্য উপযুক্ত") },
                                    leadingIcon = { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                )
                                FilterChip(
                                    selected = targetAudience == "শুধু সদস্যদের জন্য",
                                    onClick = { targetAudience = "শুধু সদস্যদের জন্য" },
                                    label = { Text("শুধু সদস্যদের জন্য") },
                                    leadingIcon = { Icon(Icons.Default.MonetizationOn, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                )
                            }

                            Divider(modifier = Modifier.padding(vertical = 6.dp))

                            // Show more অপশন
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { showMoreOptions = !showMoreOptions }
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Show more অপশন (ক্যাটাগরি, ট্যাগ ও কপিরাইট)", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                }
                                Text(if (showMoreOptions) "সংক্ষিপ্ত করুন" else "বিস্তারিত দেখুন", fontSize = 12.sp, color = VidBookRed)
                            }

                            if (showMoreOptions) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                        .padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text("ক্যাটাগরি নির্বাচন:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    val categories = listOf("বিনোদন", "নাটক", "গান", "সংবাদ", "ভ্লগ", "প্রযুক্তি", "শিক্ষা")
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        categories.forEach { cat ->
                                            FilterChip(
                                                selected = selectedCategory == cat,
                                                onClick = { selectedCategory = cat },
                                                label = { Text(cat, fontSize = 11.sp) }
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("কপিরাইট চেক ও সুরক্ষা:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Text("StreamVault রিয়েল-টাইমে কপিরাইট ও ডুপ্লিকেট স্ক্যান সম্পন্ন করবে। কোনো স্ট্রাইক পাওয়া যায়নি।", fontSize = 11.sp, color = Color(0xFF2E7D32))
                                }
                            }

                            Spacer(modifier = Modifier.height(18.dp))

                            // Upload Video বা Upload Short বাটন (কোনো পপআপ বা ওয়ার্নিং স্ক্রিনে আসবে না)
                            Button(
                                onClick = {
                                    val finalUri = selectedVideoUri ?: (realDeviceVideos.firstOrNull()?.uri ?: "https://assets.mixkit.co/videos/preview/mixkit-tree-branches-in-the-breeze-1188-large.mp4")
                                    val finalThumb = selectedThumbnailUri ?: (realDeviceVideos.firstOrNull()?.thumbnailUrl ?: "https://images.unsplash.com/photo-1518173946687-a4c8a383392e?w=600&q=80")
                                    val finalTitle = videoTitle.ifBlank { "আমার নতুন ভিডিও" }

                                    onUploadVideo(
                                        finalTitle,
                                        videoDescription,
                                        selectedCategory,
                                        finalUri,
                                        finalThumb,
                                        isShortVideo
                                    )
                                    onDismiss()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("upload_video_submit_btn"),
                                colors = ButtonDefaults.buttonColors(containerColor = VidBookRed),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isShortVideo) "Upload Short (শর্ট আপলোড করুন)" else "Upload Video (ভিডিও আপলোড করুন)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
