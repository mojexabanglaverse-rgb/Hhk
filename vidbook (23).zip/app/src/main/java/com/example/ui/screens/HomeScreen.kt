package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.DynamicFeed
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil3.compose.AsyncImage
import com.example.data.model.Post
import com.example.data.model.Story
import com.example.data.model.UserProfile
import com.example.data.model.Video
import com.example.data.model.AppLanguage
import com.example.data.model.BlockedUser
import com.example.data.model.NotificationPreferences
import com.example.data.model.PrivacySettings
import com.example.ui.FeedPreference
import com.example.ui.util.AppStrings
import com.example.ui.components.SocialPostCard
import com.example.ui.components.StoryRow
import com.example.ui.components.VideoCard
import com.example.ui.theme.VidBookBlue
import com.example.ui.theme.VidBookRed
import com.example.ui.util.appString
import com.example.ui.util.LocalAppLanguage

/**
 * Facebook-style TopBar for HomeScreen with 3-dot Menu (⋮)
 * Supports all 7 features:
 * 1. 🔍 Search
 * 2. 🌙 Dark/Light mode toggle
 * 3. 📋 Feed Preferences (All posts, Only videos, Only friends' posts)
 * 4. 🔔 Notification Settings (Turn on/off notifications)
 * 5. ⚙️ Settings (App settings dialog)
 * 6. ❓ Help & Support (FAQ page)
 * 7. 🚪 Logout (Logout from Google account)
 */
@Composable
fun HomeScreenTopBar(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    isDarkMode: Boolean,
    onToggleDarkMode: () -> Unit,
    feedPreference: FeedPreference = FeedPreference.ALL,
    onFeedPreferenceChange: (FeedPreference) -> Unit = {},
    notificationsEnabled: Boolean = true,
    onNotificationsEnabledChange: (Boolean) -> Unit = {},
    onLogout: () -> Unit = {},
    onShowSnackbar: (String) -> Unit = {},
    onOpenSettings: (() -> Unit)? = null,
    onOpenUpload: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var isSearchExpanded by remember { mutableStateOf(false) }
    var isMenuExpanded by remember { mutableStateOf(false) }
    val currentLang = LocalAppLanguage.current

    // Dialog States for Menu Options
    var showFeedPrefDialog by remember { mutableStateOf(false) }
    var showNotifSettingsDialog by remember { mutableStateOf(false) }
    var showAppSettingsDialog by remember { mutableStateOf(false) }
    var showFaqDialog by remember { mutableStateOf(false) }
    var showLogoutConfirmDialog by remember { mutableStateOf(false) }

    val focusManager = LocalFocusManager.current

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 4.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // VidBook Logo & Brand
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { isSearchExpanded = false }
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(VidBookRed, VidBookBlue)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = appString("VidBook লোগো", "VidBook Logo"),
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Vid",
                                fontWeight = FontWeight.Black,
                                fontSize = 20.sp,
                                color = VidBookRed
                            )
                            Text(
                                text = "Book",
                                fontWeight = FontWeight.Black,
                                fontSize = 20.sp,
                                color = VidBookBlue
                            )
                        }
                        Text(
                            text = appString("বাংলাদেশ", "Bangladesh"),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                // 1. Search Toggle Button
                IconButton(
                    onClick = { isSearchExpanded = !isSearchExpanded },
                    modifier = Modifier.testTag("top_bar_search_btn")
                ) {
                    Icon(
                        imageVector = if (isSearchExpanded) Icons.Default.Clear else Icons.Default.Search,
                        contentDescription = appString("অনুসন্ধান", "Search"),
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }

                // 2. Facebook-style Three Dot Menu Button (⋮)
                Box {
                    IconButton(
                        onClick = { isMenuExpanded = true },
                        modifier = Modifier.testTag("home_three_dot_menu_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = appString("মেনু অপশন", "Menu Options"),
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Material 3 Dropdown Menu with all 7 options
                    DropdownMenu(
                        expanded = isMenuExpanded,
                        onDismissRequest = { isMenuExpanded = false },
                        modifier = Modifier
                            .width(260.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .testTag("home_dropdown_menu")
                    ) {
                        // Menu Header
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(VidBookBlue.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DynamicFeed,
                                        contentDescription = null,
                                        tint = VidBookBlue,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = appString("VidBook কুইক মেনু", "VidBook Quick Menu"),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 4.dp),
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                        )

                        // Option 1: 🔍 Search
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(appString("সার্চ", "Search"), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(appString("পোস্ট, ভিডিও ও বন্ধু খুঁজুন", "Search posts, videos & friends"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = null,
                                    tint = VidBookBlue,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            onClick = {
                                isMenuExpanded = false
                                isSearchExpanded = true
                            },
                            modifier = Modifier.testTag("menu_item_search")
                        )

                        // Option 2: 🌙 Dark / Light Mode Toggle
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(
                                        text = if (isDarkMode) appString("লাইট মোড", "Light Mode") else appString("ডার্ক মোড", "Dark Mode"),
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = if (isDarkMode) appString("উজ্জ্বল থিমে স্যুইচ করুন", "Switch to light theme") else appString("রাতের থিমে স্যুইচ করুন", "Switch to dark theme"),
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                                    contentDescription = null,
                                    tint = if (isDarkMode) Color(0xFFFBC02D) else Color(0xFF5C6BC0),
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            trailingIcon = {
                                Switch(
                                    checked = isDarkMode,
                                    onCheckedChange = {
                                        onToggleDarkMode()
                                        isMenuExpanded = false
                                    },
                                    modifier = Modifier.size(width = 36.dp, height = 24.dp),
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = VidBookBlue
                                    )
                                )
                            },
                            onClick = {
                                isMenuExpanded = false
                                onToggleDarkMode()
                            },
                            modifier = Modifier.testTag("menu_item_dark_mode")
                        )

                        // Option 3: 📋 Feed Preferences
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(appString("ফিড প্রেফারেন্স", "Feed Preferences"), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(
                                        text = appString("বর্তমান: ${feedPreference.titleBn}", "Current: ${feedPreference.titleEn}"),
                                        fontSize = 11.sp,
                                        color = VidBookBlue
                                    )
                                }
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Tune,
                                    contentDescription = null,
                                    tint = Color(0xFF00897B),
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            onClick = {
                                isMenuExpanded = false
                                showFeedPrefDialog = true
                            },
                            modifier = Modifier.testTag("menu_item_feed_preference")
                        )

                        // Option 4: 🔔 Notification Settings
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(appString("নোটিফিকেশন সেটিং", "Notification Settings"), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(
                                        text = if (notificationsEnabled) appString("নোটিফিকেশন চালু আছে", "Notifications are on") else appString("নোটিফিকেশন বন্ধ আছে", "Notifications are muted"),
                                        fontSize = 11.sp,
                                        color = if (notificationsEnabled) Color(0xFF2E7D32) else Color(0xFFC62828)
                                    )
                                }
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = if (notificationsEnabled) Icons.Default.NotificationsActive else Icons.Default.NotificationsOff,
                                    contentDescription = null,
                                    tint = if (notificationsEnabled) Color(0xFFFB8C00) else Color.Gray,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            onClick = {
                                isMenuExpanded = false
                                showNotifSettingsDialog = true
                            },
                            modifier = Modifier.testTag("menu_item_notification_setting")
                        )

                        // Option 5: ⚙️ App Settings
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(appString("সেটিংস", "Settings"), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(appString("মিডিয়া, ক্যাশ ও নিরাপত্তা", "Media, cache & privacy"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = null,
                                    tint = Color(0xFF546E7A),
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            onClick = {
                                isMenuExpanded = false
                                if (onOpenSettings != null) {
                                    onOpenSettings()
                                } else {
                                    showAppSettingsDialog = true
                                }
                            },
                            modifier = Modifier.testTag("menu_item_settings")
                        )

                        // Option 6: ❓ Help & Support (FAQ)
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(appString("সাহায্য ও সাপোর্ট", "Help & Support"), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(appString("সাধারণ প্রশ্নোত্তর (FAQ)", "Frequently Asked Questions (FAQ)"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.HelpOutline,
                                    contentDescription = null,
                                    tint = Color(0xFF1E88E5),
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            onClick = {
                                isMenuExpanded = false
                                showFaqDialog = true
                            },
                            modifier = Modifier.testTag("menu_item_help_support")
                        )

                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 4.dp),
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                        )

                        // Option 7: 🚪 Logout
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(appString("লগআউট", "Logout"), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFFE53935))
                                    Text(appString("Google অ্যাকাউন্ট থেকে বের হন", "Sign out of Google Account"), fontSize = 11.sp, color = Color(0xFFE53935).copy(alpha = 0.8f))
                                }
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Logout,
                                    contentDescription = null,
                                    tint = Color(0xFFE53935),
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            onClick = {
                                isMenuExpanded = false
                                showLogoutConfirmDialog = true
                            },
                            modifier = Modifier.testTag("menu_item_logout")
                        )
                    }
                }
            }

            // Expandable Search Bar
            AnimatedVisibility(
                visible = isSearchExpanded,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                        .testTag("search_input_field"),
                    placeholder = {
                        Text(appString("ভিডিও, নাটক, গান বা বন্ধু খুঁজুন…", "Search videos, dramas, songs or friends…"), fontSize = 14.sp)
                    },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = VidBookRed)
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchQueryChange("") }) {
                                Icon(Icons.Default.Clear, contentDescription = appString("মুছুন", "Clear"))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VidBookRed,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() })
                )
            }
        }
    }

    // Dialog 1: Feed Preferences Dialog
    if (showFeedPrefDialog) {
        FeedPreferenceDialog(
            currentPreference = feedPreference,
            onPreferenceSelected = { newPref ->
                onFeedPreferenceChange(newPref)
                showFeedPrefDialog = false
            },
            onDismiss = { showFeedPrefDialog = false }
        )
    }

    // Dialog 2: Notification Settings Dialog
    if (showNotifSettingsDialog) {
        NotificationSettingsDialog(
            notificationsEnabled = notificationsEnabled,
            onToggleEnabled = { enabled ->
                onNotificationsEnabledChange(enabled)
            },
            onDismiss = { showNotifSettingsDialog = false }
        )
    }

    // Dialog 3: App Settings Dialog
    if (showAppSettingsDialog) {
        AppSettingsDialog(
            isDarkMode = isDarkMode,
            onToggleDarkMode = onToggleDarkMode,
            onClearCache = {
                onShowSnackbar(AppStrings.get(currentLang, "ক্যাশ মেমোরি খালি করা হয়েছে (১২.৪ MB খালি হলো)!", "Cache memory cleared (12.4 MB freed)!"))
            },
            onDismiss = { showAppSettingsDialog = false }
        )
    }

    // Dialog 4: Help & Support FAQ Dialog
    if (showFaqDialog) {
        HelpSupportFaqDialog(
            onDismiss = { showFaqDialog = false }
        )
    }

    // Dialog 5: Logout Confirmation Dialog
    if (showLogoutConfirmDialog) {
        LogoutConfirmDialog(
            onConfirm = {
                showLogoutConfirmDialog = false
                onLogout()
                onShowSnackbar(AppStrings.get(currentLang, "Google অ্যাকাউন্ট থেকে সফলভাবে লগআউট করা হয়েছে।", "Signed out of Google account successfully."))
            },
            onDismiss = { showLogoutConfirmDialog = false }
        )
    }
}

/**
 * 3. Feed Preference Dialog
 * Allows selecting: All Posts, Only Videos, Only Friends' Posts
 */
@Composable
fun FeedPreferenceDialog(
    currentPreference: FeedPreference,
    onPreferenceSelected: (FeedPreference) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedOption by remember { mutableStateOf(currentPreference) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("feed_preference_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF00897B).copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            tint = Color(0xFF00897B),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = appString("📋 ফিড প্রেফারেন্স", "📋 Feed Preferences"),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = appString("হোমে কোন ধরনের পোস্ট দেখতে চান?", "Choose which posts to see on Home"),
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(12.dp))

                // Option 1: All Posts
                FeedPreferenceOptionItem(
                    title = appString("🌐 সব পোস্ট", "🌐 All Posts"),
                    subtitle = appString("সব ক্রিয়েটরের সামাজিক পোস্ট ও ট্রেন্ডিং ভিডিও", "Social posts and trending videos from all creators"),
                    isSelected = selectedOption == FeedPreference.ALL,
                    onClick = { selectedOption = FeedPreference.ALL }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Option 2: Only Videos
                FeedPreferenceOptionItem(
                    title = appString("🎬 শুধু ভিডিও", "🎬 Videos Only"),
                    subtitle = appString("শুধুমাত্র ভিডিও ও বিনোদনমূলক কনটেন্ট", "Only videos and entertaining content"),
                    isSelected = selectedOption == FeedPreference.VIDEOS_ONLY,
                    onClick = { selectedOption = FeedPreference.VIDEOS_ONLY }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Option 3: Only Friends' Posts
                FeedPreferenceOptionItem(
                    title = appString("👥 শুধু বন্ধুদের পোস্ট", "👥 Friends' Posts Only"),
                    subtitle = appString("ভেরিফায়েড ক্রিয়েটর ও বন্ধুদের পোস্ট", "Posts from verified creators and friends"),
                    isSelected = selectedOption == FeedPreference.FRIENDS_ONLY,
                    onClick = { selectedOption = FeedPreference.FRIENDS_ONLY }
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text(appString("বাতিল", "Cancel"))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onPreferenceSelected(selectedOption) },
                        colors = ButtonDefaults.buttonColors(containerColor = VidBookBlue),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(appString("সেভ করুন", "Save"), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun FeedPreferenceOptionItem(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(
            1.dp,
            if (isSelected) VidBookBlue else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
        ),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) VidBookBlue.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = isSelected,
                onClick = onClick,
                colors = RadioButtonDefaults.colors(selectedColor = VidBookBlue)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = title,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 14.sp,
                    color = if (isSelected) VidBookBlue else MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

/**
 * 4. Notification Settings Dialog
 * Turn push notifications on/off
 */
@Composable
fun NotificationSettingsDialog(
    notificationsEnabled: Boolean,
    onToggleEnabled: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var masterEnabled by remember { mutableStateOf(notificationsEnabled) }
    var videoAlerts by remember { mutableStateOf(notificationsEnabled) }
    var likesComments by remember { mutableStateOf(notificationsEnabled) }
    var friendRequests by remember { mutableStateOf(notificationsEnabled) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("notification_settings_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFB8C00).copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = null,
                            tint = Color(0xFFFB8C00),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = appString("🔔 নোটিফিকেশন সেটিংস", "🔔 Notification Settings"),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = appString("VidBook এর অ্যালার্ট নিয়ন্ত্রণ করুন", "Manage VidBook notifications"),
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(12.dp))

                // Master Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(appString("সব পুশ নোটিফিকেশন", "All Push Notifications"), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            text = if (masterEnabled) appString("অ্যালার্ট সক্রিয় রয়েছে", "Alerts are active") else appString("সব নোটিফিকেশন বন্ধ", "All notifications muted"),
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = masterEnabled,
                        onCheckedChange = {
                            masterEnabled = it
                            videoAlerts = it
                            likesComments = it
                            friendRequests = it
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = VidBookBlue
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Sub Toggles
                NotificationSubToggle(
                    title = appString("নতুন ভিডিও ও রিলস অ্যালার্ট", "New Video & Reels Alerts"),
                    subtitle = appString("সাবস্ক্রাইব করা চ্যানেলের আপডেট", "Updates from subscribed channels"),
                    enabled = masterEnabled && videoAlerts,
                    onCheckedChange = { videoAlerts = it }
                )

                Spacer(modifier = Modifier.height(8.dp))

                NotificationSubToggle(
                    title = appString("লাইক ও কমেন্ট নোটিফিকেশন", "Likes & Comments Alerts"),
                    subtitle = appString("আপনার পোস্টে অন্যদের প্রতিক্রিয়া", "Reactions on your posts"),
                    enabled = masterEnabled && likesComments,
                    onCheckedChange = { likesComments = it }
                )

                Spacer(modifier = Modifier.height(8.dp))

                NotificationSubToggle(
                    title = appString("ফ্রেন্ড রিকোয়েস্ট ও ফলোয়ার", "Friend Requests & Followers"),
                    subtitle = appString("নতুন ফ্রেন্ড কানেকশন অ্যালার্ট", "New connections & follower alerts"),
                    enabled = masterEnabled && friendRequests,
                    onCheckedChange = { friendRequests = it }
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = {
                            onToggleEnabled(masterEnabled)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VidBookBlue),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(appString("সংরক্ষণ করুন", "Save"), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun NotificationSubToggle(
    title: String,
    subtitle: String,
    enabled: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 6.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = enabled,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.size(width = 36.dp, height = 24.dp),
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = VidBookBlue
            )
        )
    }
}

/**
 * 5. App Settings Dialog
 * Manage App Settings: Autoplay, Quality, Cache, Info
 */
@Composable
fun AppSettingsDialog(
    isDarkMode: Boolean,
    onToggleDarkMode: () -> Unit,
    onClearCache: () -> Unit,
    onDismiss: () -> Unit
) {
    var autoPlayVideos by remember { mutableStateOf(true) }
    var highQualityStreaming by remember { mutableStateOf(true) }
    val scrollState = rememberScrollState()

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("app_settings_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF546E7A).copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = Color(0xFF546E7A),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = appString("⚙️ অ্যাপ সেটিংস", "⚙️ App Settings"),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = appString("VidBook অ্যাপ প্রেফারেন্স কনফিগার করুন", "Configure VidBook preferences"),
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(12.dp))

                // Section 1: Appearance
                Text(
                    text = appString("ডিসপ্লে ও থিম", "Display & Theme"),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = VidBookBlue
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isDarkMode) Icons.Default.DarkMode else Icons.Default.LightMode,
                            contentDescription = null,
                            tint = VidBookBlue,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (isDarkMode) appString("ডার্ক মোড সক্রিয়", "Dark Mode Enabled") else appString("লাইট মোড সক্রিয়", "Light Mode Enabled"), fontSize = 13.sp)
                    }
                    Switch(
                        checked = isDarkMode,
                        onCheckedChange = { onToggleDarkMode() },
                        modifier = Modifier.size(width = 36.dp, height = 24.dp),
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = VidBookBlue)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Section 2: Media & Playback
                Text(
                    text = appString("ভিডিও ও মিডিয়া", "Video & Media"),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = VidBookBlue
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PlayCircleOutline, contentDescription = null, tint = VidBookBlue, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(appString("অটো-প্লে ভিডিও", "Autoplay Videos"), fontSize = 13.sp)
                            Text(appString("Wi-Fi ও মোবাইলে স্বয়ংক্রিয় প্লে", "Play automatically on Wi-Fi and mobile data"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Switch(
                        checked = autoPlayVideos,
                        onCheckedChange = { autoPlayVideos = it },
                        modifier = Modifier.size(width = 36.dp, height = 24.dp),
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = VidBookBlue)
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.HighQuality, contentDescription = null, tint = VidBookBlue, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(appString("উচ্চমান স্ট্রিমিং (HD)", "High Quality Streaming (HD)"), fontSize = 13.sp)
                            Text(appString("ভিডিওর সেরা রেজোলিউশন দেখাবে", "Always stream in highest available quality"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Switch(
                        checked = highQualityStreaming,
                        onCheckedChange = { highQualityStreaming = it },
                        modifier = Modifier.size(width = 36.dp, height = 24.dp),
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = VidBookBlue)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Section 3: Storage & Cache
                Text(
                    text = appString("স্টোরেজ ও ক্যাশ", "Storage & Cache"),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = VidBookBlue
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedButton(
                    onClick = onClearCache,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(appString("ক্যাশ মেমোরি খালি করুন", "Clear Cache"), fontSize = 13.sp)
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Section 4: App Info
                Text(
                    text = appString("অ্যাপ সম্পর্কিত তথ্য", "About App"),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = VidBookBlue
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(appString("VidBook v2.4.0 — বাংলাদেশ এডিশন", "VidBook v2.4.0 — Global Edition"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(appString("তৈরি হয়েছে Jetpack Compose ও Firebase প্রযুক্তিতে", "Built with Jetpack Compose & Firebase"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = VidBookBlue),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(appString("ঠিক আছে", "OK"), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * 6. Help & Support FAQ Dialog
 * Expandable FAQ items answering common questions
 */
@Composable
fun HelpSupportFaqDialog(
    onDismiss: () -> Unit
) {
    val scrollState = rememberScrollState()

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("help_support_faq_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E88E5).copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.HelpOutline,
                            contentDescription = null,
                            tint = Color(0xFF1E88E5),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = appString("❓ সাহায্য ও সাপোর্ট (FAQ)", "❓ Help & Support (FAQ)"),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = appString("সাধারণ প্রশ্নোত্তর ও ব্যবহারের নিয়মাবলী", "Frequently asked questions & guidelines"),
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(12.dp))

                // FAQ Items
                FaqAccordionItem(
                    question = appString("VidBook এ ভিডিও বা পোস্ট কীভাবে করব?", "How to post or upload videos?"),
                    answer = appString("হোম পেজের উপরের 'ছবি শেয়ার' অথবা 'ভিডিও আপলোড' অপশনে চাপ দিন অথবা নিচের '+' বাটনে চাপ দিয়ে যেকোনো ছবি বা ভিডিও নির্বাচন করে প্রকাশ করুন।", "Tap 'Share Photo' or 'Upload Video' on Home or tap the '+' button on the bottom bar to pick and publish.")
                )

                Spacer(modifier = Modifier.height(8.dp))

                FaqAccordionItem(
                    question = appString("কীভাবে মনিটাইজেশন পাব এবং আয় করব?", "How to get monetized and earn?"),
                    answer = appString("প্রোফাইল থেকে 'মনিটাইজেশন' অপশনে প্রবেশ করুন। লেভেল ৩-এ পৌঁছালে বিজ্ঞাপনী আয় চালু হবে এবং সরাসরি Crypto বা International Withdrawal এর মাধ্যমে উইথড্র করা যাবে।", "Open 'Monetization' from your Profile. Achieving Level 3 enables ad earnings, with withdrawals via Crypto or International Withdrawal.")
                )

                Spacer(modifier = Modifier.height(8.dp))

                FaqAccordionItem(
                    question = appString("কপিরাইট পলিসি এবং স্ট্রাইকের নিয়ম কী?", "What is the copyright policy?"),
                    answer = appString("অন্য কারো কপিরাইট করা গান বা ভিডিও অনুমতি ছাড়া ব্যবহার করবেন না। ৩টি কপিরাইট স্ট্রাইক হলে অ্যাকাউন্ট স্থায়ীভাবে নিষ্ক্রিয় করা হতে পারে।", "Do not use copyrighted music or videos without permission. 3 strikes will permanently terminate the account.")
                )

                Spacer(modifier = Modifier.height(8.dp))

                FaqAccordionItem(
                    question = appString("ডার্ক মোড কীভাবে চালু/বন্ধ করব?", "How do I switch dark mode?"),
                    answer = appString("হোম স্ক্রিনের উপরের তিন ডট মেনু (⋮) অপশনে চাপ দিন এবং 'ডার্ক মোড' টগল সুইচে চাপ দিয়ে যেকোনো সময় ডার্ক বা লাইট মোডে পরিবর্তন করুন।", "Tap the three-dot menu (⋮) on Home and toggle the Dark Mode switch to toggle theme instantly.")
                )

                Spacer(modifier = Modifier.height(8.dp))

                FaqAccordionItem(
                    question = appString("অ্যাকাউন্ট বা পাসওয়ার্ড নিয়ে সমস্যা হলে কী করব?", "Account support & help?"),
                    answer = appString("VidBook সরাসরি নিরাপদ Google Authentication ব্যবহার করে। যেকোনো সহায়তার জন্য আমাদের অফিসিয়াল সাপোর্ট টিমে ইমেইল করুন: support@vidbook.com", "VidBook uses secure Google Authentication. For any questions, contact: support@vidbook.com")
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Support Contact Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = VidBookBlue.copy(alpha = 0.1f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(appString("📧 হেল্পলাইন ও কাস্টমার কেয়ার:", "📧 Customer Helpline:"), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VidBookBlue)
                        Text(appString("support@vidbook.com (২৪/৭ সাপোর্ট পাওয়া যাবে)", "support@vidbook.com (24/7 Support)"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = VidBookBlue),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(appString("বুঝেছি", "Got It"), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun FaqAccordionItem(
    question: String,
    answer: String
) {
    var isExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { isExpanded = !isExpanded },
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
        colors = CardDefaults.cardColors(
            containerColor = if (isExpanded) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surface
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = question,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = VidBookBlue,
                    modifier = Modifier.size(20.dp)
                )
            }
            if (isExpanded) {
                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = answer,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

/**
 * 7. Logout Confirmation Dialog
 * Confirm logout from Google Account
 */
@Composable
fun LogoutConfirmDialog(
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFE53935).copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = Color(0xFFE53935),
                    modifier = Modifier.size(24.dp)
                )
            }
        },
        title = {
            Text(
                text = appString("লগআউট নিশ্চিতকরণ", "Confirm Logout"),
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Text(
                text = appString(
                    "আপনি কি নিশ্চিতভাবে আপনার Google একাউন্ট থেকে লগআউট করতে চান? পুনরায় প্রবেশের জন্য আপনাকে আবার Google দিয়ে লগইন করতে হবে।",
                    "Are you sure you want to sign out from your Google account? You will need to sign in with Google again."
                ),
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(appString("লগআউট করুন", "Sign Out"), fontWeight = FontWeight.Bold, color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(appString("বাতিল", "Cancel"))
            }
        },
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.testTag("logout_confirm_dialog")
    )
}

/**
 * HomeScreen Feed with Stories, Quick Create Post, and Filtered Feed
 */
@Composable
fun HomeScreen(
    currentUser: UserProfile?,
    stories: List<Story>,
    posts: List<Post>,
    featuredVideos: List<Video>,
    onAddStoryClick: () -> Unit,
    onStoryClick: (Story) -> Unit,
    onOpenUpload: () -> Unit,
    onPostLike: (Post) -> Unit,
    onPostComment: (Post) -> Unit,
    onPostShare: (Post) -> Unit,
    onVideoClick: (Video) -> Unit,
    onAuthorClick: (String) -> Unit = {},
    onChannelClick: (String) -> Unit = {},
    feedPreference: FeedPreference = FeedPreference.ALL,
    onFeedPreferenceChange: (FeedPreference) -> Unit = {},
    isDarkMode: Boolean = true,
    onToggleDarkMode: () -> Unit = {},
    notificationsEnabled: Boolean = true,
    onNotificationsEnabledChange: (Boolean) -> Unit = {},
    onLogout: () -> Unit = {},
    searchQuery: String = "",
    onSearchQueryChange: (String) -> Unit = {},
    onShowSnackbar: (String) -> Unit = {},
    onOpenSettings: (() -> Unit)? = null,
    includeTopBar: Boolean = false,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxSize()) {
        // Optional Integrated TopBar if requested
        if (includeTopBar) {
            HomeScreenTopBar(
                searchQuery = searchQuery,
                onSearchQueryChange = onSearchQueryChange,
                isDarkMode = isDarkMode,
                onToggleDarkMode = onToggleDarkMode,
                feedPreference = feedPreference,
                onFeedPreferenceChange = onFeedPreferenceChange,
                notificationsEnabled = notificationsEnabled,
                onNotificationsEnabledChange = onNotificationsEnabledChange,
                onLogout = onLogout,
                onShowSnackbar = onShowSnackbar,
                onOpenSettings = onOpenSettings,
                onOpenUpload = onOpenUpload
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .testTag("home_screen_feed"),
            contentPadding = PaddingValues(bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Active Feed Preference Banner (if not ALL)
            if (feedPreference != FeedPreference.ALL) {
                item {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(10.dp),
                        color = VidBookBlue.copy(alpha = 0.1f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.FilterList,
                                    contentDescription = null,
                                    tint = VidBookBlue,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = appString("ফিড ফিল্টার: ${feedPreference.titleBn}", "Feed Filter: ${feedPreference.titleEn}"),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = VidBookBlue
                                )
                            }
                            Text(
                                text = appString("সব পোস্ট দেখুন ✕", "View All Posts ✕"),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = VidBookBlue,
                                modifier = Modifier.clickable { onFeedPreferenceChange(FeedPreference.ALL) }
                            )
                        }
                    }
                }
            }

            // 1. Stories Row at top (Facebook Style)
            item {
                StoryRow(
                    stories = stories,
                    userAvatarUrl = currentUser?.avatarUrl,
                    onAddStoryClick = onAddStoryClick,
                    onStoryClick = onStoryClick
                )
            }

            // 2. Facebook-style "What's on your mind?" quick create box
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp)
                        .clickable(onClick = onOpenUpload)
                        .testTag("quick_create_post_card"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AsyncImage(
                                model = currentUser?.avatarUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&q=80",
                                contentDescription = null,
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(horizontal = 14.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Text(
                                    text = appString("আপনার মাথায় কী চলছে? পোস্ট করুন…", "What's on your mind? Post…"),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 13.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.clickable(onClick = onOpenUpload)
                            ) {
                                Icon(Icons.Default.Image, contentDescription = null, tint = VidBookBlue, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(appString("ছবি শেয়ার", "Share Photo"), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.clickable(onClick = onOpenUpload)
                            ) {
                                Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = VidBookRed, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(appString("ভিডিও আপলোড", "Upload Video"), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            }

            // 3. Social Posts & Featured Videos Feed
            items(posts) { post ->
                SocialPostCard(
                    post = post,
                    onLikeClick = { onPostLike(post) },
                    onCommentClick = { onPostComment(post) },
                    onShareClick = { onPostShare(post) },
                    onAuthorClick = onAuthorClick,
                    modifier = Modifier.padding(horizontal = 10.dp)
                )
            }

            // Trending Video in Home Feed
            if (featuredVideos.isNotEmpty()) {
                item {
                    Column(modifier = Modifier.padding(top = 6.dp)) {
                        Text(
                            text = appString("🔥 জনপ্রিয় ট্রেন্ডিং ভিডিও", "🔥 Popular Trending Videos"),
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                        VideoCard(
                            video = featuredVideos.first(),
                            onClick = { onVideoClick(featuredVideos.first()) },
                            onChannelClick = onChannelClick
                        )
                    }
                }
            }
        }
    }
}
