package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// VidBook Primary Brand Colors (Vibrant Bangladeshi & Social Video Identity)
val VidBookRed = Color(0xFFFF1744)       // Vibrant YouTube Red
val VidBookRedDark = Color(0xFFD50000)
val VidBookBlue = Color(0xFF1877F2)      // Facebook Social Blue
val VidBookBlueDark = Color(0xFF0D47A1)
val VidBookTeal = Color(0xFF00E5FF)

// Dark Theme Colors
val DarkBackground = Color(0xFF0B0E14)
val DarkSurface = Color(0xFF161B26)
val DarkSurfaceVariant = Color(0xFF222938)
val DarkBorder = Color(0xFF2E384D)
val DarkTextPrimary = Color(0xFFF0F4FC)
val DarkTextSecondary = Color(0xFF94A3B8)

// Light Theme Colors
val LightBackground = Color(0xFFF1F5F9)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF8FAFC)
val LightBorder = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)

val StoryGradientStart = Color(0xFFFF007F)
val StoryGradientCenter = Color(0xFFFF7A00)
val StoryGradientEnd = Color(0xFF7928CA)
