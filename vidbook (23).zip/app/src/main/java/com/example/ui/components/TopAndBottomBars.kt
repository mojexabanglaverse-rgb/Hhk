package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.FeedPreference
import com.example.ui.ScreenTab
import com.example.ui.screens.HomeScreenTopBar
import com.example.ui.theme.VidBookBlue
import com.example.ui.theme.VidBookRed
import com.example.ui.util.appString

@Composable
fun VidBookTopBar(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    isDarkMode: Boolean,
    onToggleDarkMode: () -> Unit,
    feedPreference: FeedPreference = FeedPreference.ALL,
    onFeedPreferenceChange: (FeedPreference) -> Unit = {},
    notificationsEnabled: Boolean = true,
    onNotificationsEnabledChange: (Boolean) -> Unit = {},
    onLogout: () -> Unit = {},
    onShowSnackbar: (String) -> Unit = {},
    onOpenSettings: () -> Unit = {},
    onOpenUpload: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    HomeScreenTopBar(
        searchQuery = searchQuery,
        onSearchQueryChange = onSearchQueryChange,
        isDarkMode = isDarkMode,
        onToggleDarkMode = onToggleDarkMode,
        feedPreference = feedPreference,
        onFeedPreferenceChange = onFeedPreferenceChange,
        notificationsEnabled = notificationsEnabled,
        onNotificationsEnabledChange = onNotificationsEnabledChange,
        onLogout = onLogout,
        onShowSnackbar = onShowSnackbar,
        onOpenSettings = onOpenSettings,
        onOpenUpload = onOpenUpload,
        modifier = modifier
    )
}

@Composable
fun VidBookBottomBar(
    currentTab: ScreenTab,
    onTabSelected: (ScreenTab) -> Unit,
    onUploadClick: () -> Unit,
    unreadNotifsCount: Int,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier.testTag("bottom_nav_bar"),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp
    ) {
        // 1. Home (Facebook feed + Stories)
        NavigationBarItem(
            selected = currentTab == ScreenTab.HOME,
            onClick = { onTabSelected(ScreenTab.HOME) },
            icon = {
                Icon(
                    imageVector = if (currentTab == ScreenTab.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                    contentDescription = appString("হোম", "Home")
                )
            },
            label = { Text(appString("হোম", "Home"), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = VidBookBlue,
                selectedTextColor = VidBookBlue,
                indicatorColor = VidBookBlue.copy(alpha = 0.15f)
            )
        )

        // 2. Videos (YouTube Video Feed)
        NavigationBarItem(
            selected = currentTab == ScreenTab.VIDEOS,
            onClick = { onTabSelected(ScreenTab.VIDEOS) },
            icon = {
                Icon(
                    imageVector = if (currentTab == ScreenTab.VIDEOS) Icons.Filled.VideoLibrary else Icons.Outlined.VideoLibrary,
                    contentDescription = appString("ভিডিও", "Videos")
                )
            },
            label = { Text(appString("ভিডিও", "Videos"), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = VidBookRed,
                selectedTextColor = VidBookRed,
                indicatorColor = VidBookRed.copy(alpha = 0.15f)
            )
        )

        // 3. Reels / Shorts
        NavigationBarItem(
            selected = currentTab == ScreenTab.REELS,
            onClick = { onTabSelected(ScreenTab.REELS) },
            icon = {
                Icon(
                    imageVector = if (currentTab == ScreenTab.REELS) Icons.Filled.PlayCircle else Icons.Outlined.PlayCircle,
                    contentDescription = appString("রিলস", "Reels")
                )
            },
            label = { Text(appString("রিলস", "Reels"), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = VidBookRed,
                selectedTextColor = VidBookRed,
                indicatorColor = VidBookRed.copy(alpha = 0.15f)
            )
        )

        // 4. Center Upload Action
        NavigationBarItem(
            selected = false,
            onClick = onUploadClick,
            icon = {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(VidBookRed, VidBookBlue)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AddCircle,
                        contentDescription = appString("পোস্ট বা ভিডিও আপলোড", "Upload Post or Video"),
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            },
            label = { Text(appString("আপলোড", "Upload"), fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1) }
        )

        // 5. Updates & Messages
        NavigationBarItem(
            selected = currentTab == ScreenTab.NOTIFICATIONS,
            onClick = { onTabSelected(ScreenTab.NOTIFICATIONS) },
            icon = {
                BadgedBox(
                    badge = {
                        if (unreadNotifsCount > 0) {
                            Badge(containerColor = VidBookRed) {
                                Text("$unreadNotifsCount", color = Color.White, fontSize = 9.sp)
                            }
                        }
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.Email,
                        contentDescription = appString("বার্তা ও বিজ্ঞপ্তি", "Notifications & Messages")
                    )
                }
            },
            label = { Text(appString("বিজ্ঞপ্তি", "Notifications"), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = VidBookBlue,
                selectedTextColor = VidBookBlue,
                indicatorColor = VidBookBlue.copy(alpha = 0.15f)
            )
        )

        // 6. Profile
        NavigationBarItem(
            selected = currentTab == ScreenTab.PROFILE,
            onClick = { onTabSelected(ScreenTab.PROFILE) },
            icon = {
                Icon(
                    imageVector = if (currentTab == ScreenTab.PROFILE) Icons.Filled.Person else Icons.Outlined.Person,
                    contentDescription = appString("প্রোফাইল", "Profile")
                )
            },
            label = { Text(appString("প্রোফাইল", "Profile"), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = VidBookBlue,
                selectedTextColor = VidBookBlue,
                indicatorColor = VidBookBlue.copy(alpha = 0.15f)
            )
        )
    }
}

