package com.example.ui.util

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import com.example.data.model.AppLanguage

val LocalAppLanguage = compositionLocalOf { AppLanguage.BN }

/**
 * Returns Bengali or English string based on the current LocalAppLanguage.
 * Reacts immediately to language changes in Compose tree.
 */
@Composable
fun appString(bn: String, en: String): String {
    return if (LocalAppLanguage.current == AppLanguage.BN) bn else en
}

/**
 * Comprehensive strings dictionary for VidBook.
 * Contains every single user-facing text across all screens.
 */
object AppStrings {

    fun get(lang: AppLanguage, bn: String, en: String): String {
        return if (lang == AppLanguage.BN) bn else en
    }

    // Number Formatting
    fun formatDigits(numberStr: String, lang: AppLanguage): String {
        if (lang == AppLanguage.EN) return numberStr
        val banglaDigits = mapOf(
            '0' to '০', '1' to '১', '2' to '২', '3' to '৩', '4' to '৪',
            '5' to '৫', '6' to '৬', '7' to '৭', '8' to '৮', '9' to '৯',
            '.' to '.'
        )
        return numberStr.map { banglaDigits[it] ?: it }.joinToString("")
    }

    fun formatViews(views: Long, lang: AppLanguage): String {
        return if (lang == AppLanguage.EN) {
            when {
                views >= 1_000_000 -> String.format("%.1fM views", views / 1_000_000.0)
                views >= 1_000 -> String.format("%.1fK views", views / 1_000.0)
                else -> "$views views"
            }
        } else {
            when {
                views >= 1_000_000 -> formatDigits(String.format("%.1f", views / 1_000_000.0), lang) + " মিলিয়ন ভিউজ"
                views >= 100_000 -> formatDigits(String.format("%.1f", views / 100_000.0), lang) + " লাখ ভিউজ"
                views >= 1_000 -> formatDigits(String.format("%.1f", views / 1_000.0), lang) + " হাজার ভিউজ"
                else -> formatDigits(views.toString(), lang) + " ভিউজ"
            }
        }
    }

    // 1. Navigation Bottom Bar
    fun navHome(lang: AppLanguage) = get(lang, "হোম", "Home")
    fun navVideos(lang: AppLanguage) = get(lang, "ভিডিও", "Videos")
    fun navReels(lang: AppLanguage) = get(lang, "রিলস", "Reels")
    fun navUpload(lang: AppLanguage) = get(lang, "আপলোড", "Upload")
    fun navNotifications(lang: AppLanguage) = get(lang, "বিজ্ঞপ্তি", "Notifications")
    fun navProfile(lang: AppLanguage) = get(lang, "প্রোফাইল", "Profile")

    // 2. TopBar & Quick 3-Dot Menu
    fun appBrandSubtitle(lang: AppLanguage) = get(lang, "বাংলাদেশ", "Bangladesh")
    fun quickMenuHeader(lang: AppLanguage) = get(lang, "VidBook কুইক মেনু", "VidBook Quick Menu")
    fun search(lang: AppLanguage) = get(lang, "সার্চ", "Search")
    fun searchSubtitle(lang: AppLanguage) = get(lang, "পোস্ট, ভিডিও ও বন্ধু খুঁজুন", "Search posts, videos & friends")
    fun searchPlaceholder(lang: AppLanguage) = get(lang, "ভিডিও, নাটক, গান বা বন্ধু খুঁজুন…", "Search videos, dramas, songs or friends…")
    fun darkMode(lang: AppLanguage) = get(lang, "ডার্ক মোড", "Dark Mode")
    fun lightMode(lang: AppLanguage) = get(lang, "লাইট মোড", "Light Mode")
    fun darkModeSub(lang: AppLanguage) = get(lang, "রাতের থিমে স্যুইচ করুন", "Switch to night theme")
    fun lightModeSub(lang: AppLanguage) = get(lang, "উজ্জ্বল থিমে স্যুইচ করুন", "Switch to light theme")
    fun feedPreference(lang: AppLanguage) = get(lang, "ফিড প্রেফারেন্স", "Feed Preferences")
    fun feedPreferenceCurrent(pref: String, lang: AppLanguage) = get(lang, "বর্তমান: $pref", "Current: $pref")
    fun notifSetting(lang: AppLanguage) = get(lang, "নোটিফিকেশন সেটিং", "Notification Settings")
    fun notifSettingOn(lang: AppLanguage) = get(lang, "নোটিফিকেশন চালু আছে", "Notifications are active")
    fun notifSettingOff(lang: AppLanguage) = get(lang, "নোটিফিকেশন বন্ধ আছে", "Notifications are muted")
    fun settings(lang: AppLanguage) = get(lang, "সেটিংস", "Settings")
    fun settingsSubtitle(lang: AppLanguage) = get(lang, "মিডিয়া, ক্যাশ ও নিরাপত্তা", "Media, Cache & Privacy")
    fun helpSupport(lang: AppLanguage) = get(lang, "সাহায্য ও সাপোর্ট", "Help & Support")
    fun helpSupportSub(lang: AppLanguage) = get(lang, "সাধারণ প্রশ্নোত্তর (FAQ)", "Frequently Asked Questions (FAQ)")
    fun logout(lang: AppLanguage) = get(lang, "লগআউট", "Logout")
    fun logoutSub(lang: AppLanguage) = get(lang, "Google অ্যাকাউন্ট থেকে বের হন", "Sign out of Google Account")

    // Feed Preferences
    fun feedPrefTitle(lang: AppLanguage) = get(lang, "📋 ফিড প্রেফারেন্স", "📋 Feed Preferences")
    fun feedPrefSub(lang: AppLanguage) = get(lang, "হোমে কোন ধরনের পোস্ট দেখতে চান?", "Choose which posts to display on Home")
    fun feedPrefAll(lang: AppLanguage) = get(lang, "🌐 সব পোস্ট", "🌐 All Posts")
    fun feedPrefAllSub(lang: AppLanguage) = get(lang, "সব ক্রিয়েটরের সামাজিক পোস্ট ও ট্রেন্ডিং ভিডিও", "Social posts and trending videos from all creators")
    fun feedPrefVideos(lang: AppLanguage) = get(lang, "🎬 শুধু ভিডিও", "🎬 Videos Only")
    fun feedPrefVideosSub(lang: AppLanguage) = get(lang, "শুধুমাত্র ভিডিও ও বিনোদনমূলক কনটেন্ট", "Only videos and entertaining watch feed")
    fun feedPrefFriends(lang: AppLanguage) = get(lang, "👥 শুধু বন্ধুদের পোস্ট", "👥 Friends' Posts Only")
    fun feedPrefFriendsSub(lang: AppLanguage) = get(lang, "ভেরিফায়েড ক্রিয়েটর ও বন্ধুদের পোস্ট", "Posts from followed creators and friends")

    // 3. Common Buttons & Modals
    fun cancel(lang: AppLanguage) = get(lang, "বাতিল", "Cancel")
    fun save(lang: AppLanguage) = get(lang, "সংরক্ষণ করুন", "Save")
    fun back(lang: AppLanguage) = get(lang, "ফিরে যান", "Go Back")
    fun ok(lang: AppLanguage) = get(lang, "ঠিক আছে", "OK")
    fun gotIt(lang: AppLanguage) = get(lang, "বুঝেছি", "Got It")
    fun close(lang: AppLanguage) = get(lang, "বন্ধ করুন", "Close")
    fun delete(lang: AppLanguage) = get(lang, "মুছে দিন", "Delete")
    fun clear(lang: AppLanguage) = get(lang, "মুছুন", "Clear")
    fun edit(lang: AppLanguage) = get(lang, "এডিট", "Edit")
    fun share(lang: AppLanguage) = get(lang, "শেয়ার", "Share")
    fun like(lang: AppLanguage) = get(lang, "লাইক", "Like")
    fun comment(lang: AppLanguage) = get(lang, "মন্তব্য", "Comment")
    fun follow(lang: AppLanguage) = get(lang, "ফলো", "Follow")
    fun following(lang: AppLanguage) = get(lang, "ফলো করছেন", "Following")
    fun subscribe(lang: AppLanguage) = get(lang, "সাবস্ক্রাইব", "Subscribe")
    fun subscribed(lang: AppLanguage) = get(lang, "সাবস্ক্রাইবড", "Subscribed")

    // 4. Home Screen & Feed
    fun whatsOnYourMind(lang: AppLanguage) = get(lang, "আপনার মনে কী আছে লিখুন…", "What's on your mind?…")
    fun sharePhoto(lang: AppLanguage) = get(lang, "ছবি শেয়ার", "Share Photo")
    fun uploadVideo(lang: AppLanguage) = get(lang, "ভিডিও আপলোড", "Upload Video")
    fun addStory(lang: AppLanguage) = get(lang, "স্টোরি দিন", "Add Story")
    fun yourStory(lang: AppLanguage) = get(lang, "আপনার স্টোরি", "Your Story")
    fun postSharedMsg(lang: AppLanguage) = get(lang, "পোস্ট শেয়ার করা হয়েছে!", "Post shared successfully!")

    // 5. Video Screen & Categories
    fun catAll(lang: AppLanguage) = get(lang, "সবগুলো", "All")
    fun catNews(lang: AppLanguage) = get(lang, "সংবাদ", "News")
    fun catNatok(lang: AppLanguage) = get(lang, "বাংলা নাটক", "Bangla Drama")
    fun catShorts(lang: AppLanguage) = get(lang, "শর্টস", "Shorts")
    fun catEntertainment(lang: AppLanguage) = get(lang, "বিনোদন", "Entertainment")
    fun catMusic(lang: AppLanguage) = get(lang, "মিউজিক", "Music")
    fun catTech(lang: AppLanguage) = get(lang, "প্রযুক্তি", "Technology")
    fun catSports(lang: AppLanguage) = get(lang, "খেলাধুলা", "Sports")
    fun catIslamic(lang: AppLanguage) = get(lang, "ইসলামিক", "Islamic")

    fun getCategoryName(category: String, lang: AppLanguage): String {
        return when (category) {
            "সবগুলো" -> catAll(lang)
            "সংবাদ" -> catNews(lang)
            "বাংলা নাটক" -> catNatok(lang)
            "শর্টস" -> catShorts(lang)
            "বিনোদন" -> catEntertainment(lang)
            "মিউজিক" -> catMusic(lang)
            "প্রযুক্তি" -> catTech(lang)
            "খেলাধুলা" -> catSports(lang)
            "ইসলামিক" -> catIslamic(lang)
            else -> category
        }
    }

    // 6. Reels Screen
    fun originalAudio(lang: AppLanguage) = get(lang, "মূল অডিও", "Original Audio")
    fun reelsTitle(lang: AppLanguage) = get(lang, "রিলস", "Reels")

    // 7. Notifications Screen
    fun notificationsTitle(lang: AppLanguage) = get(lang, "বিজ্ঞপ্তি", "Notifications")
    fun markAllAsRead(lang: AppLanguage) = get(lang, "সব পড়া হয়েছে চিহ্নিত করুন", "Mark all as read")
    fun noNotifications(lang: AppLanguage) = get(lang, "কোনো নতুন বিজ্ঞপ্তি নেই", "No new notifications")
    fun allCaughtUp(lang: AppLanguage) = get(lang, "আপনার সব বিজ্ঞপ্তি পড়া শেষ!", "You're all caught up!")

    // 8. Profile Screen
    fun profileTitle(lang: AppLanguage) = get(lang, "প্রোফাইল", "Profile")
    fun editProfile(lang: AppLanguage) = get(lang, "প্রোফাইল এডিট", "Edit Profile")
    fun professionalDashboard(lang: AppLanguage) = get(lang, "প্রফেশনাল ড্যাশবোর্ড", "Professional Dashboard")
    fun monetization(lang: AppLanguage) = get(lang, "মনিটাইজেশন", "Monetization")
    fun copyrightNotices(lang: AppLanguage) = get(lang, "কপিরাইট নোটিশ", "Copyright Notices")
    fun followers(lang: AppLanguage) = get(lang, "ফলোয়ার", "Followers")
    fun totalVideos(lang: AppLanguage) = get(lang, "ভিডিও", "Videos")
    fun tabPosts(lang: AppLanguage) = get(lang, "পোস্টসমূহ", "Posts")
    fun tabVideos(lang: AppLanguage) = get(lang, "ভিডিও", "Videos")
    fun tabAbout(lang: AppLanguage) = get(lang, "সম্পর্কে", "About")
    fun noPostsYet(lang: AppLanguage) = get(lang, "এখনো কোনো পোস্ট নেই", "No posts yet")
    fun noVideosYet(lang: AppLanguage) = get(lang, "এখনো কোনো ভিডিও নেই", "No videos yet")
    fun changeCover(lang: AppLanguage) = get(lang, "কভার ছবি পরিবর্তন", "Change Cover Photo")
    fun changeAvatar(lang: AppLanguage) = get(lang, "প্রোফাইল ছবি পরিবর্তন", "Change Profile Photo")
    fun googleSignInButton(lang: AppLanguage) = get(lang, "🔵 Google দিয়ে সাইন-ইন", "🔵 Sign in with Google")

    // 9. Professional Dashboard
    fun dashboardOverview(lang: AppLanguage) = get(lang, "প্রফেশনাল ওভারভিউ", "Professional Overview")
    fun performanceTitle(lang: AppLanguage) = get(lang, "কনটেন্ট পারফরম্যান্স (গত ২৮ দিন)", "Content Performance (Last 28 Days)")
    fun totalViewsCount(lang: AppLanguage) = get(lang, "মোট ভিউজ", "Total Views")
    fun netFollowersGrowth(lang: AppLanguage) = get(lang, "ফলোয়ার বৃদ্ধি", "Net Followers Growth")
    fun estimatedRevenue(lang: AppLanguage) = get(lang, "আনুমানিক আয়", "Estimated Revenue")
    fun watchTimeHours(lang: AppLanguage) = get(lang, "ওয়াচ টাইম (ঘণ্টা)", "Watch Time (Hours)")
    fun engagement(lang: AppLanguage) = get(lang, "ইঙ্গেজমেন্ট", "Engagement")
    fun creatorTools(lang: AppLanguage) = get(lang, "ক্রিয়েটর টুলস ও ফিচারসমূহ", "Creator Tools & Features")

    // 10. Monetization Screen
    fun monetizationHeader(lang: AppLanguage) = get(lang, "ক্রিয়েটর মনিটাইজেশন ও আয়", "Creator Monetization & Earnings")
    fun monetizationSubtitle(lang: AppLanguage) = get(lang, "বিজ্ঞাপনী আয়, স্টারস, Crypto ও International Withdrawal", "Ad revenue, stars, Crypto and International Withdrawals")
    fun currentBalance(lang: AppLanguage) = get(lang, "উত্তোলনযোগ্য ব্যালেন্স", "Withdrawable Balance")
    fun withdrawBtn(lang: AppLanguage) = get(lang, "উইথড্র করুন", "Withdraw Funds")
    fun criteriaTitle(lang: AppLanguage) = get(lang, "মনিটাইজেশন শর্তাবলী ও অগ্রগতি", "Monetization Criteria & Progress")
    fun methodCrypto(lang: AppLanguage) = get(lang, "Crypto (ক্রিপ্টো)", "Crypto")
    fun methodInternational(lang: AppLanguage) = get(lang, "International Withdrawal (আন্তর্জাতিক)", "International Withdrawal")
    fun withdrawSuccessMsg(lang: AppLanguage) = get(lang, "উইথড্রয়াল আবেদন সফলভাবে গৃহীত হয়েছে!", "Withdrawal request submitted successfully!")

    // 11. Copyright Screen
    fun copyrightHeader(lang: AppLanguage) = get(lang, "কপিরাইট ও স্ট্রাইক সেন্টার", "Copyright & Strike Center")
    fun copyrightSub(lang: AppLanguage) = get(lang, "কমিউনিটি নির্দেশিকা ও কনটেন্ট সুরক্ষা স্ট্যাটাস", "Community guidelines & content safety status")
    fun copyrightStatusTitle(lang: AppLanguage) = get(lang, "কপিরাইট স্ট্যাটাস", "Copyright Status")
    fun fileDisputeBtn(lang: AppLanguage) = get(lang, "আপিল আবেদন করুন", "Submit Appeal")
    fun noticesListTitle(lang: AppLanguage) = get(lang, "কপিরাইট নোটিশসমূহ", "Copyright Notices")
    fun noStrikesMsg(lang: AppLanguage) = get(lang, "আপনার চ্যানেলে কোনো সক্রিয় স্ট্রাইক নেই!", "No active strikes on your channel!")

    // 12. Upload & Post Creation Dialog
    fun uploadModalTitle(lang: AppLanguage) = get(lang, "পোস্ট বা ভিডিও তৈরি করুন", "Create Post or Video")
    fun tabPost(lang: AppLanguage) = get(lang, "পোস্ট", "Post")
    fun tabVideo(lang: AppLanguage) = get(lang, "ভিডিও", "Video")
    fun postInputHint(lang: AppLanguage) = get(lang, "আপনার মনের ভাবনা শেয়ার করুন…", "Share what's on your mind…")
    fun videoTitleHint(lang: AppLanguage) = get(lang, "ভিডিওর শিরোনাম লিখুন…", "Enter video title…")
    fun videoDescHint(lang: AppLanguage) = get(lang, "ভিডিওর বিবরণ (অপশনাল)…", "Video description (optional)…")
    fun selectCategoryHint(lang: AppLanguage) = get(lang, "ক্যাটাগরি নির্বাচন করুন", "Select Category")
    fun copyrightChecking(lang: AppLanguage) = get(lang, "ভিডিওর অডিও ও ভিজ্যুয়াল কপিরাইট চেক করা হচ্ছে…", "Checking video audio & visual copyright…")
    fun copyrightSafe(lang: AppLanguage) = get(lang, "✓ কোনো কপিরাইট সমস্যা পাওয়া যায়নি", "✓ No copyright issues found")
    fun copyrightWarning(lang: AppLanguage) = get(lang, "⚠️ সুরক্ষিত কনটেন্ট শনাক্ত হয়েছে", "⚠️ Protected content detected")
    fun publishNow(lang: AppLanguage) = get(lang, "প্রকাশ করুন", "Publish Now")

    // 13. Comments Bottom Sheet
    fun commentsTitle(count: Int, lang: AppLanguage) = get(
        lang,
        "মন্তব্যসমূহ (${formatDigits(count.toString(), lang)})",
        "Comments ($count)"
    )
    fun writeCommentPlaceholder(lang: AppLanguage) = get(lang, "একটি সুন্দর মন্তব্য লিখুন…", "Write a friendly comment…")
    fun noCommentsYet(lang: AppLanguage) = get(lang, "এখনো কোনো মন্তব্য নেই। প্রথম মন্তব্যটি আপনিই করুন!", "No comments yet. Be the first to comment!")
    fun postCommentBtn(lang: AppLanguage) = get(lang, "মন্তব্য করুন", "Comment")

    // 14. Settings Screen Sections
    fun settingsTitle(lang: AppLanguage) = get(lang, "সেটিংস", "Settings")
    fun privacySettingsTitle(lang: AppLanguage) = get(lang, "১. 🔒 প্রাইভেসি সেটিং", "1. 🔒 Privacy Settings")
    fun languageSettingsTitle(lang: AppLanguage) = get(lang, "২. 🌐 ভাষা পরিবর্তন", "2. 🌐 Language Settings")
    fun dataSaverTitle(lang: AppLanguage) = get(lang, "৩. 📱 ডেটা সেভার মোড", "3. 📱 Data Saver Mode")
    fun blockListTitle(lang: AppLanguage) = get(lang, "৪. 🚫 ব্লক লিস্ট", "4. 🚫 Block List")
    fun notifCustomizationTitle(lang: AppLanguage) = get(lang, "৫. 🔕 নোটিফিকেশন কাস্টমাইজ", "5. 🔕 Notification Customization")
    fun clearCacheTitle(lang: AppLanguage) = get(lang, "৬. 📊 Cache পরিষ্কার", "6. 📊 Clear Cache")
    fun deleteAccountTitle(lang: AppLanguage) = get(lang, "৭. 🔑 অ্যাকাউন্ট মুছে ফেলা", "7. 🔑 Delete Account")

    // Logout & Delete Account Dialogs
    fun logoutDialogTitle(lang: AppLanguage) = get(lang, "লগআউট নিশ্চিতকরণ", "Confirm Logout")
    fun logoutDialogMsg(lang: AppLanguage) = get(
        lang,
        "আপনি কি নিশ্চিতভাবে আপনার Google একাউন্ট থেকে লগআউট করতে চান? পুনরায় প্রবেশের জন্য আপনাকে আবার Google দিয়ে লগইন করতে হবে।",
        "Are you sure you want to sign out from your Google account? You will need to sign in again with Google."
    )
    fun confirmLogoutBtn(lang: AppLanguage) = get(lang, "লগআউট করুন", "Sign Out")
    fun deleteAccountDialogTitle(lang: AppLanguage) = get(lang, "অ্যাকাউন্ট স্থায়ীভাবে মুছে ফেলতে চান?", "Permanently delete account?")
    fun deleteAccountDialogMsg(lang: AppLanguage) = get(
        lang,
        "আপনি কি নিশ্চিত? Firebase Auth ও Firestore থেকে আপনার অ্যাকাউন্ট, পোস্ট, ভিডিও ও সকল ডেটা চিরতরে মুছে যাবে। এই কাজটি আর পূর্বাবস্থায় ফিরিয়ে আনা সম্ভব নয়।",
        "Are you sure? Your account, posts, videos, and all data will be permanently removed from Firebase Auth and Firestore. This action cannot be undone."
    )
    fun confirmDeleteAccountBtn(lang: AppLanguage) = get(lang, "হ্যাঁ, মুছে দিন", "Yes, Delete")
}
