package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Comment
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.example.data.model.Video
import com.example.ui.components.VideoCard
import com.example.ui.components.VideoPlayerView
import com.example.ui.components.formatBanglaViews
import com.example.ui.components.toBanglaDigits
import com.example.ui.theme.VidBookRed
import com.example.ui.util.AppStrings
import com.example.ui.util.LocalAppLanguage
import com.example.ui.util.appString

@Composable
fun VideoDetailScreen(
    video: Video,
    upNextVideos: List<Video>,
    onBack: () -> Unit,
    onLikeClick: () -> Unit,
    onSubscribeClick: () -> Unit,
    onCommentClick: () -> Unit,
    onSelectUpNext: (Video) -> Unit,
    onIncrementViewCount: (String) -> Unit = {},
    onChannelClick: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    BackHandler { onBack() }
    var isDescriptionExpanded by remember { mutableStateOf(false) }
    var isSaved by remember { mutableStateOf(false) }
    var isFullscreen by remember { mutableStateOf(false) }

    // Increment view count in Firebase Firestore and update UI immediately when video starts
    LaunchedEffect(video.id) {
        onIncrementViewCount(video.id)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("video_detail_screen")
    ) {
        // Video Player Container with Back Button
        Box(modifier = Modifier.fillMaxWidth()) {
            VideoPlayerView(
                videoUrl = video.videoUrl,
                thumbnailUrl = video.thumbnailUrl,
                modifier = Modifier.fillMaxWidth(),
                isFullscreen = isFullscreen,
                onToggleFullscreen = { isFullscreen = !isFullscreen }
            )

            // Top overlay back button
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    .testTag("detail_back_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = appString("ফিরে যান", "Back"),
                    tint = Color.White
                )
            }
        }

        // Details & Recommended Videos
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            // Video Title & Views Counter
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Text(
                        text = video.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        lineHeight = 22.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${AppStrings.formatViews(video.viewsCount, LocalAppLanguage.current)} • ${video.timeAgo}",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "#${AppStrings.getCategoryName(video.category, LocalAppLanguage.current)}",
                            color = VidBookRed,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Channel Row with Subscribe Button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = video.channelAvatar,
                            contentDescription = video.channelName,
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .clickable { onChannelClick(video.channelId) },
                            contentScale = ContentScale.Crop
                        )

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onChannelClick(video.channelId) }
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = video.channelName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                if (video.isChannelVerified) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = VidBookRed,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                            Text(
                                text = appString("৮৫০K সাবস্ক্রাইবার", "850K subscribers"),
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Subscribe Button (YouTube Style)
                        Button(
                            onClick = onSubscribeClick,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (video.isSubscribed) MaterialTheme.colorScheme.surfaceVariant else VidBookRed
                            ),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.testTag("detail_subscribe_btn")
                        ) {
                            if (video.isSubscribed) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(appString("সাবস্ক্রাইবড", "Subscribed"), color = MaterialTheme.colorScheme.onSurface, fontSize = 12.sp)
                            } else {
                                Text(appString("সাবস্ক্রাইব", "Subscribe"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Action Buttons Row (Like, Dislike, Share, Save)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        // Like
                        ActionPill(
                            icon = if (video.isLiked) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                            label = AppStrings.formatDigits(video.likesCount.toString(), LocalAppLanguage.current),
                            tint = if (video.isLiked) VidBookRed else MaterialTheme.colorScheme.onSurface,
                            onClick = onLikeClick
                        )

                        // Dislike
                        ActionPill(
                            icon = Icons.Outlined.ThumbDown,
                            label = appString("অপছন্দ", "Dislike"),
                            tint = MaterialTheme.colorScheme.onSurface,
                            onClick = { /* Dislike feedback */ }
                        )

                        // Share
                        ActionPill(
                            icon = Icons.Default.Share,
                            label = appString("শেয়ার", "Share"),
                            tint = MaterialTheme.colorScheme.onSurface,
                            onClick = {
                                val shareIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, "VidBook-এ ভিডিওটি দেখুন: ${video.title}\n${video.videoUrl}")
                                    type = "text/plain"
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share"))
                            }
                        )

                        // Save
                        ActionPill(
                            icon = if (isSaved) Icons.Filled.Bookmark else Icons.Default.BookmarkBorder,
                            label = if (isSaved) appString("সংরক্ষিত", "Saved") else appString("সেভ", "Save"),
                            tint = if (isSaved) VidBookRed else MaterialTheme.colorScheme.onSurface,
                            onClick = { isSaved = !isSaved }
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Expandable Description Box
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isDescriptionExpanded = !isDescriptionExpanded },
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = appString("বিবরণ ও তথ্য", "Description & Info"),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                Text(
                                    text = if (isDescriptionExpanded) appString("সংক্ষিপ্ত করুন", "Show less") else appString("আরও দেখুন…", "Show more…"),
                                    fontSize = 11.sp,
                                    color = VidBookRed
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = video.description,
                                fontSize = 12.sp,
                                lineHeight = 18.sp,
                                maxLines = if (isDescriptionExpanded) 100 else 2,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Comments Preview Card
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(onClick = onCommentClick),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Comment, contentDescription = null, tint = VidBookRed, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(appString("মন্তব্য (২৪৫)", "Comments (245)"), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(appString("চমৎকার নাটক! পরবর্তী পর্ব কবে আসবে?", "Great drama! When is the next episode?"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(appString("সব দেখুন", "View all"), fontSize = 12.sp, color = VidBookRed, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }

            // Up Next Section Header
            item {
                Text(
                    text = appString("পরবর্তী ভিডিওসমূহ", "Up Next"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }

            // Up Next Video Cards
            items(upNextVideos.filter { it.id != video.id }) { nextVideo ->
                VideoCard(
                    video = nextVideo,
                    onClick = { onSelectUpNext(nextVideo) }
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
fun ActionPill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.height(36.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 12.dp)
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = tint, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = label, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = tint)
        }
    }
}
