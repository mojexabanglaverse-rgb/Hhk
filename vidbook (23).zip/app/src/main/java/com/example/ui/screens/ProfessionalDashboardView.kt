package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.example.data.model.AppLanguage
import com.example.data.model.CreatorLevel
import com.example.data.model.CreatorMonetizationState
import com.example.data.model.UserProfile
import com.example.data.model.Video
import com.example.ui.components.toBanglaDigits
import com.example.ui.theme.VidBookBlue
import com.example.ui.theme.VidBookRed
import com.example.ui.util.AppStrings
import com.example.ui.util.LocalAppLanguage
import com.example.ui.util.appString

enum class DashboardTimeRange(val titleBn: String, val titleEn: String) {
    TODAY("আজ", "Today"),
    LAST_7_DAYS("গত ৭ দিন", "Last 7 Days"),
    LAST_28_DAYS("গত ২৮ দিন", "Last 28 Days");

    fun getTitle(lang: AppLanguage): String = if (lang == AppLanguage.BN) titleBn else titleEn
}

data class DashboardMetrics(
    val views: String,
    val viewsChange: String,
    val earnings: String,
    val earningsBdt: String,
    val engagement: String,
    val engagementChange: String,
    val netFollowers: String,
    val netFollowersChange: String,
    val watchTimeMinutes: String,
    val threeSecondViews: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfessionalDashboardView(
    user: UserProfile?,
    topVideos: List<Video>,
    onBack: () -> Unit,
    monetizationState: CreatorMonetizationState = CreatorMonetizationState(),
    onOpenMonetization: () -> Unit = {}
) {
    BackHandler { onBack() }

    val currentLang = LocalAppLanguage.current
    var selectedRangeIndex by remember { mutableIntStateOf(2) } // Default: Last 28 days

    val currentEarnings = monetizationState.totalEarnings
    val dailyEarnings = monetizationState.dailyEarnings
    val followersCount = user?.followersCount ?: 0
    val totalViewsCount = topVideos.sumOf { it.viewsCount }
    val watchTime = (monetizationState.watchTimeHours * 60).toInt()
    val minSuffix = if (currentLang == AppLanguage.BN) "মিনিট" else "mins"

    val metrics = when (selectedRangeIndex) {
        0 -> DashboardMetrics(
            views = if (totalViewsCount > 0) AppStrings.formatDigits((totalViewsCount / 20).toString(), currentLang) else AppStrings.formatDigits("0", currentLang),
            viewsChange = if (totalViewsCount > 0) AppStrings.formatDigits("+8.2%", currentLang) else AppStrings.formatDigits("0%", currentLang),
            earnings = "$${String.format(java.util.Locale.US, "%.2f", dailyEarnings)}",
            earningsBdt = "৳${AppStrings.formatDigits((dailyEarnings * 110).toInt().toString(), currentLang)}",
            engagement = if (followersCount > 0) AppStrings.formatDigits((followersCount / 10).toString(), currentLang) else AppStrings.formatDigits("0", currentLang),
            engagementChange = if (followersCount > 0) AppStrings.formatDigits("+5.4%", currentLang) else AppStrings.formatDigits("0%", currentLang),
            netFollowers = AppStrings.formatDigits(followersCount.toString(), currentLang),
            netFollowersChange = if (followersCount > 0) AppStrings.formatDigits("+12.1%", currentLang) else AppStrings.formatDigits("0%", currentLang),
            watchTimeMinutes = "${AppStrings.formatDigits((if (watchTime > 0) (watchTime / 28) else 0).toString(), currentLang)} $minSuffix",
            threeSecondViews = if (totalViewsCount > 0) AppStrings.formatDigits((totalViewsCount / 25).toString(), currentLang) else AppStrings.formatDigits("0", currentLang)
        )
        1 -> DashboardMetrics(
            views = if (totalViewsCount > 0) AppStrings.formatDigits((totalViewsCount / 4).toString(), currentLang) else AppStrings.formatDigits("0", currentLang),
            viewsChange = if (totalViewsCount > 0) AppStrings.formatDigits("+14.5%", currentLang) else AppStrings.formatDigits("0%", currentLang),
            earnings = "$${String.format(java.util.Locale.US, "%.2f", (dailyEarnings * 7).coerceAtMost(currentEarnings))}",
            earningsBdt = "৳${AppStrings.formatDigits(((dailyEarnings * 7).coerceAtMost(currentEarnings) * 110).toInt().toString(), currentLang)}",
            engagement = if (followersCount > 0) AppStrings.formatDigits((followersCount / 3).toString(), currentLang) else AppStrings.formatDigits("0", currentLang),
            engagementChange = if (followersCount > 0) AppStrings.formatDigits("+9.8%", currentLang) else AppStrings.formatDigits("0%", currentLang),
            netFollowers = AppStrings.formatDigits(followersCount.toString(), currentLang),
            netFollowersChange = if (followersCount > 0) AppStrings.formatDigits("+18.0%", currentLang) else AppStrings.formatDigits("0%", currentLang),
            watchTimeMinutes = "${AppStrings.formatDigits((if (watchTime > 0) (watchTime / 4) else 0).toString(), currentLang)} $minSuffix",
            threeSecondViews = if (totalViewsCount > 0) AppStrings.formatDigits((totalViewsCount / 5).toString(), currentLang) else AppStrings.formatDigits("0", currentLang)
        )
        else -> DashboardMetrics(
            views = AppStrings.formatDigits(totalViewsCount.toString(), currentLang),
            viewsChange = if (totalViewsCount > 0) AppStrings.formatDigits("+18.4%", currentLang) else AppStrings.formatDigits("0%", currentLang),
            earnings = "$${String.format(java.util.Locale.US, "%.2f", currentEarnings)}",
            earningsBdt = "৳${AppStrings.formatDigits((currentEarnings * 110).toInt().toString(), currentLang)}",
            engagement = if (followersCount > 0) AppStrings.formatDigits((followersCount / 2).toString(), currentLang) else AppStrings.formatDigits("0", currentLang),
            engagementChange = if (followersCount > 0) AppStrings.formatDigits("+12.3%", currentLang) else AppStrings.formatDigits("0%", currentLang),
            netFollowers = AppStrings.formatDigits(followersCount.toString(), currentLang),
            netFollowersChange = if (followersCount > 0) AppStrings.formatDigits("+25.6%", currentLang) else AppStrings.formatDigits("0%", currentLang),
            watchTimeMinutes = "${AppStrings.formatDigits(watchTime.toString(), currentLang)} $minSuffix",
            threeSecondViews = AppStrings.formatDigits(totalViewsCount.toString(), currentLang)
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = appString("প্রফেশনাল ড্যাশবোর্ড", "Professional Dashboard"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = appString("ফিরে যান", "Back")
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .testTag("professional_dashboard_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Creator Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = user?.avatarUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80",
                            contentDescription = user?.name,
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = user?.name?.takeIf { it.isNotBlank() } ?: (if (user != null) appString("ব্যবহারকারী", "User") else appString("অতিথি", "Guest")),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                if (user?.isVerified == true) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = VidBookBlue,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                            Text(
                                text = "${appString("ডিজিটাল কনটেন্ট ক্রিয়েটর", "Digital Content Creator")} • ${monetizationState.level.title}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Time Filter Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DashboardTimeRange.values().forEachIndexed { index, range ->
                        FilterChip(
                            selected = selectedRangeIndex == index,
                            onClick = { selectedRangeIndex = index },
                            label = {
                                Text(
                                    text = range.getTitle(currentLang),
                                    fontSize = 12.sp,
                                    fontWeight = if (selectedRangeIndex == index) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = VidBookBlue,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Section Title
            item {
                Text(
                    text = "${appString("পারফরম্যান্স ওভারভিউ", "Performance Overview")} (${DashboardTimeRange.values()[selectedRangeIndex].getTitle(currentLang)})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            // 4 Core Metrics Grid (Views, Earnings, Engagement, Net Followers)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // 1. Views
                        MetricCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.Visibility,
                            iconColor = VidBookBlue,
                            title = appString("ভিউস (Views)", "Views"),
                            value = metrics.views,
                            change = metrics.viewsChange,
                            subLabel = "${appString("৩ সেকেন্ড ভিউ: ", "3s views: ")}${metrics.threeSecondViews}"
                        )

                        // 2. Approximate Earnings
                        MetricCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.MonetizationOn,
                            iconColor = Color(0xFF2E7D32),
                            title = appString("আনুমানিক আয় (Earnings)", "Approx. Earnings"),
                            value = metrics.earnings,
                            change = metrics.earningsBdt,
                            subLabel = appString("ইন-স্ট্রিম অ্যাডস ও স্টারস", "In-Stream Ads & Stars")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // 3. Engagement
                        MetricCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.ThumbUp,
                            iconColor = Color(0xFFE65100),
                            title = appString("এনগেজমেন্ট (Engagement)", "Engagement"),
                            value = metrics.engagement,
                            change = metrics.engagementChange,
                            subLabel = appString("লাইক, কমেন্ট ও শেয়ার", "Likes, comments & shares")
                        )

                        // 4. Net Followers
                        MetricCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.TrendingUp,
                            iconColor = Color(0xFF6A1B9A),
                            title = appString("নেট ফলোয়ার (Net Followers)", "Net Followers"),
                            value = metrics.netFollowers,
                            change = metrics.netFollowersChange,
                            subLabel = "${appString("মোট ফলোয়ার: ", "Total followers: ")}${AppStrings.formatDigits(followersCount.toString(), currentLang)}"
                        )
                    }
                }
            }

            // Watch Time & Retention Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Timeline, contentDescription = null, tint = VidBookRed, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(appString("মোট ওয়াচটাইম", "Total Watch Time"), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                            Text(metrics.watchTimeMinutes, fontWeight = FontWeight.Bold, color = VidBookRed, fontSize = 14.sp)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { 0.76f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = VidBookRed,
                            trackColor = VidBookRed.copy(alpha = 0.2f)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = appString(
                                "গড় দেখার সময়: ২ মিনিট ৪৫ সেকেন্ড (৭৬% অডিয়েন্স রিটেনশন)",
                                "Avg watch time: 2m 45s (76% audience retention)"
                            ),
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Monetization Tools Status Section
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = appString("মনিটাইজেশন ও লেভেল সিস্টেম", "Monetization & Level System"),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = monetizationState.level.badgeColor.copy(alpha = 0.15f),
                            modifier = Modifier.clickable { onOpenMonetization() }
                        ) {
                            Text(
                                text = appString("বিস্তারিত দেখুন >", "View Details >"),
                                color = monetizationState.level.badgeColor,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    // Level Banner Card
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenMonetization() }
                            .testTag("dashboard_monetization_card"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, monetizationState.level.badgeColor.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(monetizationState.level.badgeColor.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = monetizationState.level.badgeEmoji, fontSize = 20.sp)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "Level ${monetizationState.level.levelNumber} — ${monetizationState.level.title}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = if (monetizationState.isSuspended) {
                                            appString("মনিটাইজেশন স্থগিত রয়েছে", "Monetization suspended")
                                        } else {
                                            "${appString("মোট আয়:", "Total Earnings:")} $${String.format("%.2f", monetizationState.totalEarnings)} • ${appString("উত্তোলন সক্রিয়", "Withdrawal Active")}"
                                        },
                                        fontSize = 11.sp,
                                        color = if (monetizationState.isSuspended) VidBookRed else Color(0xFF2E7D32)
                                    )
                                }
                            }

                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                                contentDescription = null,
                                tint = monetizationState.level.badgeColor,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    MonetizationToolItem(
                        title = appString("ইন-স্ট্রিম বিজ্ঞাপন (In-Stream Ads)", "In-Stream Ads"),
                        status = appString("সক্রিয়", "Active"),
                        earnings = "$240.00",
                        icon = Icons.Default.PlayArrow,
                        iconTint = VidBookRed
                    )

                    MonetizationToolItem(
                        title = appString("স্টারস ও ভার্চুয়াল গিফট (Stars)", "Stars & Virtual Gifts"),
                        status = appString("সক্রিয়", "Active"),
                        earnings = "$68.50",
                        icon = Icons.Default.Star,
                        iconTint = Color(0xFFFFB300)
                    )

                    MonetizationToolItem(
                        title = appString("ব্র্যান্ড পার্টনারশিপ ও স্পন্সরশিপ", "Brand Partnership & Sponsorship"),
                        status = appString("অনুমোদিত", "Approved"),
                        earnings = "$34.00",
                        icon = Icons.Default.Campaign,
                        iconTint = VidBookBlue
                    )
                }
            }

            // Top Content List
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = appString("সেরা পারফর্মিং কনটেন্ট (Top Content)", "Top Performing Content"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )

                    if (topVideos.isEmpty()) {
                        Text(
                            text = appString("আপনার আপলোড করা ভিডিওগুলো এখানে প্রদর্শিত হবে।", "Your uploaded videos will be shown here."),
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        topVideos.take(3).forEach { video ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AsyncImage(
                                        model = video.thumbnailUrl,
                                        contentDescription = video.title,
                                        modifier = Modifier
                                            .size(54.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = video.title,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 13.sp,
                                            maxLines = 1
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "${appString("ভিউ: ", "Views: ")}${AppStrings.formatViews(video.viewsCount * 32, currentLang)} • ${appString("আয়: ", "Earnings: ")}$${(video.viewsCount * 0.12).toInt()}.00",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    iconColor: Color,
    title: String,
    value: String,
    change: String,
    subLabel: String
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Medium
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = change,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (change.startsWith("+") || change.startsWith("৳")) Color(0xFF2E7D32) else VidBookBlue
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subLabel,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun MonetizationToolItem(
    title: String,
    status: String,
    earnings: String,
    icon: ImageVector,
    iconTint: Color
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(iconTint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text("${appString("স্ট্যাটাস: ", "Status: ")}$status", fontSize = 11.sp, color = Color(0xFF2E7D32))
            }
            Text(earnings, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}
