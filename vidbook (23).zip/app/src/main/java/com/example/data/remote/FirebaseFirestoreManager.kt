package com.example.data.remote

import android.util.Log
import com.example.data.local.NotificationEntity
import com.example.data.local.PostEntity
import com.example.data.local.VideoEntity
import com.example.data.model.CreatorLevel
import com.example.data.model.CreatorMonetizationState
import com.example.data.model.UserProfile
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

/**
 * Production-ready Firestore Manager for VidBook.
 * Updates user follower counts and video view counts directly in Firebase Firestore.
 */
object FirebaseFirestoreManager {

    private const val TAG = "FirestoreManager"

    private val firestore: FirebaseFirestore? by lazy {
        try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.w(TAG, "Firebase Firestore not initialized or google-services.json missing.", e)
            null
        }
    }

    /**
     * Updates the follower count for a user in Firestore (users/{userId}).
     * Increments by +1 on follow, -1 on unfollow.
     */
    suspend fun updateFollowerCount(userId: String, delta: Long): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val userRef = db.collection("users").document(userId)
            userRef.set(
                mapOf(
                    "followersCount" to FieldValue.increment(delta),
                    "lastUpdated" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()
            Log.d(TAG, "Updated followersCount for $userId by $delta in Firestore")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to update followersCount in Firestore for $userId", e)
            Result.failure(e)
        }
    }

    /**
     * Updates full user profile details in Firestore (users/{userId}).
     */
    suspend fun updateUserProfileInFirestore(
        userId: String,
        name: String,
        username: String,
        bio: String,
        avatarUrl: String? = null,
        coverUrl: String? = null
    ): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val userRef = db.collection("users").document(userId)
            val data = mutableMapOf<String, Any?>(
                "name" to name,
                "username" to username,
                "bio" to bio,
                "lastUpdated" to FieldValue.serverTimestamp()
            )
            if (!avatarUrl.isNullOrBlank()) data["avatarUrl"] = avatarUrl
            if (!coverUrl.isNullOrBlank()) data["coverUrl"] = coverUrl
            userRef.set(data, SetOptions.merge()).await()
            Log.d(TAG, "Updated user profile for $userId in Firestore")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to update profile in Firestore for $userId", e)
            Result.failure(e)
        }
    }

    /**
     * Increments the view count for a video in Firestore (videos/{videoId}).
     */
    suspend fun incrementVideoViewCount(videoId: String): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val videoRef = db.collection("videos").document(videoId)
            videoRef.set(
                mapOf(
                    "viewsCount" to FieldValue.increment(1),
                    "lastViewed" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()
            Log.d(TAG, "Incremented viewsCount for $videoId in Firestore")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to increment viewsCount in Firestore for $videoId", e)
            Result.failure(e)
        }
    }

    /**
     * Saves or updates a user's copyright status (strikes, upload block, monetization ban) in Firestore.
     */
    suspend fun saveUserCopyrightStatus(
        userId: String,
        strikeCount: Int,
        isUploadBlocked: Boolean,
        uploadBlockedUntil: Long,
        isMonetizationDisabled: Boolean
    ): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val statusRef = db.collection("users").document(userId).collection("copyright").document("status")
            statusRef.set(
                mapOf(
                    "strikeCount" to strikeCount,
                    "isUploadBlocked" to isUploadBlocked,
                    "uploadBlockedUntil" to uploadBlockedUntil,
                    "isMonetizationDisabled" to isMonetizationDisabled,
                    "lastUpdated" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()
            Log.d(TAG, "Saved copyright status for $userId in Firestore: strikes=$strikeCount")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to save copyright status for $userId in Firestore", e)
            Result.failure(e)
        }
    }

    /**
     * Saves a copyright notice for a user in Firestore (users/{userId}/copyright_notices/{noticeId}).
     */
    suspend fun saveCopyrightNotice(
        userId: String,
        noticeId: String,
        videoTitle: String,
        thumbnailUrl: String? = null,
        copyrightOwner: String,
        matchType: String,
        strikeNumber: Int,
        status: String,
        date: String,
        timestamp: Long,
        penaltyDescription: String
    ): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val noticeRef = db.collection("users").document(userId)
                .collection("copyright_notices").document(noticeId)
            val data = mutableMapOf<String, Any?>(
                "id" to noticeId,
                "userId" to userId,
                "videoTitle" to videoTitle,
                "copyrightOwner" to copyrightOwner,
                "matchType" to matchType,
                "strikeNumber" to strikeNumber,
                "status" to status,
                "date" to date,
                "timestamp" to timestamp,
                "penaltyDescription" to penaltyDescription,
                "createdAt" to FieldValue.serverTimestamp()
            )
            if (!thumbnailUrl.isNullOrBlank()) {
                data["thumbnailUrl"] = thumbnailUrl
            }
            noticeRef.set(data, SetOptions.merge()).await()
            Log.d(TAG, "Saved copyright notice $noticeId for $userId in Firestore")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to save copyright notice in Firestore", e)
            Result.failure(e)
        }
    }

    /**
     * Updates dispute reason for a copyright notice in Firestore.
     */
    suspend fun submitDisputeInFirestore(
        userId: String,
        noticeId: String,
        disputeReason: String
    ): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val noticeRef = db.collection("users").document(userId)
                .collection("copyright_notices").document(noticeId)
            noticeRef.set(
                mapOf(
                    "status" to "DISPUTED",
                    "disputeReason" to disputeReason,
                    "disputedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Saves complete Monetization status in Firebase Firestore (users/{userId}/monetization/status).
     * Includes level, watchTimeMinutes, followersCount, strikeCount, monetizationStatus, earnings.
     */
    suspend fun saveMonetizationState(
        userId: String,
        level: Int,
        watchTimeMinutes: Long,
        followersCount: Int,
        strikeCount: Int,
        monetizationStatus: String,
        totalEarnings: Double,
        dailyEarnings: Double,
        isSuspended: Boolean
    ): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val docRef = db.collection("users").document(userId)
                .collection("monetization").document("status")
            docRef.set(
                mapOf(
                    "level" to level,
                    "watchTimeMinutes" to watchTimeMinutes,
                    "followersCount" to followersCount,
                    "strikeCount" to strikeCount,
                    "monetizationStatus" to monetizationStatus,
                    "earnings" to mapOf(
                        "total" to totalEarnings,
                        "daily" to dailyEarnings
                    ),
                    "isSuspended" to isSuspended,
                    "lastUpdated" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()
            Log.d(TAG, "Saved monetization state for $userId: Level $level, status=$monetizationStatus")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to save monetization state for $userId in Firestore", e)
            Result.failure(e)
        }
    }

    /**
     * Records a withdrawal in Firebase Firestore (users/{userId}/withdrawals/{withdrawalId}).
     */
    suspend fun recordWithdrawalInFirestore(
        userId: String,
        withdrawalId: String,
        method: String,
        amount: Double,
        destination: String,
        status: String,
        dateFormatted: String
    ): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val docRef = db.collection("users").document(userId)
                .collection("withdrawals").document(withdrawalId)
            docRef.set(
                mapOf(
                    "id" to withdrawalId,
                    "userId" to userId,
                    "method" to method,
                    "amount" to amount,
                    "destination" to destination,
                    "status" to status,
                    "date" to dateFormatted,
                    "timestamp" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()
            Log.d(TAG, "Recorded withdrawal $withdrawalId for $userId: $$amount via $method")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to record withdrawal in Firestore", e)
            Result.failure(e)
        }
    }

    /**
     * Saves a post to Firestore (posts/{postId}).
     */
    suspend fun savePostToFirestore(post: PostEntity): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val data = mapOf(
                "id" to post.id,
                "authorId" to post.authorId,
                "authorName" to post.authorName,
                "authorAvatar" to post.authorAvatar,
                "isAuthorVerified" to post.isAuthorVerified,
                "timeAgo" to post.timeAgo,
                "content" to post.content,
                "imageUrl" to post.imageUrl,
                "videoUrl" to post.videoUrl,
                "likesCount" to post.likesCount,
                "commentsCount" to post.commentsCount,
                "sharesCount" to post.sharesCount,
                "isLiked" to post.isLiked,
                "isSaved" to post.isSaved,
                "timestamp" to post.timestamp
            )
            db.collection("posts").document(post.id).set(data, SetOptions.merge()).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to save post to Firestore", e)
            Result.failure(e)
        }
    }

    /**
     * Fetches all real posts from Firestore.
     */
    suspend fun fetchPostsFromFirestore(): List<PostEntity> {
        val db = firestore ?: return emptyList()
        return try {
            val snapshot = db.collection("posts")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .get()
                .await()
            snapshot.documents.mapNotNull { doc ->
                val id = doc.getString("id") ?: doc.id
                val authorId = doc.getString("authorId") ?: ""
                val authorName = doc.getString("authorName") ?: ""
                val authorAvatar = doc.getString("authorAvatar") ?: ""
                val isAuthorVerified = doc.getBoolean("isAuthorVerified") ?: false
                val timeAgo = doc.getString("timeAgo") ?: "এইমাত্র"
                val content = doc.getString("content") ?: ""
                val imageUrl = doc.getString("imageUrl")
                val videoUrl = doc.getString("videoUrl")
                val likesCount = doc.getLong("likesCount")?.toInt() ?: 0
                val commentsCount = doc.getLong("commentsCount")?.toInt() ?: 0
                val sharesCount = doc.getLong("sharesCount")?.toInt() ?: 0
                val isLiked = doc.getBoolean("isLiked") ?: false
                val isSaved = doc.getBoolean("isSaved") ?: false
                val timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis()

                PostEntity(
                    id = id,
                    authorId = authorId,
                    authorName = authorName,
                    authorAvatar = authorAvatar,
                    isAuthorVerified = isAuthorVerified,
                    timeAgo = timeAgo,
                    content = content,
                    imageUrl = imageUrl,
                    videoUrl = videoUrl,
                    likesCount = likesCount,
                    commentsCount = commentsCount,
                    sharesCount = sharesCount,
                    isLiked = isLiked,
                    isSaved = isSaved,
                    timestamp = timestamp
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to fetch posts from Firestore", e)
            emptyList()
        }
    }

    /**
     * Saves a video to Firestore (videos/{videoId}).
     */
    suspend fun saveVideoToFirestore(video: VideoEntity): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val data = mapOf(
                "id" to video.id,
                "title" to video.title,
                "description" to video.description,
                "videoUrl" to video.videoUrl,
                "thumbnailUrl" to video.thumbnailUrl,
                "channelId" to video.channelId,
                "channelName" to video.channelName,
                "channelAvatar" to video.channelAvatar,
                "isChannelVerified" to video.isChannelVerified,
                "viewsCount" to video.viewsCount,
                "timeAgo" to video.timeAgo,
                "duration" to video.duration,
                "category" to video.category,
                "likesCount" to video.likesCount,
                "isLiked" to video.isLiked,
                "isSubscribed" to video.isSubscribed,
                "isShort" to video.isShort,
                "timestamp" to video.timestamp
            )
            db.collection("videos").document(video.id).set(data, SetOptions.merge()).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to save video to Firestore", e)
            Result.failure(e)
        }
    }

    /**
     * Fetches all real videos from Firestore.
     */
    suspend fun fetchVideosFromFirestore(): List<VideoEntity> {
        val db = firestore ?: return emptyList()
        return try {
            val snapshot = db.collection("videos")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .get()
                .await()
            snapshot.documents.mapNotNull { doc ->
                val id = doc.getString("id") ?: doc.id
                val title = doc.getString("title") ?: ""
                val description = doc.getString("description") ?: ""
                val videoUrl = doc.getString("videoUrl") ?: ""
                val thumbnailUrl = doc.getString("thumbnailUrl") ?: ""
                val channelId = doc.getString("channelId") ?: ""
                val channelName = doc.getString("channelName") ?: ""
                val channelAvatar = doc.getString("channelAvatar") ?: ""
                val isChannelVerified = doc.getBoolean("isChannelVerified") ?: false
                val viewsCount = doc.getLong("viewsCount") ?: 0L
                val timeAgo = doc.getString("timeAgo") ?: "এইমাত্র"
                val duration = doc.getString("duration") ?: "0:00"
                val category = doc.getString("category") ?: "সবগুলো"
                val likesCount = doc.getLong("likesCount")?.toInt() ?: 0
                val isLiked = doc.getBoolean("isLiked") ?: false
                val isSubscribed = doc.getBoolean("isSubscribed") ?: false
                val isShort = doc.getBoolean("isShort") ?: false
                val timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis()

                VideoEntity(
                    id = id,
                    title = title,
                    description = description,
                    videoUrl = videoUrl,
                    thumbnailUrl = thumbnailUrl,
                    channelId = channelId,
                    channelName = channelName,
                    channelAvatar = channelAvatar,
                    isChannelVerified = isChannelVerified,
                    viewsCount = viewsCount,
                    timeAgo = timeAgo,
                    duration = duration,
                    category = category,
                    likesCount = likesCount,
                    isLiked = isLiked,
                    isSubscribed = isSubscribed,
                    isShort = isShort,
                    timestamp = timestamp
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to fetch videos from Firestore", e)
            emptyList()
        }
    }

    /**
     * Fetches user profile from Firestore (users/{userId}).
     */
    suspend fun fetchUserProfileFromFirestore(userId: String): UserProfile? {
        val db = firestore ?: return null
        return try {
            val doc = db.collection("users").document(userId).get().await()
            if (doc.exists()) {
                UserProfile(
                    id = userId,
                    name = doc.getString("name") ?: "",
                    username = doc.getString("username") ?: "",
                    email = doc.getString("email") ?: "",
                    bio = doc.getString("bio") ?: "",
                    avatarUrl = doc.getString("avatarUrl") ?: "",
                    coverUrl = doc.getString("coverUrl") ?: "",
                    followersCount = doc.getLong("followersCount")?.toInt() ?: 0,
                    followingCount = doc.getLong("followingCount")?.toInt() ?: 0,
                    subscribersCount = doc.getLong("subscribersCount")?.toInt() ?: 0,
                    totalVideos = doc.getLong("totalVideos")?.toInt() ?: 0,
                    isVerified = doc.getBoolean("isVerified") ?: false
                )
            } else {
                null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to fetch user profile for $userId from Firestore", e)
            null
        }
    }

    /**
     * Fetches monetization state from Firestore (users/{userId}/monetization/status).
     */
    suspend fun fetchMonetizationFromFirestore(userId: String): CreatorMonetizationState? {
        val db = firestore ?: return null
        return try {
            val doc = db.collection("users").document(userId)
                .collection("monetization").document("status").get().await()
            if (doc.exists()) {
                val levelNum = doc.getLong("level")?.toInt() ?: 0
                val level = CreatorLevel.values().find { it.levelNumber == levelNum } ?: CreatorLevel.LEVEL_0
                val watchTimeMinutes = doc.getLong("watchTimeMinutes") ?: 0L
                val followersCount = doc.getLong("followersCount")?.toInt() ?: 0
                val strikeCount = doc.getLong("strikeCount")?.toInt() ?: 0
                val isSuspended = doc.getBoolean("isSuspended") ?: (strikeCount >= 3)
                val earningsMap = doc.get("earnings") as? Map<*, *>
                val totalEarnings = (earningsMap?.get("total") as? Number)?.toDouble() ?: 0.0
                val dailyEarnings = (earningsMap?.get("daily") as? Number)?.toDouble() ?: 0.0

                CreatorMonetizationState(
                    level = level,
                    followersCount = followersCount,
                    watchTimeHours = watchTimeMinutes / 60.0,
                    strikeCount = strikeCount,
                    isSuspended = isSuspended,
                    totalEarnings = totalEarnings,
                    dailyEarnings = dailyEarnings
                )
            } else {
                null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to fetch monetization from Firestore for $userId", e)
            null
        }
    }

    /**
     * Updates privacy settings in Firestore (users/{userId}).
     */
    suspend fun updatePrivacySettings(
        userId: String,
        postsVisibility: String,
        whoCanFollowMe: String,
        profileVisibility: String
    ): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val userRef = db.collection("users").document(userId)
            userRef.set(
                mapOf(
                    "privacySettings" to mapOf(
                        "postsVisibility" to postsVisibility,
                        "whoCanFollowMe" to whoCanFollowMe,
                        "profileVisibility" to profileVisibility
                    ),
                    "lastUpdated" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()
            Log.d(TAG, "Updated privacySettings for $userId in Firestore")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to update privacySettings in Firestore for $userId", e)
            Result.failure(e)
        }
    }

    /**
     * Blocks a user by adding targetUserId to blockedUsers array in Firestore.
     */
    suspend fun blockUserInFirestore(userId: String, targetUserId: String): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val userRef = db.collection("users").document(userId)
            userRef.set(
                mapOf(
                    "blockedUsers" to FieldValue.arrayUnion(targetUserId),
                    "lastUpdated" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()
            Log.d(TAG, "Added $targetUserId to blockedUsers in Firestore for $userId")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to block user $targetUserId in Firestore", e)
            Result.failure(e)
        }
    }

    /**
     * Unblocks a user by removing targetUserId from blockedUsers array in Firestore.
     */
    suspend fun unblockUserInFirestore(userId: String, targetUserId: String): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val userRef = db.collection("users").document(userId)
            userRef.update("blockedUsers", FieldValue.arrayRemove(targetUserId)).await()
            Log.d(TAG, "Removed $targetUserId from blockedUsers in Firestore for $userId")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to unblock user $targetUserId in Firestore", e)
            Result.failure(e)
        }
    }

    /**
     * Deletes user document and associated collections from Firestore.
     */
    suspend fun deleteUserFromFirestore(userId: String): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            db.collection("users").document(userId).delete().await()
            Log.d(TAG, "Deleted user document from Firestore: $userId")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to delete user document in Firestore for $userId", e)
            Result.failure(e)
        }
    }
}
