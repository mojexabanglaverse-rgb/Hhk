package com.example.data.model

import androidx.compose.ui.graphics.Color

enum class CreatorLevel(
    val levelNumber: Int,
    val title: String,
    val badgeName: String,
    val badgeEmoji: String,
    val colorHex: Long,
    val unlocks: List<String>
) {
    LEVEL_0(
        levelNumber = 0,
        title = "নতুন Creator",
        badgeName = "সাদা ব্যাজ",
        badgeEmoji = "⚪",
        colorHex = 0xFF9E9E9E,
        unlocks = listOf("ভিডিও আপলোড")
    ),
    LEVEL_1(
        levelNumber = 1,
        title = "উদীয়মান Creator",
        badgeName = "সবুজ ব্যাজ",
        badgeEmoji = "🟢",
        colorHex = 0xFF2E7D32,
        unlocks = listOf("Super Thanks", "Channel Membership")
    ),
    LEVEL_2(
        levelNumber = 2,
        title = "Rising Creator",
        badgeName = "নীল ব্যাজ",
        badgeEmoji = "🔵",
        colorHex = 0xFF1976D2,
        unlocks = listOf("In-stream বিজ্ঞাপন", "Earnings Dashboard")
    ),
    LEVEL_3(
        levelNumber = 3,
        title = "Monetized Creator",
        badgeName = "সোনালি ব্যাজ",
        badgeEmoji = "🌟",
        colorHex = 0xFFFFB300,
        unlocks = listOf("সম্পূর্ণ Monetization", "Withdrawal")
    );

    val badgeColor: Color
        get() = Color(colorHex)
}

enum class WithdrawalCategory(val title: String, val minAmount: Double) {
    CRYPTO("ক্রিপ্টো কারেন্সি", 100.0),
    INTERNATIONAL("আন্তর্জাতিক পেমেন্ট", 50.0)
}

enum class WithdrawalMethod(
    val id: String,
    val displayName: String,
    val networkOrDetails: String,
    val minAmount: Double,
    val category: WithdrawalCategory,
    val placeholder: String
) {
    BTC("btc", "Bitcoin (BTC)", "Bitcoin Network", 100.0, WithdrawalCategory.CRYPTO, "BTC Wallet Address দিন (1..., 3..., bc1...)"),
    ETH("eth", "Ethereum (ETH)", "ERC-20 Network", 100.0, WithdrawalCategory.CRYPTO, "ETH Wallet Address দিন (0x...)"),
    USDT_TRC20("usdt_trc20", "USDT TRC20", "Tron Network (TRC20)", 100.0, WithdrawalCategory.CRYPTO, "TRC20 USDT Address দিন (T...)"),
    USDT_ERC20("usdt_erc20", "USDT ERC20", "Ethereum Network (ERC20)", 100.0, WithdrawalCategory.CRYPTO, "ERC20 USDT Address দিন (0x...)"),
    BNB("bnb", "BNB (Binance Coin)", "BNB Smart Chain (BEP20)", 100.0, WithdrawalCategory.CRYPTO, "BEP20 BNB Address দিন (0x...)"),

    PAYPAL("paypal", "PayPal", "Instant / 3-5 Business Days", 50.0, WithdrawalCategory.INTERNATIONAL, "PayPal Email Address দিন"),
    PAYONEER("payoneer", "Payoneer", "Global Bank Transfer", 50.0, WithdrawalCategory.INTERNATIONAL, "Payoneer Email বা Payoneer ID দিন"),
    WISE("wise", "Wise (TransferWise)", "Multi-Currency Account", 50.0, WithdrawalCategory.INTERNATIONAL, "Wise Email বা IBAN নম্বর দিন"),
    BANK_WIRE("bank_wire", "Bank Wire Transfer", "SWIFT / Direct Deposit", 50.0, WithdrawalCategory.INTERNATIONAL, "Bank Name, Account No & SWIFT Code দিন")
}

data class WithdrawalRecord(
    val id: String,
    val methodId: String,
    val methodName: String,
    val amount: Double,
    val destination: String,
    val status: String = "Processing (৩-৭ কার্যদিবস)",
    val timestamp: Long = System.currentTimeMillis(),
    val dateFormatted: String
)

data class CreatorMonetizationState(
    val level: CreatorLevel = CreatorLevel.LEVEL_0,
    val followersCount: Int = 0,
    val requiredFollowers: Int = 600,
    val watchTimeHours: Double = 0.0,
    val requiredWatchTimeHours: Double = 3300.0,
    val strikeCount: Int = 0,
    val maxStrikes: Int = 3,
    val accountAgeDays: Int = 1,
    val requiredAccountDays: Int = 30,
    val isSuspended: Boolean = false,
    val totalEarnings: Double = 0.0,
    val dailyEarnings: Double = 0.0,
    val withdrawalHistory: List<WithdrawalRecord> = emptyList(),
    val lastWithdrawalMonthYear: String? = null
)
