package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "posts")
data class PostEntity(
    @PrimaryKey val id: String,
    val authorId: String,
    val authorName: String,
    val authorAvatar: String,
    val isAuthorVerified: Boolean,
    val timeAgo: String,
    val content: String,
    val imageUrl: String?,
    val videoUrl: String?,
    val likesCount: Int,
    val commentsCount: Int,
    val sharesCount: Int,
    val isLiked: Boolean,
    val isSaved: Boolean,
    val timestamp: Long
)

@Entity(tableName = "videos")
data class VideoEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val videoUrl: String,
    val thumbnailUrl: String,
    val channelId: String,
    val channelName: String,
    val channelAvatar: String,
    val isChannelVerified: Boolean,
    val viewsCount: Long,
    val timeAgo: String,
    val duration: String,
    val category: String,
    val likesCount: Int,
    val isLiked: Boolean,
    val isSubscribed: Boolean,
    val isShort: Boolean,
    val copyrightStatus: String = "CLEAR",
    val contentSha256: String = "",
    val timestamp: Long
)

@Entity(tableName = "stories")
data class StoryEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val userName: String,
    val userAvatar: String,
    val mediaUrl: String,
    val isVideo: Boolean,
    val caption: String,
    val timeAgo: String,
    val isSeen: Boolean,
    val timestamp: Long,
    val expiresAt: Long
)

@Entity(tableName = "comments")
data class CommentEntity(
    @PrimaryKey val id: String,
    val targetId: String,
    val authorName: String,
    val authorAvatar: String,
    val text: String,
    val timeAgo: String,
    val likesCount: Int,
    val isLiked: Boolean,
    val timestamp: Long
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val typeString: String,
    val title: String,
    val message: String,
    val avatarUrl: String,
    val timeAgo: String,
    val isRead: Boolean,
    val targetId: String?,
    val timestamp: Long
)
