package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.copyright.data.ContentMatchEntity
import com.example.copyright.data.CopyrightDao
import com.example.copyright.data.CopyrightModerationActionEntity
import com.example.copyright.data.CopyrightReferenceEntity
import com.example.copyright.data.CopyrightScanLogEntity

@Database(
    entities = [
        PostEntity::class,
        VideoEntity::class,
        StoryEntity::class,
        CommentEntity::class,
        NotificationEntity::class,
        CopyrightReferenceEntity::class,
        ContentMatchEntity::class,
        CopyrightScanLogEntity::class,
        CopyrightModerationActionEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class VidBookDatabase : RoomDatabase() {
    abstract fun postDao(): PostDao
    abstract fun videoDao(): VideoDao
    abstract fun storyDao(): StoryDao
    abstract fun commentDao(): CommentDao
    abstract fun notificationDao(): NotificationDao
    abstract fun copyrightDao(): CopyrightDao

    companion object {
        @Volatile
        private var INSTANCE: VidBookDatabase? = null

        fun getDatabase(context: Context): VidBookDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VidBookDatabase::class.java,
                    "vidbook_database"
                ).fallbackToDestructiveMigration()
                 .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
