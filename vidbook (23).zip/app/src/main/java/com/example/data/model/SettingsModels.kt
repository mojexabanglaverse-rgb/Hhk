package com.example.data.model

enum class PostVisibility(val key: String, val titleBn: String, val titleEn: String) {
    PUBLIC("PUBLIC", "সবাই (Public)", "Public"),
    FOLLOWERS("FOLLOWERS", "শুধু ফলোয়ার", "Followers Only"),
    ONLY_ME("ONLY_ME", "শুধু আমি", "Only Me")
}

enum class FollowPermission(val key: String, val titleBn: String, val titleEn: String) {
    EVERYONE("EVERYONE", "সবাই", "Everyone"),
    NO_ONE("NO_ONE", "কেউ না", "No one")
}

enum class ProfileVisibility(val key: String, val titleBn: String, val titleEn: String) {
    EVERYONE("EVERYONE", "সবাই", "Everyone"),
    FOLLOWERS("FOLLOWERS", "শুধু ফলোয়ার", "Followers Only")
}

data class PrivacySettings(
    val postsVisibility: PostVisibility = PostVisibility.PUBLIC,
    val whoCanFollowMe: FollowPermission = FollowPermission.EVERYONE,
    val profileVisibility: ProfileVisibility = ProfileVisibility.EVERYONE
)

enum class AppLanguage(val code: String, val displayName: String) {
    BN("bn", "বাংলা"),
    EN("en", "English")
}

data class BlockedUser(
    val id: String,
    val name: String,
    val username: String,
    val avatarUrl: String
)

data class NotificationPreferences(
    val likeNotifications: Boolean = true,
    val commentNotifications: Boolean = true,
    val followNotifications: Boolean = true,
    val newVideoNotifications: Boolean = true
)
