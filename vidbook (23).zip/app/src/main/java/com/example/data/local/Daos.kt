package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PostDao {
    @Query("SELECT * FROM posts ORDER BY timestamp DESC")
    fun getAllPosts(): Flow<List<PostEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPosts(posts: List<PostEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: PostEntity)

    @Update
    suspend fun updatePost(post: PostEntity)

    @Query("UPDATE posts SET isLiked = :isLiked, likesCount = :likesCount WHERE id = :id")
    suspend fun updateLike(id: String, isLiked: Boolean, likesCount: Int)

    @Query("DELETE FROM posts WHERE id = :id")
    suspend fun deletePost(id: String)

    @Query("DELETE FROM posts WHERE id IN ('post_1', 'post_2', 'post_3') OR id LIKE 'post_%' OR id LIKE 'sample_%' OR authorId IN ('user_bd_01', 'user_sample_01', 'ch_01', 'ch_natok', 'ch_news', 'ch_tech', 'ch_music')")
    suspend fun deleteSamplePosts()

    @Query("DELETE FROM posts")
    suspend fun clearAllPosts()
}

@Dao
interface VideoDao {
    @Query("SELECT * FROM videos WHERE isShort = 0 ORDER BY timestamp DESC")
    fun getLongVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE isShort = 1 ORDER BY timestamp DESC")
    fun getShorts(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE id = :id")
    suspend fun getVideoById(id: String): VideoEntity?

    @Query("SELECT * FROM videos WHERE category = :category AND isShort = 0 ORDER BY timestamp DESC")
    fun getVideosByCategory(category: String): Flow<List<VideoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVideos(videos: List<VideoEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVideo(video: VideoEntity)

    @Query("UPDATE videos SET viewsCount = viewsCount + 1 WHERE id = :id")
    suspend fun incrementViews(id: String)

    @Query("UPDATE videos SET isLiked = :isLiked, likesCount = :likesCount WHERE id = :id")
    suspend fun updateLike(id: String, isLiked: Boolean, likesCount: Int)

    @Query("UPDATE videos SET isSubscribed = :isSubscribed WHERE channelId = :channelId")
    suspend fun updateChannelSubscription(channelId: String, isSubscribed: Boolean)

    @Query("DELETE FROM videos WHERE id IN ('vid_1', 'vid_2', 'vid_3', 'vid_4', 'short_1', 'short_2', 'short_3') OR id LIKE 'vid_%' OR id LIKE 'short_%' OR id LIKE 'sample_%' OR channelId IN ('user_bd_01', 'ch_01', 'ch_natok', 'ch_news', 'ch_tech', 'ch_music')")
    suspend fun deleteSampleVideos()

    @Query("DELETE FROM videos")
    suspend fun clearAllVideos()
}

@Dao
interface StoryDao {
    @Query("SELECT * FROM stories WHERE expiresAt > :currentTime ORDER BY timestamp DESC")
    fun getActiveStories(currentTime: Long): Flow<List<StoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStories(stories: List<StoryEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStory(story: StoryEntity)

    @Query("UPDATE stories SET isSeen = 1 WHERE id = :id")
    suspend fun markSeen(id: String)

    @Query("DELETE FROM stories WHERE id IN ('story_1', 'story_2', 'story_3', 'story_4') OR id LIKE 'story_%' OR id LIKE 'sample_%' OR userId IN ('user_bd_01', 'user_sample_01')")
    suspend fun deleteSampleStories()

    @Query("DELETE FROM stories")
    suspend fun clearAllStories()
}

@Dao
interface CommentDao {
    @Query("SELECT * FROM comments WHERE targetId = :targetId ORDER BY timestamp DESC")
    fun getCommentsForTarget(targetId: String): Flow<List<CommentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComment(comment: CommentEntity)

    @Query("DELETE FROM comments WHERE id IN ('c_1', 'c_2', 'c_3') OR id LIKE 'c_%' OR id LIKE 'sample_%' OR id LIKE 'comment_sample_%'")
    suspend fun deleteSampleComments()

    @Query("DELETE FROM comments")
    suspend fun clearAllComments()
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(notifications: List<NotificationEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: String)

    @Query("UPDATE notifications SET isRead = 1")
    suspend fun markAllAsRead()

    @Query("DELETE FROM notifications WHERE id IN ('notif_1', 'notif_2', 'notif_3', 'notif_4', 'notif_5') OR id LIKE 'notif_%' OR id LIKE 'sample_%' OR targetId IN ('post_1', 'post_2', 'vid_1', 'vid_2', 'short_1', 'monetization')")
    suspend fun deleteSampleNotifications()

    @Query("DELETE FROM notifications")
    suspend fun clearAllNotifications()
}
