package com.example.data.model

data class Post(
    val id: String,
    val authorId: String,
    val authorName: String,
    val authorAvatar: String,
    val isAuthorVerified: Boolean = false,
    val timeAgo: String,
    val content: String,
    val imageUrl: String? = null,
    val videoUrl: String? = null,
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val sharesCount: Int = 0,
    val isLiked: Boolean = false,
    val isSaved: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

data class Video(
    val id: String,
    val title: String,
    val description: String,
    val videoUrl: String,
    val thumbnailUrl: String,
    val channelId: String,
    val channelName: String,
    val channelAvatar: String,
    val isChannelVerified: Boolean = false,
    val viewsCount: Long = 0,
    val timeAgo: String,
    val duration: String,
    val category: String, // नाटक, সংবাদ, শর্টস, বিনোদন, খেলাধুলা, গান
    val likesCount: Int = 0,
    val isLiked: Boolean = false,
    val isSubscribed: Boolean = false,
    val isShort: Boolean = false,
    val copyrightStatus: String = "CLEAR",
    val contentSha256: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class Story(
    val id: String,
    val userId: String,
    val userName: String,
    val userAvatar: String,
    val mediaUrl: String,
    val isVideo: Boolean = false,
    val caption: String = "",
    val timeAgo: String = "এখনই",
    val isSeen: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + 24 * 60 * 60 * 1000L
)

data class Comment(
    val id: String,
    val targetId: String, // Post ID or Video ID
    val authorName: String,
    val authorAvatar: String,
    val text: String,
    val timeAgo: String = "এখনই",
    val likesCount: Int = 0,
    val isLiked: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

data class NotificationItem(
    val id: String,
    val type: NotificationType,
    val title: String,
    val message: String,
    val avatarUrl: String,
    val timeAgo: String,
    val isRead: Boolean = false,
    val targetId: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

enum class NotificationType {
    LIKE,
    COMMENT,
    SUBSCRIBE,
    NEW_VIDEO,
    FOLLOW,
    COPYRIGHT,
    SYSTEM
}

data class UserProfile(
    val id: String,
    val name: String,
    val username: String,
    val email: String,
    val bio: String,
    val avatarUrl: String,
    val coverUrl: String,
    val followersCount: Int = 0,
    val followingCount: Int = 0,
    val subscribersCount: Int = 0,
    val totalVideos: Int = 0,
    val isVerified: Boolean = false
)
