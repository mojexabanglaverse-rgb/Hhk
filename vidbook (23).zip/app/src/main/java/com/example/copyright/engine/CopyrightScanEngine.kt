package com.example.copyright.engine

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.example.copyright.data.ContentMatchEntity
import com.example.copyright.data.CopyrightDao
import com.example.copyright.data.CopyrightReferenceEntity
import com.example.copyright.data.CopyrightScanLogEntity
import com.example.copyright.fingerprint.AudioFingerprintExtractor
import com.example.copyright.fingerprint.PerceptualVideoHasher
import com.example.copyright.fingerprint.Sha256Hasher
import com.example.copyright.fingerprint.TemporalMatcher
import com.example.copyright.model.CandidateVideoFingerprint
import com.example.copyright.model.CopyrightScanEvidence
import com.example.copyright.model.CopyrightStatus
import com.example.copyright.model.FrameFingerprint
import com.example.copyright.model.MatchDecisionType
import com.example.copyright.model.MediaMetadataInfo
import com.example.data.local.VideoDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.util.UUID

/**
 * Production-Grade Copyright and Duplicate Detection Engine for VidBook.
 * Performs media analysis, cryptographic SHA-256 file matching, 2D DCT perceptual
 * video fingerprinting, acoustic sub-band energy audio matching, and temporal alignment.
 */
class CopyrightScanEngine(
    private val context: Context,
    private val copyrightDao: CopyrightDao,
    private val videoDao: VideoDao
) {
    val detectorVersion = "copyright-engine-1.0"

    /**
     * Executes the pre-upload media analysis pipeline.
     */
    suspend fun scanVideo(
        videoUriOrPath: String,
        videoTitle: String,
        candidateVideoId: String = "cand_${System.currentTimeMillis()}",
        onProgress: (stage: String, progress: Float) -> Unit = { _, _ -> }
    ): CopyrightScanEvidence = withContext(Dispatchers.IO) {
        val scanId = "scan_${UUID.randomUUID().toString().take(12)}"

        try {
            onProgress("মিডিয়া ফাইল রিড করা হচ্ছে (Reading media)...", 0.12f)

            // STEP 1: EXTRACT MEDIA METADATA & STREAMING SHA-256
            val metadata = extractMetadataAndHash(videoUriOrPath)
            if (metadata == null) {
                return@withContext createFailureEvidence(
                    scanId = scanId,
                    videoId = candidateVideoId,
                    reason = "মিডিয়া ফাইল রিড করতে ব্যর্থ হয়েছে বা ফাইলটি ক্ষতিগ্রস্ত (Corrupted Media)."
                )
            }

            onProgress("SHA-256 ফাইল হ্যাশ জেনারেট হচ্ছে (Calculating SHA-256)...", 0.28f)

            // STEP 2: EXACT FILE DUPLICATE DETECTION (Cryptographic SHA-256)
            // 2.A: Check Copyright Reference Database
            val refExactMatch = copyrightDao.findReferenceBySha256(metadata.contentSha256)
            if (refExactMatch != null) {
                onProgress("ডুপ্লিকেট ফাইল শনাক্ত হয়েছে (Exact duplicate found)", 1.0f)
                val evidence = CopyrightScanEvidence(
                    scanId = scanId,
                    detectorVersion = detectorVersion,
                    exactSha256Match = true,
                    matchedReferenceId = refExactMatch.id,
                    matchedReferenceTitle = refExactMatch.title,
                    matchType = "EXACT_DUPLICATE",
                    decision = MatchDecisionType.EXACT_DUPLICATE,
                    status = CopyrightStatus.BLOCKED,
                    policyAction = "BLOCK_UPLOAD",
                    audioMatchRatio = 1.0f,
                    audioMatchDurationMs = metadata.durationMs,
                    videoMatchRatio = 1.0f,
                    matchingFrameCount = 10,
                    totalComparedFrames = 10,
                    confidence = 1.0f,
                    matchedSegments = emptyList(),
                    frameHammingDistances = List(10) { 0 },
                    message = "This exact video has already been uploaded.",
                    rawDetails = "SHA-256 Checksum Match: ${metadata.contentSha256} matches Reference ID ${refExactMatch.id}",
                    humanReadableExplanation = "এই ভিডিও ফাইলের SHA-256 ক্রিপ্টোগ্রাফিক হ্যাশ ডাটাবেজে সংরক্ষিত অরিজিনাল ভিডিও '${refExactMatch.title}'-এর সাথে হুবহু মিলে গেছে। একই ভিডিও বার বার আপলোড করা নিষিদ্ধ।"
                )
                logScan(candidateVideoId, evidence, metadata.contentSha256)
                recordMatch(candidateVideoId, refExactMatch.id, evidence)
                return@withContext evidence
            }

            val candidateFile = File(videoUriOrPath)
            if (candidateFile.exists() && candidateFile.length() == 0L) {
                return@withContext createFailureEvidence(
                    scanId = scanId,
                    videoId = candidateVideoId,
                    reason = "ভিডিও ফাইলের সাইজ শূন্য (Empty/Invalid Media File)."
                )
            }

            onProgress("ভিডিও ফ্রেম পারসেপচুয়াল এক্সট্রাকশন (Extracting video frames)...", 0.48f)

            // STEP 3: EXTRACT PERCEPTUAL VIDEO FINGERPRINTS
            val frameFingerprints = PerceptualVideoHasher.sampleVideoFrames(
                context = context,
                videoUriOrPath = videoUriOrPath,
                durationMs = metadata.durationMs,
                sampleCount = 11
            )

            onProgress("অডিও সাব-ব্যান্ড ফিঙ্গারপ্রিন্ট বিশ্লেষণ (Analyzing audio fingerprint)...", 0.68f)

            // STEP 4: EXTRACT AUDIO FINGERPRINTS
            val audioFingerprint = AudioFingerprintExtractor.extractAudioFingerprint(
                context = context,
                mediaUriOrPath = videoUriOrPath,
                estimatedDurationMs = metadata.durationMs
            )

            val candidate = CandidateVideoFingerprint(
                metadata = metadata,
                frameFingerprints = frameFingerprints,
                audioFingerprint = audioFingerprint
            )

            onProgress("কপিরাইট রেজিস্ট্রি ও রেফারেন্স ম্যাচিং (Comparing with copyright registry)...", 0.88f)

            // STEP 5: COMPARE AGAINST REFERENCE & PLATFORM DATABASE
            val references = copyrightDao.getActiveReferencesList()
            var bestReference: CopyrightReferenceEntity? = null
            var bestVideoRatio = 0f
            var bestAudioRatio = 0f
            var bestConfidence = 0f
            var bestMatchedFrames = 0
            var bestTotalFrames = 0
            var bestSegments = emptyList<com.example.copyright.model.MatchedSegment>()
            var bestHammingDistances = emptyList<Int>()
            var bestDecision = MatchDecisionType.NO_MATCH

            for (ref in references) {
                // Parse reference frame fingerprints
                val refFrames = parseReferenceFrames(ref.frameFingerprints)
                val refAcousticHashes = parseReferenceAcousticHashes(ref.audioFingerprint)

                // Temporal Video Perceptual Matching
                val videoMatchResult = TemporalMatcher.match(candidate.frameFingerprints, refFrames)

                // Audio Landmark Cross-correlation Matching
                val audioMatchResult = AudioFingerprintExtractor.compareAudioFingerprints(
                    candidate.audioFingerprint.landmarkHashes,
                    refAcousticHashes
                )

                val vRatio = videoMatchResult.frameMatchRatio
                val aRatio = audioMatchResult.matchRatio

                // Calculate evidence-based confidence score
                val combinedConfidence = when {
                    vRatio >= 0.75f && aRatio >= 0.70f -> (vRatio * 0.5f + aRatio * 0.5f).coerceIn(0f, 1f)
                    vRatio >= 0.65f -> (vRatio * 0.9f).coerceIn(0f, 1f)
                    aRatio >= 0.75f -> (aRatio * 0.85f).coerceIn(0f, 1f)
                    vRatio >= 0.40f -> (vRatio * 0.7f).coerceIn(0f, 1f)
                    else -> 0f
                }

                // Explicit Action Matrix Policy:
                val currentDecision = when {
                    vRatio >= 0.75f && aRatio >= 0.70f -> MatchDecisionType.HIGH_CONFIDENCE_MATCH
                    vRatio >= 0.55f || videoMatchResult.maxContinuousMatchCount >= 4 -> MatchDecisionType.SUBSTANTIAL_MATCH
                    aRatio >= 0.75f && vRatio < 0.35f -> MatchDecisionType.AUDIO_MATCH_ONLY
                    vRatio >= 0.35f || aRatio >= 0.45f -> MatchDecisionType.POSSIBLE_MATCH
                    else -> MatchDecisionType.NO_MATCH
                }

                if (combinedConfidence > bestConfidence && currentDecision != MatchDecisionType.NO_MATCH) {
                    bestConfidence = combinedConfidence
                    bestReference = ref
                    bestVideoRatio = vRatio
                    bestAudioRatio = aRatio
                    bestMatchedFrames = videoMatchResult.matchingFrameCount
                    bestTotalFrames = videoMatchResult.totalComparedFrames
                    bestSegments = videoMatchResult.matchedSegments
                    bestHammingDistances = videoMatchResult.frameHammingDistances
                    bestDecision = currentDecision
                }
            }

            onProgress("কপিরাইট বিশ্লেষণ সম্পন্ন (Finalizing decision)...", 1.0f)

            // STEP 6: SYNTHESIZE DECISION
            if (bestReference != null && bestDecision != MatchDecisionType.NO_MATCH) {
                val status = when (bestDecision) {
                    MatchDecisionType.HIGH_CONFIDENCE_MATCH,
                    MatchDecisionType.SUBSTANTIAL_MATCH,
                    MatchDecisionType.AUDIO_MATCH_ONLY -> CopyrightStatus.BLOCKED
                    MatchDecisionType.POSSIBLE_MATCH -> CopyrightStatus.MANUAL_REVIEW
                    else -> CopyrightStatus.CLEAR
                }

                val policyAction = when (bestDecision) {
                    MatchDecisionType.HIGH_CONFIDENCE_MATCH,
                    MatchDecisionType.SUBSTANTIAL_MATCH -> "BLOCK_UPLOAD"
                    MatchDecisionType.AUDIO_MATCH_ONLY -> "CLAIM_REVENUE"
                    MatchDecisionType.POSSIBLE_MATCH -> "MANUAL_REVIEW"
                    else -> "ALLOW_UPLOAD"
                }

                val matchType = when (bestDecision) {
                    MatchDecisionType.HIGH_CONFIDENCE_MATCH -> "MULTI_MODAL"
                    MatchDecisionType.SUBSTANTIAL_MATCH -> "PERCEPTUAL_VIDEO"
                    MatchDecisionType.AUDIO_MATCH_ONLY -> "AUDIO_ONLY"
                    MatchDecisionType.POSSIBLE_MATCH -> "MULTI_MODAL"
                    else -> "NONE"
                }

                val userExplanation = when (bestDecision) {
                    MatchDecisionType.HIGH_CONFIDENCE_MATCH ->
                        "ভিডিও ও অডিও দুটি মাধ্যমেই '${bestReference.title}'-এর সাথে উচ্চ মাত্রার সাদৃশ্য শনাক্ত হয়েছে (${(bestConfidence * 100).toInt()}% সাদৃশ্য)। স্বত্বাধিকারীর অনুমতি ছাড়া এটি আপলোড করা নিষিদ্ধ।"
                    MatchDecisionType.SUBSTANTIAL_MATCH ->
                        "ভিডিওর উল্লেখযোগ্য অংশ '${bestReference.title}'-এর ফুটেজের সাথে মিলে গেছে ($bestMatchedFrames টি ফ্রেম সাদৃশ্যপূর্ণ)।"
                    MatchDecisionType.AUDIO_MATCH_ONLY ->
                        "ভিডিওটির সাউন্ডট্র্যাক কপিরাইটযুক্ত গান বা মিউজিক '${bestReference.title}'-এর সাথে মিলে গেছে (${(bestAudioRatio * 100).toInt()}% অডিও সাদৃশ্য)।"
                    MatchDecisionType.POSSIBLE_MATCH ->
                        "ভিডিওটিতে সম্ভাব্য কপিরাইটযুক্ত ফুটেজ বা অডিও রয়েছে (${(bestConfidence * 100).toInt()}% সাদৃশ্য)। ম্যানুয়াল পর্যালোচনার প্রয়োজন।"
                    else -> "কপিরাইট শনাক্ত হয়েছে।"
                }

                val evidence = CopyrightScanEvidence(
                    scanId = scanId,
                    detectorVersion = detectorVersion,
                    exactSha256Match = false,
                    matchedReferenceId = bestReference.id,
                    matchedReferenceTitle = bestReference.title,
                    matchType = matchType,
                    decision = bestDecision,
                    status = status,
                    policyAction = policyAction,
                    audioMatchRatio = bestAudioRatio,
                    audioMatchDurationMs = (bestAudioRatio * metadata.durationMs).toLong(),
                    videoMatchRatio = bestVideoRatio,
                    matchingFrameCount = bestMatchedFrames,
                    totalComparedFrames = bestTotalFrames,
                    confidence = bestConfidence,
                    matchedSegments = bestSegments,
                    frameHammingDistances = bestHammingDistances,
                    message = "কপিরাইট বা ডুপ্লিকেট কনটেন্ট শনাক্ত হয়েছে।",
                    rawDetails = "Matched Reference: '${bestReference.title}' (${bestReference.id}), Video Sim: ${(bestVideoRatio * 100).toInt()}%, Audio Sim: ${(bestAudioRatio * 100).toInt()}%, Frames: $bestMatchedFrames/$bestTotalFrames",
                    humanReadableExplanation = userExplanation
                )

                logScan(candidateVideoId, evidence, metadata.contentSha256)
                recordMatch(candidateVideoId, bestReference.id, evidence)
                return@withContext evidence
            }

            // STEP 7: CLEAR (NO MATCH FOUND)
            val clearEvidence = CopyrightScanEvidence(
                scanId = scanId,
                detectorVersion = detectorVersion,
                exactSha256Match = false,
                matchedReferenceId = null,
                matchedReferenceTitle = null,
                matchType = "NONE",
                decision = MatchDecisionType.NO_MATCH,
                status = CopyrightStatus.CLEAR,
                policyAction = "ALLOW_UPLOAD",
                audioMatchRatio = 0f,
                audioMatchDurationMs = 0L,
                videoMatchRatio = 0f,
                matchingFrameCount = 0,
                totalComparedFrames = candidate.frameFingerprints.size,
                confidence = 0f,
                matchedSegments = emptyList(),
                frameHammingDistances = emptyList(),
                message = "Copyright Check Passed (No matches found)",
                rawDetails = "SHA-256: ${metadata.contentSha256}, Frames Extracted: ${candidate.frameFingerprints.size}, Audio Windows: ${candidate.audioFingerprint.landmarkHashes.size}",
                humanReadableExplanation = "কপিরাইট ও ডুপ্লিকেট স্ক্যান সম্পন্ন: কোনো ম্যাচ পাওয়া যায়নি (CLEAR)। ভিডিওটি সফলভাবে আপলোডের জন্য অনুমোদিত।"
            )
            logScan(candidateVideoId, clearEvidence, metadata.contentSha256)
            return@withContext clearEvidence

        } catch (e: Exception) {
            return@withContext createFailureEvidence(
                scanId = scanId,
                videoId = candidateVideoId,
                reason = "স্ক্যান প্রক্রিয়া চলাকালে অপ্রত্যাশিত ত্রুটি: ${e.localizedMessage}"
            )
        }
    }

    private suspend fun logScan(videoId: String, evidence: CopyrightScanEvidence, sha256: String) {
        try {
            copyrightDao.insertScanLog(
                CopyrightScanLogEntity(
                    id = "log_${UUID.randomUUID().toString().take(12)}",
                    videoId = videoId,
                    scanVersion = detectorVersion,
                    sha256 = sha256,
                    audioFingerprintVersion = "sub-band-v1",
                    videoFingerprintVersion = "dct-phash-v1",
                    result = evidence.decision.name,
                    matchedReferenceId = evidence.matchedReferenceId,
                    evidence = evidence.rawDetails,
                    createdAt = System.currentTimeMillis()
                )
            )
        } catch (ignored: Exception) {}
    }

    private suspend fun recordMatch(videoId: String, referenceId: String, evidence: CopyrightScanEvidence) {
        try {
            copyrightDao.insertMatch(
                ContentMatchEntity(
                    id = "match_${UUID.randomUUID().toString().take(12)}",
                    candidateVideoId = videoId,
                    referenceContentId = referenceId,
                    matchType = evidence.decision.name,
                    audioMatchRatio = evidence.audioMatchRatio,
                    videoMatchRatio = evidence.videoMatchRatio,
                    matchedDurationMs = evidence.audioMatchDurationMs,
                    confidence = evidence.confidence,
                    matchedSegments = evidence.matchedSegments.joinToString("; ") {
                        "${it.candidateStartMs}-${it.candidateEndMs}ms (Sim: ${(it.averageSimilarity * 100).toInt()}%)"
                    },
                    createdAt = System.currentTimeMillis()
                )
            )
        } catch (ignored: Exception) {}
    }

    private suspend fun createFailureEvidence(scanId: String, videoId: String, reason: String): CopyrightScanEvidence {
        val evidence = CopyrightScanEvidence(
            scanId = scanId,
            detectorVersion = detectorVersion,
            exactSha256Match = false,
            matchedReferenceId = null,
            matchedReferenceTitle = null,
            decision = MatchDecisionType.SCAN_FAILED,
            status = CopyrightStatus.SCAN_FAILED,
            audioMatchRatio = 0f,
            audioMatchDurationMs = 0L,
            videoMatchRatio = 0f,
            matchingFrameCount = 0,
            totalComparedFrames = 0,
            confidence = 0f,
            matchedSegments = emptyList(),
            message = "স্ক্যান ব্যর্থ হয়েছে: $reason",
            rawDetails = reason
        )
        logScan(videoId, evidence, "0000000000000000000000000000000000000000000000000000000000000000")
        return evidence
    }

    private fun extractMetadataAndHash(uriOrPath: String): MediaMetadataInfo? {
        var inputStream: java.io.InputStream? = null
        var fileSize = 0L
        try {
            val file = File(uriOrPath)
            if (file.exists() && file.isFile) {
                fileSize = file.length()
                inputStream = FileInputStream(file)
            } else if (uriOrPath.startsWith("content://") || uriOrPath.startsWith("android.resource://")) {
                val pfd = context.contentResolver.openFileDescriptor(Uri.parse(uriOrPath), "r")
                fileSize = pfd?.statSize ?: 0L
                pfd?.close()
                inputStream = context.contentResolver.openInputStream(Uri.parse(uriOrPath))
            } else {
                // Online URL or string identifier: compute hash on URI bytes
                val bytes = uriOrPath.toByteArray()
                fileSize = bytes.size.toLong()
                inputStream = bytes.inputStream()
            }

            if (inputStream == null) return null
            val sha256 = Sha256Hasher.computeSha256(inputStream)

            // Extract technical duration and specs using MediaMetadataRetriever
            val retriever = MediaMetadataRetriever()
            var durationMs = 180000L
            var width = 1280
            var height = 720
            var frameRate = 30.0f
            var sampleRate = 44100
            var channels = 2
            var mime = "video/mp4"

            try {
                if (file.exists()) {
                    retriever.setDataSource(uriOrPath)
                } else if (uriOrPath.startsWith("content://")) {
                    retriever.setDataSource(context, Uri.parse(uriOrPath))
                } else {
                    retriever.setDataSource(uriOrPath, HashMap())
                }

                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?.let {
                    durationMs = it
                }
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()?.let {
                    width = it
                }
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()?.let {
                    height = it
                }
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE)?.let {
                    mime = it
                }
            } catch (ignored: Exception) {
            } finally {
                try { retriever.release() } catch (ignored: Exception) {}
            }

            return MediaMetadataInfo(
                contentSha256 = sha256,
                fileSize = fileSize,
                durationMs = durationMs,
                width = width,
                height = height,
                frameRate = frameRate,
                audioSampleRate = sampleRate,
                audioChannels = channels,
                codec = mime,
                containerFormat = mime.substringAfterLast("/", "mp4")
            )
        } catch (e: Exception) {
            return null
        } finally {
            try { inputStream?.close() } catch (ignored: Exception) {}
        }
    }

    private fun parseReferenceFrames(frameString: String): List<FrameFingerprint> {
        if (frameString.isBlank()) return emptyList()
        return frameString.split(";").mapNotNull { token ->
            val parts = token.split(",")
            if (parts.size >= 3) {
                val time = parts[0].toLongOrNull() ?: 0L
                val pHash = parts[1]
                val dHash = parts[2]
                FrameFingerprint(timestampMs = time, positionRatio = 0f, pHashHex = pHash, dHashHex = dHash)
            } else null
        }
    }

    private fun parseReferenceAcousticHashes(audioString: String): List<Long> {
        if (audioString.isBlank()) return emptyList()
        return audioString.split(",").mapNotNull { it.trim().toLongOrNull() }
    }
}
