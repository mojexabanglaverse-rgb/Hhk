package com.example.copyright.fingerprint

import com.example.copyright.model.FrameFingerprint
import com.example.copyright.model.MatchedSegment

/**
 * Temporal Matcher analyzes frame-by-frame perceptual alignment.
 * Detects full and partial video matches, intro/outro additions, and shifted segments.
 */
object TemporalMatcher {

    private const val FRAME_SIMILARITY_THRESHOLD = 0.82f // >= 82% similarity = frame match (Hamming dist <= 11)

    data class TemporalMatchResult(
        val matchingFrameCount: Int,
        val totalComparedFrames: Int,
        val frameMatchRatio: Float,
        val maxContinuousMatchCount: Int,
        val matchedSegments: List<MatchedSegment>,
        val averageSimilarity: Float,
        val frameHammingDistances: List<Int> = emptyList()
    )

    fun match(
        candidateFrames: List<FrameFingerprint>,
        referenceFrames: List<FrameFingerprint>
    ): TemporalMatchResult {
        if (candidateFrames.isEmpty() || referenceFrames.isEmpty()) {
            return TemporalMatchResult(0, 0, 0f, 0, emptyList(), 0f, emptyList())
        }

        var matchingCount = 0
        var totalSimSum = 0f
        val segments = mutableListOf<MatchedSegment>()
        val hammingDistances = mutableListOf<Int>()

        var currentSegmentStartCandidate = -1L
        var currentSegmentEndCandidate = -1L
        var currentSegmentStartRef = -1L
        var currentSegmentEndRef = -1L
        var segmentFrames = 0
        var segmentSimSum = 0f
        var maxContinuous = 0

        // Slide window / compare corresponding or nearest temporal positions
        for (c in candidateFrames) {
            val cHash = PerceptualVideoHasher.hexToHash(c.pHashHex)
            var bestSimForFrame = 0f
            var bestDistForFrame = 64
            var bestRefMatch: FrameFingerprint? = null

            for (r in referenceFrames) {
                val rHash = PerceptualVideoHasher.hexToHash(r.pHashHex)
                val dist = PerceptualVideoHasher.hammingDistance(cHash, rHash)
                val sim = (64 - dist).toFloat() / 64.0f
                if (sim > bestSimForFrame) {
                    bestSimForFrame = sim
                    bestDistForFrame = dist
                    bestRefMatch = r
                }
            }
            hammingDistances.add(bestDistForFrame)

            if (bestSimForFrame >= FRAME_SIMILARITY_THRESHOLD && bestRefMatch != null) {
                matchingCount++
                totalSimSum += bestSimForFrame

                if (segmentFrames == 0) {
                    currentSegmentStartCandidate = c.timestampMs
                    currentSegmentStartRef = bestRefMatch.timestampMs
                }
                currentSegmentEndCandidate = c.timestampMs
                currentSegmentEndRef = bestRefMatch.timestampMs
                segmentFrames++
                segmentSimSum += bestSimForFrame

                if (segmentFrames > maxContinuous) {
                    maxContinuous = segmentFrames
                }
            } else {
                if (segmentFrames >= 2) {
                    segments.add(
                        MatchedSegment(
                            candidateStartMs = currentSegmentStartCandidate,
                            candidateEndMs = currentSegmentEndCandidate,
                            referenceStartMs = currentSegmentStartRef,
                            referenceEndMs = currentSegmentEndRef,
                            frameCount = segmentFrames,
                            averageSimilarity = segmentSimSum / segmentFrames
                        )
                    )
                }
                segmentFrames = 0
                segmentSimSum = 0f
            }
        }

        if (segmentFrames >= 2) {
            segments.add(
                MatchedSegment(
                    candidateStartMs = currentSegmentStartCandidate,
                    candidateEndMs = currentSegmentEndCandidate,
                    referenceStartMs = currentSegmentStartRef,
                    referenceEndMs = currentSegmentEndRef,
                    frameCount = segmentFrames,
                    averageSimilarity = segmentSimSum / segmentFrames
                )
            )
        }

        val totalCompared = candidateFrames.size.coerceAtMost(referenceFrames.size).coerceAtLeast(1)
        val ratio = (matchingCount.toFloat() / totalCompared).coerceIn(0f, 1f)
        val avgSim = if (matchingCount > 0) totalSimSum / matchingCount else 0f

        return TemporalMatchResult(
            matchingFrameCount = matchingCount,
            totalComparedFrames = totalCompared,
            frameMatchRatio = ratio,
            maxContinuousMatchCount = maxContinuous,
            matchedSegments = segments,
            averageSimilarity = avgSim,
            frameHammingDistances = hammingDistances
        )
    }
}
