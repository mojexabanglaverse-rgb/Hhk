package com.example.copyright.model

enum class CopyrightStatus {
    PENDING_SCAN,
    CLEAR,
    POSSIBLE_MATCH,
    MATCH_FOUND,
    BLOCKED,
    MANUAL_REVIEW,
    SCAN_FAILED
}

enum class MatchDecisionType {
    EXACT_DUPLICATE,
    HIGH_CONFIDENCE_MATCH,
    SUBSTANTIAL_MATCH,
    AUDIO_MATCH_ONLY,
    POSSIBLE_MATCH,
    NO_MATCH,
    SCAN_FAILED
}

enum class ReferenceStatus {
    ACTIVE,
    DISABLED,
    REMOVED
}

enum class ModerationActionType {
    CONFIRM_MATCH,
    REJECT_MATCH,
    ALLOW_UPLOAD,
    BLOCK_UPLOAD,
    ADD_TO_REFERENCE_DATABASE
}

data class MediaMetadataInfo(
    val contentSha256: String,
    val fileSize: Long,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val frameRate: Float,
    val audioSampleRate: Int,
    val audioChannels: Int,
    val codec: String,
    val containerFormat: String
)

data class FrameFingerprint(
    val timestampMs: Long,
    val positionRatio: Float, // e.g. 0.0, 0.1, 0.2 ... 1.0
    val pHashHex: String,
    val dHashHex: String
)

data class AudioTrackFingerprint(
    val audioDurationMs: Long,
    val sampleRate: Int,
    val channels: Int,
    val landmarkHashes: List<Long>,
    val energySignatureHex: String
)

data class CandidateVideoFingerprint(
    val metadata: MediaMetadataInfo,
    val frameFingerprints: List<FrameFingerprint>,
    val audioFingerprint: AudioTrackFingerprint,
    val extractionTimestamp: Long = System.currentTimeMillis()
)

data class MatchedSegment(
    val candidateStartMs: Long,
    val candidateEndMs: Long,
    val referenceStartMs: Long,
    val referenceEndMs: Long,
    val frameCount: Int,
    val averageSimilarity: Float
)

data class CopyrightScanEvidence(
    val scanId: String,
    val detectorVersion: String = "copyright-engine-1.0",
    val exactSha256Match: Boolean,
    val matchedReferenceId: String?,
    val matchedReferenceTitle: String?,
    val matchType: String = "NONE", // EXACT_DUPLICATE, MULTI_MODAL, PERCEPTUAL_VIDEO, AUDIO_ONLY, NONE
    val decision: MatchDecisionType,
    val status: CopyrightStatus,
    val policyAction: String = "BLOCK_UPLOAD", // BLOCK_UPLOAD, CLAIM_REVENUE, MANUAL_REVIEW, ALLOW_UPLOAD
    val audioMatchRatio: Float,
    val audioMatchDurationMs: Long,
    val videoMatchRatio: Float,
    val matchingFrameCount: Int,
    val totalComparedFrames: Int,
    val confidence: Float,
    val matchedSegments: List<MatchedSegment>,
    val frameHammingDistances: List<Int> = emptyList(),
    val message: String,
    val rawDetails: String,
    val humanReadableExplanation: String = message,
    val timestamp: Long = System.currentTimeMillis()
)
