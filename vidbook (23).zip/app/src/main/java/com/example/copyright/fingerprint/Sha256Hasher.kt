package com.example.copyright.fingerprint

import java.io.File
import java.io.InputStream
import java.security.MessageDigest

/**
 * High-performance streaming SHA-256 hasher with bounded memory footprint.
 * Reads media files in 16KB chunks to prevent Out-Of-Memory errors on large video files.
 */
object Sha256Hasher {

    private const val BUFFER_SIZE = 16 * 1024 // 16 KB

    fun computeSha256(file: File): String {
        return file.inputStream().use { computeSha256(it) }
    }

    fun computeSha256(inputStream: InputStream): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(BUFFER_SIZE)
        var bytesRead: Int
        while (inputStream.read(buffer).also { bytesRead = it } != -1) {
            digest.update(buffer, 0, bytesRead)
        }
        val hashBytes = digest.digest()
        return bytesToHex(hashBytes)
    }

    fun computeSha256(byteArray: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(byteArray)
        return bytesToHex(digest.digest())
    }

    private fun bytesToHex(bytes: ByteArray): String {
        val sb = StringBuilder(bytes.size * 2)
        for (b in bytes) {
            sb.append(String.format("%02x", b.toInt() and 0xFF))
        }
        return sb.toString()
    }
}
