package com.example.copyright.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(
    tableName = "copyright_references",
    indices = [
        Index(value = ["sha256"]),
        Index(value = ["status"]),
        Index(value = ["ownerId"])
    ]
)
data class CopyrightReferenceEntity(
    @PrimaryKey val id: String,
    val ownerId: String,
    val title: String,
    val source: String,
    val sha256: String,
    val audioFingerprint: String, // Comma-separated list of acoustic hashes
    val videoFingerprint: String, // Representative perceptual hash
    val frameFingerprints: String, // Comma-separated or JSON list of frame hashes
    val durationMs: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val status: String = "ACTIVE" // ACTIVE, DISABLED, REMOVED
)

@Entity(
    tableName = "content_matches",
    indices = [
        Index(value = ["candidateVideoId"]),
        Index(value = ["referenceContentId"]),
        Index(value = ["createdAt"])
    ]
)
data class ContentMatchEntity(
    @PrimaryKey val id: String,
    val candidateVideoId: String,
    val referenceContentId: String,
    val matchType: String,
    val audioMatchRatio: Float,
    val videoMatchRatio: Float,
    val matchedDurationMs: Long,
    val confidence: Float,
    val matchedSegments: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "copyright_scan_logs",
    indices = [
        Index(value = ["videoId"]),
        Index(value = ["sha256"]),
        Index(value = ["createdAt"])
    ]
)
data class CopyrightScanLogEntity(
    @PrimaryKey val id: String,
    val videoId: String,
    val scanVersion: String,
    val sha256: String,
    val audioFingerprintVersion: String,
    val videoFingerprintVersion: String,
    val result: String,
    val matchedReferenceId: String?,
    val evidence: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "copyright_moderation_actions",
    indices = [
        Index(value = ["matchId"]),
        Index(value = ["timestamp"])
    ]
)
data class CopyrightModerationActionEntity(
    @PrimaryKey val id: String,
    val matchId: String,
    val action: String, // CONFIRM_MATCH, REJECT_MATCH, ALLOW_UPLOAD, BLOCK_UPLOAD, ADD_TO_REFERENCE_DATABASE
    val adminNotes: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface CopyrightDao {

    @Query("SELECT * FROM copyright_references WHERE status = 'ACTIVE'")
    fun getActiveReferences(): Flow<List<CopyrightReferenceEntity>>

    @Query("SELECT * FROM copyright_references WHERE status = 'ACTIVE'")
    suspend fun getActiveReferencesList(): List<CopyrightReferenceEntity>

    @Query("SELECT * FROM copyright_references WHERE sha256 = :sha256 AND status = 'ACTIVE' LIMIT 1")
    suspend fun findReferenceBySha256(sha256: String): CopyrightReferenceEntity?

    @Query("SELECT * FROM copyright_references WHERE id = :id LIMIT 1")
    suspend fun getReferenceById(id: String): CopyrightReferenceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReference(reference: CopyrightReferenceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReferences(references: List<CopyrightReferenceEntity>)

    @Query("UPDATE copyright_references SET status = :status, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateReferenceStatus(id: String, status: String, updatedAt: Long = System.currentTimeMillis())

    // Content Matches
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatch(match: ContentMatchEntity)

    @Query("SELECT * FROM content_matches ORDER BY createdAt DESC")
    fun getAllMatches(): Flow<List<ContentMatchEntity>>

    @Query("SELECT * FROM content_matches ORDER BY createdAt DESC")
    suspend fun getAllMatchesList(): List<ContentMatchEntity>

    @Query("SELECT * FROM content_matches WHERE candidateVideoId = :videoId")
    suspend fun getMatchesForVideo(videoId: String): List<ContentMatchEntity>

    // Scan Logs
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScanLog(log: CopyrightScanLogEntity)

    @Query("SELECT * FROM copyright_scan_logs ORDER BY createdAt DESC")
    fun getAllScanLogs(): Flow<List<CopyrightScanLogEntity>>

    // Moderation Actions
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertModerationAction(action: CopyrightModerationActionEntity)

    @Query("SELECT * FROM copyright_moderation_actions ORDER BY timestamp DESC")
    fun getAllModerationActions(): Flow<List<CopyrightModerationActionEntity>>
}
