package com.example.copyright.model

enum class CopyrightNoticeStatus {
    ACTIVE,
    RESOLVED,
    DISPUTED
}

data class CopyrightNotice(
    val id: String,
    val userId: String,
    val videoTitle: String,
    val videoUri: String? = null,
    val thumbnailUrl: String? = null,
    val copyrightOwner: String,
    val matchType: String, // "SHA-256 হুবহু ডুপ্লিকেট", "Visual Fingerprint (ভিজ্যুয়াল ফ্রেম মিল)", "Audio Fingerprint (অডিও মিল)"
    val strikeNumber: Int, // 1, 2, 3
    val status: CopyrightNoticeStatus = CopyrightNoticeStatus.ACTIVE,
    val date: String,
    val timestamp: Long = System.currentTimeMillis(),
    val penaltyDescription: String,
    val disputeReason: String? = null
)

data class UserCopyrightStatus(
    val strikeCount: Int = 0,
    val isUploadBlocked: Boolean = false,
    val uploadBlockedUntil: Long = 0L,
    val isMonetizationDisabled: Boolean = false,
    val lastUpdated: Long = System.currentTimeMillis()
)
