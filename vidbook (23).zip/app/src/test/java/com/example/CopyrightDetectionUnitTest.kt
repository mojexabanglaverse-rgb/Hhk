package com.example

import com.example.copyright.fingerprint.AudioFingerprintExtractor
import com.example.copyright.fingerprint.PerceptualVideoHasher
import com.example.copyright.fingerprint.Sha256Hasher
import com.example.copyright.fingerprint.TemporalMatcher
import com.example.copyright.model.FrameFingerprint
import com.example.copyright.model.MatchDecisionType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CopyrightDetectionUnitTest {

    @Test
    fun testSha256ExactHashingConsistency() {
        val sampleBytes1 = "vidbook_bangla_drama_master_file_content_test".toByteArray()
        val sampleBytes2 = "vidbook_bangla_drama_master_file_content_test".toByteArray()
        val sampleBytesDiff = "vidbook_bangla_drama_master_file_content_modified".toByteArray()

        val hash1 = Sha256Hasher.computeSha256(sampleBytes1)
        val hash2 = Sha256Hasher.computeSha256(sampleBytes2)
        val hashDiff = Sha256Hasher.computeSha256(sampleBytesDiff)

        assertEquals("Same media bytes must produce exact same SHA-256", hash1, hash2)
        assertEquals(64, hash1.length)
        assertNotEquals("Modified bytes must produce different SHA-256", hash1, hashDiff)
    }

    @Test
    fun testHammingDistanceAndSimilarity() {
        val hashA = 0xAAAAAAAAAAAAAAAAUL.toLong() // 10101010...
        val hashB = 0xAAAAAAAAAAAAAAAAUL.toLong() // Exact same
        val hashC = 0xAAAAAAAAAAAAAAA5UL.toLong() // Differ by 2 bits
        val hashInverted = 0x5555555555555555UL.toLong() // All 64 bits differ

        val distSame = PerceptualVideoHasher.hammingDistance(hashA, hashB)
        assertEquals(0, distSame)
        assertEquals(1.0f, PerceptualVideoHasher.similarity(hashA, hashB), 0.001f)

        val dist4 = PerceptualVideoHasher.hammingDistance(hashA, hashC)
        assertEquals(4, dist4)
        assertTrue(PerceptualVideoHasher.similarity(hashA, hashC) >= 0.93f)

        val distAll = PerceptualVideoHasher.hammingDistance(hashA, hashInverted)
        assertEquals(64, distAll)
        assertEquals(0.0f, PerceptualVideoHasher.similarity(hashA, hashInverted), 0.001f)
    }

    @Test
    fun testHexConversion() {
        val original = 0x123456789ABCDEF0UL.toLong()
        val hex = PerceptualVideoHasher.hashToHex(original)
        val decoded = PerceptualVideoHasher.hexToHash(hex)
        assertEquals(original, decoded)
    }

    @Test
    fun testAudioAcousticHashingAndCrossCorrelation() {
        // Generate synthetic audio sample buffer with rising energy profile
        val samplesRising = ShortArray(2048) { (it * 10).toShort() }
        val acousticHash1 = AudioFingerprintExtractor.computeAcousticHash(samplesRising)
        assertTrue("Acoustic hash must be non-zero for non-empty audio", acousticHash1 != 0L)

        // Same audio stream hashes
        val candidateHashes = listOf(100L, 200L, 300L, 400L, 500L, 600L, 700L, 800L)
        val referenceHashes = listOf(100L, 200L, 300L, 400L, 500L, 600L, 700L, 800L)

        val matchExact = AudioFingerprintExtractor.compareAudioFingerprints(candidateHashes, referenceHashes)
        assertEquals(1.0f, matchExact.matchRatio, 0.001f)
        assertTrue(matchExact.confidence >= 0.90f)

        // Shifted audio (e.g. video re-edited with 1 second delay)
        val shiftedReference = listOf(999L, 999L, 100L, 200L, 300L, 400L, 500L, 600L)
        val matchShifted = AudioFingerprintExtractor.compareAudioFingerprints(candidateHashes, shiftedReference)
        assertTrue("Cross-correlation must align shifted audio streams", matchShifted.matchRatio >= 0.70f)
    }

    @Test
    fun testTemporalFrameMatchingContinuousAlignment() {
        val pHash1 = PerceptualVideoHasher.hashToHex(0x1111222233334444L)
        val pHash2 = PerceptualVideoHasher.hashToHex(0x2222333344445555L)
        val pHash3 = PerceptualVideoHasher.hashToHex(0x3333444455556666L)
        val pHash4 = PerceptualVideoHasher.hashToHex(0x4444555566667777L)
        val pHashDiff = PerceptualVideoHasher.hashToHex(0xFFFFFFFFFFFFFFFFUL.toLong())

        val candidateFrames = listOf(
            FrameFingerprint(timestampMs = 0L, positionRatio = 0.0f, pHashHex = pHash1, dHashHex = "0"),
            FrameFingerprint(timestampMs = 1000L, positionRatio = 0.25f, pHashHex = pHash2, dHashHex = "0"),
            FrameFingerprint(timestampMs = 2000L, positionRatio = 0.50f, pHashHex = pHash3, dHashHex = "0"),
            FrameFingerprint(timestampMs = 3000L, positionRatio = 0.75f, pHashHex = pHash4, dHashHex = "0")
        )

        val referenceFrames = listOf(
            FrameFingerprint(timestampMs = 500L, positionRatio = 0.1f, pHashHex = pHash1, dHashHex = "0"),
            FrameFingerprint(timestampMs = 1500L, positionRatio = 0.3f, pHashHex = pHash2, dHashHex = "0"),
            FrameFingerprint(timestampMs = 2500L, positionRatio = 0.5f, pHashHex = pHash3, dHashHex = "0"),
            FrameFingerprint(timestampMs = 3500L, positionRatio = 0.7f, pHashHex = pHash4, dHashHex = "0")
        )

        val matchResult = TemporalMatcher.match(candidateFrames, referenceFrames)
        assertEquals(4, matchResult.matchingFrameCount)
        assertEquals(1.0f, matchResult.frameMatchRatio, 0.001f)
        assertEquals(4, matchResult.maxContinuousMatchCount)
        assertFalse("Matched segments should not be empty for continuous match", matchResult.matchedSegments.isEmpty())

        // Completely dissimilar video
        val dissimilarFrames = listOf(
            FrameFingerprint(timestampMs = 0L, positionRatio = 0.0f, pHashHex = pHashDiff, dHashHex = "0"),
            FrameFingerprint(timestampMs = 1000L, positionRatio = 0.5f, pHashHex = pHashDiff, dHashHex = "0")
        )
        val dissimMatch = TemporalMatcher.match(candidateFrames, dissimilarFrames)
        assertEquals(0, dissimMatch.matchingFrameCount)
        assertEquals(0.0f, dissimMatch.frameMatchRatio, 0.001f)
    }
}
