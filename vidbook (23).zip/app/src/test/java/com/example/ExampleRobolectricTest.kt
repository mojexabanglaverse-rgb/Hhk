package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.vidbook.app.R
import com.example.data.model.Post
import com.example.data.model.Video
import com.example.ui.components.formatBanglaViews
import com.example.ui.components.toBanglaDigits
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun readStringFromContext() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("VidBook", appName)
    }

    @Test
    fun testBanglaDigitFormatting() {
        val formatted = "123".toBanglaDigits()
        assertEquals("১২৩", formatted)
    }

    @Test
    fun testBanglaViewsFormatting() {
        val views1M = formatBanglaViews(1_500_000)
        assertTrue(views1M.contains("মিলিয়ন"))

        val views100K = formatBanglaViews(250_000)
        assertTrue(views100K.contains("লাখ"))
    }

    @Test
    fun testVideoModelCreation() {
        val video = Video(
            id = "test_vid",
            title = "নাটক",
            description = "বিবরণ",
            videoUrl = "https://example.com/stream.mp4",
            thumbnailUrl = "https://example.com/thumb.jpg",
            channelId = "ch_01",
            channelName = "বাংলা চ্যানেল",
            channelAvatar = "https://example.com/avatar.jpg",
            viewsCount = 5000,
            timeAgo = "১ দিন আগে",
            duration = "15:00",
            category = "বাংলা নাটক"
        )
        assertEquals("test_vid", video.id)
        assertEquals("বাংলা নাটক", video.category)
    }

    @Test
    fun testPostModelCreation() {
        val post = Post(
            id = "post_01",
            authorId = "user_01",
            authorName = "তানভীর",
            authorAvatar = "https://example.com/avatar.jpg",
            timeAgo = "এইমাত্র",
            content = "আজকের পোস্ট"
        )
        assertEquals("পোস্ট", post.content.takeLast(5))
    }
}
