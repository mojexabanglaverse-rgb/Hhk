package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.StreamVaultViewModel
import com.example.ui.screens.ApiDocsScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.LiveUploadScreen
import com.example.ui.screens.LockScreen
import com.example.ui.screens.SimulatorScreen
import com.example.ui.theme.MyApplicationTheme

enum class VaultNavTab(
    val title: String,
    val icon: ImageVector,
    val testTag: String
) {
    DASHBOARD("Dashboard", Icons.Default.VideoLibrary, "nav_item_dashboard"),
    LIVE_UPLOADS("Live Upload", Icons.Default.CloudSync, "nav_item_live_upload"),
    API_DOCS("API & Keys", Icons.Default.Security, "nav_item_api_docs"),
    SIMULATOR("API Tester", Icons.Default.SmartDisplay, "nav_item_simulator")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                StreamVaultAppContent()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StreamVaultAppContent(
    viewModel: StreamVaultViewModel = viewModel()
) {
    val isUnlocked by viewModel.isUnlocked.collectAsStateWithLifecycle()

    if (!isUnlocked) {
        LockScreen(viewModel = viewModel)
        return
    }

    var selectedTab by remember { mutableIntStateOf(VaultNavTab.DASHBOARD.ordinal) }
    val isServerRunning by viewModel.isServerRunning.collectAsStateWithLifecycle()
    val activeUploadsCount by viewModel.currentlyUploadingCount.collectAsStateWithLifecycle()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("app_root_scaffold"),
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.PlayCircleOutline,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "StreamVault",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        // Server running dot
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isServerRunning) MaterialTheme.colorScheme.tertiary
                                    else MaterialTheme.colorScheme.error
                                )
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.refreshIpAddress() },
                        modifier = Modifier.testTag("refresh_ip_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh Server Network"
                        )
                    }
                    IconButton(
                        onClick = { viewModel.lockApp() },
                        modifier = Modifier.testTag("lock_app_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Lock StreamVault"
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                VaultNavTab.entries.forEachIndexed { index, tab ->
                    val isSelected = selectedTab == index
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = index },
                        icon = {
                            if (tab == VaultNavTab.LIVE_UPLOADS && activeUploadsCount > 0) {
                                BadgedBox(badge = {
                                    Badge {
                                        Text("$activeUploadsCount")
                                    }
                                }) {
                                    Icon(
                                        imageVector = tab.icon,
                                        contentDescription = tab.title
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.title
                                )
                            }
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.testTag(tab.testTag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(
                targetState = selectedTab,
                label = "screen_crossfade"
            ) { tabIndex ->
                when (tabIndex) {
                    VaultNavTab.DASHBOARD.ordinal -> DashboardScreen(
                        viewModel = viewModel,
                        onNavigateToSimulator = { selectedTab = VaultNavTab.SIMULATOR.ordinal },
                        onNavigateToLiveUploads = { selectedTab = VaultNavTab.LIVE_UPLOADS.ordinal }
                    )
                    VaultNavTab.LIVE_UPLOADS.ordinal -> LiveUploadScreen(
                        viewModel = viewModel,
                        onNavigateToSimulator = { selectedTab = VaultNavTab.SIMULATOR.ordinal }
                    )
                    VaultNavTab.API_DOCS.ordinal -> ApiDocsScreen(
                        viewModel = viewModel
                    )
                    VaultNavTab.SIMULATOR.ordinal -> SimulatorScreen(
                        viewModel = viewModel,
                        onNavigateToDashboard = { selectedTab = VaultNavTab.DASHBOARD.ordinal },
                        onNavigateToLiveUploads = { selectedTab = VaultNavTab.LIVE_UPLOADS.ordinal }
                    )
                }
            }
        }
    }
}
