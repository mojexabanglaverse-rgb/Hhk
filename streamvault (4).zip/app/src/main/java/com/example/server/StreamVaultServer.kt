package com.example.server

import com.example.data.local.VideoEntity
import com.example.data.repository.VideoRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.io.RandomAccessFile
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.util.UUID

class StreamVaultServer(
    private val repository: VideoRepository,
    private val port: Int = 8080
) {
    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private val _serverError = MutableStateFlow<String?>(null)
    val serverError: StateFlow<String?> = _serverError.asStateFlow()

    var requireApiKey: Boolean = true

    fun start() {
        if (_isRunning.value) return
        serverJob = scope.launch {
            try {
                serverSocket = ServerSocket(port)
                _isRunning.value = true
                _serverError.value = null
                UploadTracker.log("StreamVault Server started on port $port")

                while (_isRunning.value && serverSocket?.isClosed == false) {
                    try {
                        val clientSocket = serverSocket?.accept() ?: break
                        scope.launch {
                            handleClient(clientSocket)
                        }
                    } catch (e: Exception) {
                        if (!_isRunning.value) break
                    }
                }
            } catch (e: Exception) {
                _serverError.value = "Failed to start server: ${e.message}"
                UploadTracker.log("Server error: ${e.message}")
                _isRunning.value = false
            }
        }
    }

    fun stop() {
        _isRunning.value = false
        try {
            serverSocket?.close()
            serverSocket = null
        } catch (e: Exception) {
            e.printStackTrace()
        }
        serverJob?.cancel()
        serverJob = null
        UploadTracker.log("StreamVault Server stopped")
    }

    private suspend fun handleClient(socket: Socket) {
        val clientIp = socket.inetAddress?.hostAddress ?: "unknown"
        try {
            socket.soTimeout = 0 // 0 = infinite timeout: never times out during large video uploads
            val rawInput = socket.getInputStream()
            val rawOutput = socket.getOutputStream()

            // Parse request line and headers
            val headers = mutableMapOf<String, String>()
            var requestLine: String? = null
            val headerReader = BufferedReader(InputStreamReader(rawInput, Charsets.UTF_8))
            val headerBytes = ByteArrayOutputStream()

            // Read headers byte-by-byte until \r\n\r\n
            var prev1 = -1
            var prev2 = -1
            var prev3 = -1
            var current: Int
            while (true) {
                current = rawInput.read()
                if (current == -1) break
                headerBytes.write(current)
                if (prev3 == '\r'.code && prev2 == '\n'.code && prev1 == '\r'.code && current == '\n'.code) {
                    break
                }
                prev3 = prev2
                prev2 = prev1
                prev1 = current
            }

            val headerText = headerBytes.toString("UTF-8")
            val lines = headerText.split("\r\n")
            if (lines.isEmpty() || lines[0].isBlank()) {
                socket.close()
                return
            }

            requestLine = lines[0]
            val parts = requestLine.split(" ")
            if (parts.size < 2) {
                socket.close()
                return
            }

            val method = parts[0].uppercase()
            val fullPath = parts[1]

            for (i in 1 until lines.size) {
                val line = lines[i]
                val colonIdx = line.indexOf(':')
                if (colonIdx > 0) {
                    val key = line.substring(0, colonIdx).trim().lowercase()
                    val value = line.substring(colonIdx + 1).trim()
                    headers[key] = value
                }
            }

            // Parse path and query parameters
            val pathParts = fullPath.split("?", limit = 2)
            val path = pathParts[0]
            val queryParams = mutableMapOf<String, String>()
            if (pathParts.size > 1) {
                val pairs = pathParts[1].split("&")
                for (pair in pairs) {
                    val kv = pair.split("=", limit = 2)
                    if (kv.isNotEmpty()) {
                        val k = URLDecoder.decode(kv[0], "UTF-8")
                        val v = if (kv.size > 1) URLDecoder.decode(kv[1], "UTF-8") else ""
                        queryParams[k] = v
                    }
                }
            }

            // Handle CORS preflight
            if (method == "OPTIONS") {
                sendCorsResponse(rawOutput)
                socket.close()
                return
            }

            // Check Authentication if enabled
            if (requireApiKey && !isPublicEndpoint(path)) {
                val apiKey = headers["x-api-key"]
                    ?: headers["authorization"]?.removePrefix("Bearer ")?.trim()
                    ?: queryParams["api_key"]
                    ?: ""

                val isValid = repository.isValidApiKey(apiKey)
                if (!isValid) {
                    sendJsonResponse(
                        rawOutput,
                        401,
                        "Unauthorized",
                        JSONObject().put("error", "Invalid or missing API Key. Pass 'X-API-Key' header or '?api_key=' parameter.")
                    )
                    socket.close()
                    return
                }
            }

            // Route endpoints
            when {
                // GET /api/health or /api/status
                (path == "/api/health" || path == "/api/status") && method == "GET" -> {
                    val videos = repository.allVideos.first()
                    val json = JSONObject().apply {
                        put("status", "ok")
                        put("server", "StreamVault-VideoServer/1.0")
                        put("totalVideos", videos.size)
                        put("activeUploads", UploadTracker.sessions.value.values.count { it.status == UploadStatus.UPLOADING })
                        put("timestamp", System.currentTimeMillis())
                    }
                    sendJsonResponse(rawOutput, 200, "OK", json)
                }

                // GET /api/videos - List all videos
                path == "/api/videos" && method == "GET" -> {
                    val videos = repository.allVideos.first()
                    val array = JSONArray()
                    for (v in videos) {
                        val item = JSONObject().apply {
                            put("id", v.id)
                            put("title", v.title)
                            put("description", v.description)
                            put("fileSizeBytes", v.fileSizeBytes)
                            put("formattedSize", NetworkUtils.formatBytes(v.fileSizeBytes))
                            put("mimeType", v.mimeType)
                            put("durationSeconds", v.durationSeconds)
                            put("createdAt", v.createdAt)
                            put("uploaderApp", v.uploaderApp)
                            put("streamUrl", "/api/videos/${v.id}/stream")
                        }
                        array.put(item)
                    }
                    val json = JSONObject().apply {
                        put("success", true)
                        put("count", videos.size)
                        put("videos", array)
                    }
                    sendJsonResponse(rawOutput, 200, "OK", json)
                }

                // GET /api/videos/{id} - Single video info
                path.matches(Regex("^/api/videos/[a-zA-Z0-9_-]+$")) && method == "GET" -> {
                    val videoId = path.substringAfterLast("/")
                    val video = repository.getVideoById(videoId)
                    if (video != null) {
                        val json = JSONObject().apply {
                            put("id", video.id)
                            put("title", video.title)
                            put("description", video.description)
                            put("fileSizeBytes", video.fileSizeBytes)
                            put("formattedSize", NetworkUtils.formatBytes(video.fileSizeBytes))
                            put("mimeType", video.mimeType)
                            put("durationSeconds", video.durationSeconds)
                            put("createdAt", video.createdAt)
                            put("uploaderApp", video.uploaderApp)
                            put("streamUrl", "/api/videos/${video.id}/stream")
                        }
                        sendJsonResponse(rawOutput, 200, "OK", json)
                    } else {
                        sendJsonResponse(rawOutput, 404, "Not Found", JSONObject().put("error", "Video not found"))
                    }
                }

                // API Deletion is strictly prohibited by policy
                // Rule 4: "API দিয়েও ভিডিও ডিলিট করা যাবে না। API শুধু আপলোড ও স্ট্রিম করতে পারবে।"
                path.startsWith("/api/videos") && method == "DELETE" -> {
                    val forbiddenJson = JSONObject().apply {
                        put("success", false)
                        put("error", "API deletion is strictly disabled (Forbidden 403)")
                        put("message", "Videos can NEVER be deleted via API. The API is strictly limited to video upload and streaming. Deletion can only be performed manually by the owner from the StreamVault Dashboard through two-step YES confirmation.")
                        put("allowedMethods", JSONArray().put("GET").put("POST"))
                    }
                    sendJsonResponse(rawOutput, 403, "Forbidden", forbiddenJson)
                    UploadTracker.log("Rejected unauthorized API DELETE request from $clientIp (Policy: API deletion blocked)")
                }

                // POST /api/videos/upload - Receive video from external app
                (path == "/api/videos/upload" || path == "/api/videos") && method == "POST" -> {
                    handleVideoUpload(rawInput, rawOutput, headers, queryParams, clientIp)
                }

                // GET /api/videos/{id}/stream - Stream video with HTTP Range support
                path.matches(Regex("^/api/videos/[a-zA-Z0-9_-]+/stream$")) && method == "GET" -> {
                    val segments = path.split("/")
                    val videoId = segments[3] // /api/videos/{id}/stream
                    handleVideoStream(videoId, rawOutput, headers)
                }

                else -> {
                    sendJsonResponse(
                        rawOutput,
                        404,
                        "Not Found",
                        JSONObject().put("error", "Endpoint not found: $method $path")
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try {
                socket.close()
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    private fun isPublicEndpoint(path: String): Boolean {
        // Stream endpoint and health can be configured public or authenticated.
        // Let health check be open, streaming can be accessed with ?api_key= or public
        return path == "/api/health" || path == "/api/status"
    }

    /**
     * Handles binary video upload with live progress tracking
     */
    private suspend fun handleVideoUpload(
        input: InputStream,
        output: OutputStream,
        headers: Map<String, String>,
        queryParams: Map<String, String>,
        clientIp: String
    ) {
        val contentLength = headers["content-length"]?.toLongOrNull() ?: -1L
        val contentType = headers["content-type"] ?: "video/mp4"

        // Video title from headers or query params
        val rawTitle = headers["x-video-title"]
            ?: queryParams["title"]
            ?: "Video_${System.currentTimeMillis()}"
        val videoTitle = try {
            URLDecoder.decode(rawTitle, "UTF-8")
        } catch (e: Exception) {
            rawTitle
        }

        val videoDesc = headers["x-video-description"] ?: queryParams["description"] ?: ""
        val uploaderApp = headers["x-uploader-app"] ?: headers["user-agent"] ?: "External App (API)"

        val videoId = "vid_" + UUID.randomUUID().toString().replace("-", "").take(12)
        val cleanTitle = videoTitle.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        val fileName = "${videoId}_$cleanTitle"
        val targetFile = File(repository.getVideosDirectory(), fileName)

        val sessionId = UUID.randomUUID().toString()
        UploadTracker.startSession(
            sessionId = sessionId,
            title = videoTitle,
            totalBytes = if (contentLength > 0) contentLength else 0L,
            clientIp = clientIp
        )

        var totalBytesRead = 0L
        var lastUpdateMs = System.currentTimeMillis()
        var lastBytesRead = 0L

        try {
            val fileOut = BufferedOutputStream(FileOutputStream(targetFile), 1048576)
            val buffer = ByteArray(1048576) // 1MB (1048576 bytes) buffer for high-speed large video uploads
            var bytesRead: Int

            if (contentLength > 0) {
                var remaining = contentLength
                while (remaining > 0) {
                    val toRead = Math.min(buffer.size.toLong(), remaining).toInt()
                    bytesRead = input.read(buffer, 0, toRead)
                    if (bytesRead == -1) break
                    fileOut.write(buffer, 0, bytesRead)
                    totalBytesRead += bytesRead
                    remaining -= bytesRead

                    val now = System.currentTimeMillis()
                    if (now - lastUpdateMs >= 200 || remaining == 0L) {
                        val durationSec = (now - lastUpdateMs).coerceAtLeast(1) / 1000.0
                        val speed = ((totalBytesRead - lastBytesRead) / durationSec).toLong()
                        UploadTracker.updateProgress(sessionId, totalBytesRead, speed)
                        lastUpdateMs = now
                        lastBytesRead = totalBytesRead
                    }
                }
            } else {
                // Unknown length: read until EOF
                while (input.read(buffer).also { bytesRead = it } != -1) {
                    fileOut.write(buffer, 0, bytesRead)
                    totalBytesRead += bytesRead

                    val now = System.currentTimeMillis()
                    if (now - lastUpdateMs >= 200) {
                        val durationSec = (now - lastUpdateMs).coerceAtLeast(1) / 1000.0
                        val speed = ((totalBytesRead - lastBytesRead) / durationSec).toLong()
                        UploadTracker.updateProgress(sessionId, totalBytesRead, speed)
                        lastUpdateMs = now
                        lastBytesRead = totalBytesRead
                    }
                }
            }

            fileOut.flush()
            fileOut.close()

            // Save video metadata to SQLite database
            val entity = VideoEntity(
                id = videoId,
                title = videoTitle,
                description = videoDesc,
                fileName = fileName,
                filePath = targetFile.absolutePath,
                fileSizeBytes = totalBytesRead,
                mimeType = if (contentType.contains("video/")) contentType.split(";")[0] else "video/mp4",
                durationSeconds = 0,
                createdAt = System.currentTimeMillis(),
                uploaderApp = uploaderApp,
                clientIp = clientIp,
                streamPath = "/api/videos/$videoId/stream"
            )
            repository.insertVideo(entity)

            UploadTracker.completeSession(sessionId, totalBytesRead)

            val responseJson = JSONObject().apply {
                put("success", true)
                put("message", "Video uploaded and saved to SQLite database successfully")
                put("id", videoId)
                put("title", videoTitle)
                put("sizeBytes", totalBytesRead)
                put("formattedSize", NetworkUtils.formatBytes(totalBytesRead))
                put("streamUrl", "/api/videos/$videoId/stream")
            }
            sendJsonResponse(output, 201, "Created", responseJson)
        } catch (e: Exception) {
            UploadTracker.failSession(sessionId, e.message ?: "Upload interrupted")
            // Policy: Zero auto-delete / No temp removal on error. Files & SQLite records stay untouched.
            sendJsonResponse(
                output,
                500,
                "Internal Server Error",
                JSONObject().put("error", "Upload failed: ${e.message}")
            )
        }
    }

    /**
     * Streams video file with HTTP 206 Partial Content (HTTP Range requests)
     * Compatible with ExoPlayer, VideoView, HTML5 video, YouTube-like apps, and browser streaming
     */
    private suspend fun handleVideoStream(
        videoId: String,
        output: OutputStream,
        headers: Map<String, String>
    ) {
        val video = repository.getVideoById(videoId)
        if (video == null) {
            sendJsonResponse(output, 404, "Not Found", JSONObject().put("error", "Video not found"))
            return
        }

        val file = File(video.filePath)
        if (!file.exists()) {
            sendJsonResponse(output, 404, "Not Found", JSONObject().put("error", "Video file not found on disk"))
            return
        }

        val fileLength = file.length()
        val rangeHeader = headers["range"]

        if (rangeHeader != null && rangeHeader.startsWith("bytes=")) {
            // Partial Content 206
            val rangeValue = rangeHeader.removePrefix("bytes=").trim()
            val parts = rangeValue.split("-")
            val start = parts[0].toLongOrNull() ?: 0L
            val end = if (parts.size > 1 && parts[1].isNotBlank()) {
                parts[1].toLongOrNull() ?: (fileLength - 1)
            } else {
                fileLength - 1
            }

            val validStart = start.coerceIn(0L, fileLength - 1)
            val validEnd = end.coerceIn(validStart, fileLength - 1)
            val contentLength = (validEnd - validStart) + 1

            val headerBuilder = StringBuilder()
            headerBuilder.append("HTTP/1.1 206 Partial Content\r\n")
            headerBuilder.append("Content-Type: ${video.mimeType}\r\n")
            headerBuilder.append("Accept-Ranges: bytes\r\n")
            headerBuilder.append("Content-Range: bytes $validStart-$validEnd/$fileLength\r\n")
            headerBuilder.append("Content-Length: $contentLength\r\n")
            headerBuilder.append("Access-Control-Allow-Origin: *\r\n")
            headerBuilder.append("Connection: keep-alive\r\n")
            headerBuilder.append("\r\n")

            output.write(headerBuilder.toString().toByteArray(Charsets.UTF_8))
            output.flush()

            val raf = RandomAccessFile(file, "r")
            raf.seek(validStart)
            var bytesToRead = contentLength
            val buffer = ByteArray(65536) // 64KB buffer
            while (bytesToRead > 0) {
                val toRead = Math.min(buffer.size.toLong(), bytesToRead).toInt()
                val read = raf.read(buffer, 0, toRead)
                if (read == -1) break
                output.write(buffer, 0, read)
                bytesToRead -= read
            }
            output.flush()
            raf.close()
        } else {
            // Full Content 200 OK
            val headerBuilder = StringBuilder()
            headerBuilder.append("HTTP/1.1 200 OK\r\n")
            headerBuilder.append("Content-Type: ${video.mimeType}\r\n")
            headerBuilder.append("Content-Length: $fileLength\r\n")
            headerBuilder.append("Accept-Ranges: bytes\r\n")
            headerBuilder.append("Access-Control-Allow-Origin: *\r\n")
            headerBuilder.append("Connection: keep-alive\r\n")
            headerBuilder.append("\r\n")

            output.write(headerBuilder.toString().toByteArray(Charsets.UTF_8))
            output.flush()

            val fileIn = BufferedInputStream(file.inputStream())
            val buffer = ByteArray(65536)
            var read: Int
            while (fileIn.read(buffer).also { read = it } != -1) {
                output.write(buffer, 0, read)
            }
            output.flush()
            fileIn.close()
        }
    }

    private fun sendJsonResponse(output: OutputStream, statusCode: Int, statusText: String, json: JSONObject) {
        val bodyBytes = json.toString(2).toByteArray(Charsets.UTF_8)
        val headerBuilder = StringBuilder()
        headerBuilder.append("HTTP/1.1 $statusCode $statusText\r\n")
        headerBuilder.append("Content-Type: application/json; charset=utf-8\r\n")
        headerBuilder.append("Content-Length: ${bodyBytes.size}\r\n")
        headerBuilder.append("Access-Control-Allow-Origin: *\r\n")
        headerBuilder.append("Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n")
        headerBuilder.append("Access-Control-Allow-Headers: *\r\n")
        headerBuilder.append("Connection: close\r\n")
        headerBuilder.append("\r\n")

        output.write(headerBuilder.toString().toByteArray(Charsets.UTF_8))
        output.write(bodyBytes)
        output.flush()
    }

    private fun sendCorsResponse(output: OutputStream) {
        val headerBuilder = StringBuilder()
        headerBuilder.append("HTTP/1.1 204 No Content\r\n")
        headerBuilder.append("Access-Control-Allow-Origin: *\r\n")
        headerBuilder.append("Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n")
        headerBuilder.append("Access-Control-Allow-Headers: *\r\n")
        headerBuilder.append("Access-Control-Max-Age: 86400\r\n")
        headerBuilder.append("Content-Length: 0\r\n")
        headerBuilder.append("\r\n")
        output.write(headerBuilder.toString().toByteArray(Charsets.UTF_8))
        output.flush()
    }
}
