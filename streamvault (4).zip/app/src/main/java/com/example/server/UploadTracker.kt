package com.example.server

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class UploadStatus {
    UPLOADING,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class UploadSession(
    val id: String,
    val videoTitle: String,
    val totalBytes: Long,
    val bytesUploaded: Long = 0,
    val progressPercent: Float = 0f,
    val speedBytesPerSec: Long = 0,
    val startedAt: Long = System.currentTimeMillis(),
    val status: UploadStatus = UploadStatus.UPLOADING,
    val clientIp: String = "127.0.0.1",
    val errorMessage: String? = null
)

object UploadTracker {
    private val _sessions = MutableStateFlow<Map<String, UploadSession>>(emptyMap())
    val sessions: StateFlow<Map<String, UploadSession>> = _sessions.asStateFlow()

    private val _recentLogs = MutableStateFlow<List<String>>(emptyList())
    val recentLogs: StateFlow<List<String>> = _recentLogs.asStateFlow()

    fun log(message: String) {
        val timestamp = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        val entry = "[$timestamp] $message"
        _recentLogs.update { (listOf(entry) + it).take(50) }
    }

    fun startSession(
        sessionId: String,
        title: String,
        totalBytes: Long,
        clientIp: String
    ) {
        val session = UploadSession(
            id = sessionId,
            videoTitle = title,
            totalBytes = totalBytes,
            bytesUploaded = 0,
            progressPercent = 0f,
            startedAt = System.currentTimeMillis(),
            status = UploadStatus.UPLOADING,
            clientIp = clientIp
        )
        _sessions.update { it + (sessionId to session) }
        log("API Upload Started: '$title' ($totalBytes bytes) from $clientIp")
    }

    fun updateProgress(
        sessionId: String,
        bytesUploaded: Long,
        speedBytesPerSec: Long
    ) {
        _sessions.update { map ->
            val current = map[sessionId] ?: return@update map
            val total = if (current.totalBytes > 0) current.totalBytes else 1L
            val percent = ((bytesUploaded.toDouble() / total.toDouble()) * 100.0).coerceIn(0.0, 100.0).toFloat()
            map + (sessionId to current.copy(
                bytesUploaded = bytesUploaded,
                progressPercent = percent,
                speedBytesPerSec = speedBytesPerSec
            ))
        }
    }

    fun completeSession(sessionId: String, finalSize: Long) {
        _sessions.update { map ->
            val current = map[sessionId] ?: return@update map
            map + (sessionId to current.copy(
                bytesUploaded = finalSize,
                totalBytes = finalSize,
                progressPercent = 100f,
                status = UploadStatus.COMPLETED
            ))
        }
        val title = _sessions.value[sessionId]?.videoTitle ?: "Video"
        log("API Upload Complete: '$title' (${finalSize} bytes) successfully saved.")
    }

    fun failSession(sessionId: String, error: String) {
        _sessions.update { map ->
            val current = map[sessionId] ?: return@update map
            map + (sessionId to current.copy(
                status = UploadStatus.FAILED,
                errorMessage = error
            ))
        }
        val title = _sessions.value[sessionId]?.videoTitle ?: "Video"
        log("API Upload Failed: '$title' - $error")
    }

    fun clearCompleted() {
        _sessions.update { map ->
            map.filterValues { it.status == UploadStatus.UPLOADING }
        }
    }
}
