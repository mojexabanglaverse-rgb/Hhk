package com.example.server

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okio.BufferedSink
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

data class SimulationResult(
    val success: Boolean,
    val statusCode: Int,
    val message: String,
    val responseBody: String = ""
)

object ExternalClientSimulator {

    private val _isSimulating = MutableStateFlow(false)
    val isSimulating: StateFlow<Boolean> = _isSimulating.asStateFlow()

    private val _clientProgress = MutableStateFlow(0f)
    val clientProgress: StateFlow<Float> = _clientProgress.asStateFlow()

    private val _clientLog = MutableStateFlow<List<String>>(emptyList())
    val clientLog: StateFlow<List<String>> = _clientLog.asStateFlow()

    private fun log(msg: String) {
        val time = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        _clientLog.value = listOf("[$time] $msg") + _clientLog.value.take(40)
    }

    suspend fun simulateUploadFromExternalApp(
        context: Context,
        serverUrl: String,
        apiKey: String,
        videoTitle: String,
        videoDesc: String,
        sizeMb: Float = 3.5f,
        throttleMsPerChunk: Long = 40
    ): SimulationResult = withContext(Dispatchers.IO) {
        _isSimulating.value = true
        _clientProgress.value = 0f
        log("🚀 External App initiated upload: '$videoTitle' (~${sizeMb} MB)")
        log("🔑 Using API Key: ${apiKey.take(8)}...")
        log("🌐 Target API: $serverUrl/api/videos/upload")

        try {
            val totalBytes = (sizeMb * 1024 * 1024).toLong()
            val client = OkHttpClient.Builder()
                .connectTimeout(0, TimeUnit.MILLISECONDS)
                .writeTimeout(0, TimeUnit.MILLISECONDS)
                .readTimeout(0, TimeUnit.MILLISECONDS)
                .build()

            // Custom RequestBody that streams bytes with artificial pacing for visible real-time simulation
            val requestBody = object : RequestBody() {
                override fun contentType() = "video/mp4".toMediaType()
                override fun contentLength() = totalBytes

                override fun writeTo(sink: BufferedSink) {
                    val chunkSize = 1048576 // 1MB buffer (1048576 bytes)
                    var written = 0L

                    // Create minimal valid MP4 header signature bytes (ftyp isom/mp42)
                    val headerBytes = createMp4Header()
                    sink.write(headerBytes)
                    written += headerBytes.size

                    // Synthetic video chunk pattern
                    val dummyChunk = ByteArray(chunkSize) { (it % 256).toByte() }

                    while (written < totalBytes) {
                        val toWrite = Math.min(dummyChunk.size.toLong(), totalBytes - written).toInt()
                        sink.write(dummyChunk, 0, toWrite)
                        sink.flush()
                        written += toWrite

                        val progress = ((written.toDouble() / totalBytes.toDouble()) * 100.0).toFloat()
                        _clientProgress.value = progress

                        if (throttleMsPerChunk > 0) {
                            try {
                                Thread.sleep(throttleMsPerChunk)
                            } catch (e: InterruptedException) {
                                break
                            }
                        }
                    }
                }
            }

            val request = Request.Builder()
                .url("$serverUrl/api/videos/upload")
                .header("X-API-Key", apiKey)
                .header("X-Video-Title", videoTitle)
                .header("X-Video-Description", videoDesc)
                .header("X-Uploader-App", "YouTube Clone App v2.4")
                .post(requestBody)
                .build()

            log("📤 Streaming data chunks to StreamVault Server...")
            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""

            if (response.isSuccessful) {
                log("✅ Server response [${response.code}]: Video saved in SQLite & ready to stream!")
                SimulationResult(
                    success = true,
                    statusCode = response.code,
                    message = "Successfully uploaded via external API!",
                    responseBody = body
                )
            } else {
                log("❌ Server returned error [${response.code}]: $body")
                SimulationResult(
                    success = false,
                    statusCode = response.code,
                    message = "Failed: Server returned code ${response.code}",
                    responseBody = body
                )
            }
        } catch (e: Exception) {
            log("❌ Upload failed: ${e.message}")
            SimulationResult(
                success = false,
                statusCode = 0,
                message = "Connection error: ${e.message}"
            )
        } finally {
            _isSimulating.value = false
        }
    }

    /**
     * Builds a real MP4 'ftyp' box header signature
     */
    private fun createMp4Header(): ByteArray {
        val out = ByteArrayOutputStream()
        // ftyp box (32 bytes)
        val ftypBox = byteArrayOf(
            0x00, 0x00, 0x00, 0x20, // box size = 32
            0x66, 0x74, 0x79, 0x70, // 'ftyp'
            0x69, 0x73, 0x6F, 0x6D, // major brand: 'isom'
            0x00, 0x00, 0x02, 0x00, // minor version
            0x69, 0x73, 0x6F, 0x6D, // compatible brands: 'isom'
            0x69, 0x73, 0x6F, 0x32, // 'iso2'
            0x61, 0x76, 0x63, 0x31, // 'avc1'
            0x6D, 0x70, 0x34, 0x31  // 'mp41'
        )
        out.write(ftypBox)
        return out.toByteArray()
    }
}
