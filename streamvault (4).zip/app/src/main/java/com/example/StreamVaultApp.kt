package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.repository.VideoRepository
import com.example.server.StreamVaultServer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class StreamVaultApp : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var repository: VideoRepository
        private set

    lateinit var server: StreamVaultServer
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getDatabase(this)
        repository = VideoRepository(this, database.videoDao(), database.apiKeyDao())
        server = StreamVaultServer(repository, port = 8080)

        // Seed default API key and start server
        CoroutineScope(Dispatchers.IO).launch {
            repository.ensureDefaultApiKey()
            server.start()
        }
    }

    override fun onTerminate() {
        super.onTerminate()
        server.stop()
    }
}
