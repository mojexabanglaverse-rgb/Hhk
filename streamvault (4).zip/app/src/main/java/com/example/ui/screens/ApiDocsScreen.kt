package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ApiKeyEntity
import com.example.ui.StreamVaultViewModel

@Composable
fun ApiDocsScreen(
    viewModel: StreamVaultViewModel,
    modifier: Modifier = Modifier
) {
    val apiKeys by viewModel.apiKeys.collectAsStateWithLifecycle()
    val activeKey by viewModel.activeApiKey.collectAsStateWithLifecycle()
    val requireAuth by viewModel.requireAuth.collectAsStateWithLifecycle()
    val serverIp by viewModel.serverIp.collectAsStateWithLifecycle()
    val port = viewModel.port

    val clipboardManager = LocalClipboardManager.current
    var showCreateKeyDialog by remember { mutableStateOf(false) }
    var newKeyName by remember { mutableStateOf("") }
    var isKeyVisible by remember { mutableStateOf(false) }
    var copiedText by remember { mutableStateOf<String?>(null) }

    val baseUrl = "http://$serverIp:$port"

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Security & API Key Header Card (Req 6)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("api_security_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "API Key Authentication",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Switch(
                            checked = requireAuth,
                            onCheckedChange = { viewModel.toggleRequireAuth(it) },
                            modifier = Modifier.testTag("toggle_require_auth_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (requireAuth) "Enforced: External apps must provide 'X-API-Key' in HTTP headers."
                        else "Disabled: External apps can query and stream without an API key (Testing mode).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Primary API Key display
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Active API Key",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (activeKey.isBlank()) "No key generated"
                                    else if (isKeyVisible) activeKey
                                    else activeKey.take(6) + "••••••••••••" + activeKey.takeLast(4),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                            }

                            Row {
                                IconButton(
                                    onClick = { isKeyVisible = !isKeyVisible },
                                    modifier = Modifier.testTag("toggle_key_visibility_button")
                                ) {
                                    Icon(
                                        imageVector = if (isKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = "Toggle Visibility",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        clipboardManager.setText(AnnotatedString(activeKey))
                                        copiedText = "API Key"
                                    },
                                    modifier = Modifier.testTag("copy_api_key_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "Copy API Key",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        FilledTonalButton(
                            onClick = { showCreateKeyDialog = true },
                            modifier = Modifier.testTag("create_new_key_button")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Create Client Key", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Section: Endpoints Reference (Req 5: External YouTube-like app API)
        item {
            Text(
                text = "REST API Endpoints Reference",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        // Endpoint 1: Upload Video
        item {
            EndpointCard(
                method = "POST",
                methodColor = MaterialTheme.colorScheme.tertiary,
                path = "/api/videos/upload",
                title = "1. Upload Video from External App",
                description = "External apps like YouTube push binary video stream directly to this endpoint with metadata headers.",
                headers = listOf(
                    "X-API-Key: $activeKey",
                    "X-Video-Title: Vacation Highlights.mp4",
                    "X-Video-Description: External YouTube Upload",
                    "Content-Type: video/mp4",
                    "Content-Length: <file_size>"
                ),
                curlExample = "curl -X POST \"$baseUrl/api/videos/upload\" \\\n" +
                        "  -H \"X-API-Key: $activeKey\" \\\n" +
                        "  -H \"X-Video-Title: Tech_Review.mp4\" \\\n" +
                        "  -H \"Content-Type: video/mp4\" \\\n" +
                        "  --data-binary \"@my_video.mp4\"",
                onCopy = {
                    clipboardManager.setText(AnnotatedString(it))
                    copiedText = "cURL Upload"
                }
            )
        }

        // Endpoint 2: Stream Video (HTTP Range Support)
        item {
            EndpointCard(
                method = "GET",
                methodColor = MaterialTheme.colorScheme.primary,
                path = "/api/videos/{id}/stream",
                title = "2. Stream Video (HTTP 206 Range)",
                description = "Streams video content with byte-range seek support (RFC 7233). Compatible with ExoPlayer, VideoView, HTML5 <video>, and external streaming players.",
                headers = listOf(
                    "Range: bytes=0-1048575 (optional)",
                    "X-API-Key: $activeKey (or ?api_key=)"
                ),
                curlExample = "curl -i \"$baseUrl/api/videos/vid_example/stream\" \\\n" +
                        "  -H \"Range: bytes=0-1048575\"",
                onCopy = {
                    clipboardManager.setText(AnnotatedString(it))
                    copiedText = "cURL Stream"
                }
            )
        }

        // Endpoint 3: List Videos
        item {
            EndpointCard(
                method = "GET",
                methodColor = MaterialTheme.colorScheme.primary,
                path = "/api/videos",
                title = "3. Get Saved Videos List",
                description = "Returns a JSON list of all stored videos with IDs, titles, sizes, timestamps, and streaming paths.",
                headers = listOf(
                    "X-API-Key: $activeKey"
                ),
                curlExample = "curl \"$baseUrl/api/videos\" \\\n" +
                        "  -H \"X-API-Key: $activeKey\"",
                onCopy = {
                    clipboardManager.setText(AnnotatedString(it))
                    copiedText = "cURL List"
                }
            )
        }

        // Endpoint Policy: Deletion via API is Blocked
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("api_deletion_blocked_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.25f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.error
                        ) {
                            Text(
                                text = "BLOCKED (403)",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onError,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "API Video Deletion Disabled",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "৪. API দিয়ে কোনো ভিডিও ডিলিট করা যাবে না। API শুধু নতুন ভিডিও গ্রহণ (Upload) ও প্রদর্শন (Stream) করতে পারবে।",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "ভিডিওর রেকর্ড SQLite ডেটাবেজ ও ইন্টারনাল স্টোরেজে আজীবন সুরক্ষিত থাকবে। কোনো কারণে ভিডিও মুছতে হলে শুধুমাত্র ড্যাশবোর্ড থেকে ম্যানুয়ালি ডিলিট বাটন চেপে 'YES' কনফার্মেশনের মাধ্যমে ডিলিট করতে হবে।",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "DELETE /api/videos/{id} ➔ 403 Forbidden\n\"API deletion is disabled. Manual YES confirmation required.\"",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp
                            ),
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        }

        // API Key Management List
        if (apiKeys.isNotEmpty()) {
            item {
                Text(
                    text = "Configured API Keys (${apiKeys.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            items(apiKeys, key = { it.key }) { keyItem ->
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("key_item_${keyItem.key.take(6)}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = keyItem.name,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = keyItem.key,
                                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Usage: ${keyItem.usageCount} requests",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Row {
                            IconButton(onClick = {
                                clipboardManager.setText(AnnotatedString(keyItem.key))
                            }) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy")
                            }
                            if (apiKeys.size > 1) {
                                IconButton(onClick = { viewModel.deleteApiKey(keyItem) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog: Create New API Key
    if (showCreateKeyDialog) {
        AlertDialog(
            onDismissRequest = { showCreateKeyDialog = false },
            title = { Text("Generate New API Key") },
            text = {
                Column {
                    Text("Enter a name or client label for this API key:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newKeyName,
                        onValueChange = { newKeyName = it },
                        placeholder = { Text("e.g., YouTube App Client") },
                        modifier = Modifier.fillMaxWidth().testTag("new_key_name_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.createNewApiKey(newKeyName)
                        newKeyName = ""
                        showCreateKeyDialog = false
                    },
                    modifier = Modifier.testTag("confirm_create_key_button")
                ) {
                    Text("Generate")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateKeyDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun EndpointCard(
    method: String,
    methodColor: Color,
    path: String,
    title: String,
    description: String,
    headers: List<String>,
    curlExample: String,
    onCopy: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Method and path badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = methodColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = method,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = methodColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Text(
                    text = path,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Required Headers / Params:",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )
            for (h in headers) {
                Text(
                    text = "• $h",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Code / curl sample box
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.background,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "cURL Request Example",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            color = MaterialTheme.colorScheme.primary
                        )
                        IconButton(
                            onClick = { onCopy(curlExample) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy curl",
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = curlExample,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    )
                }
            }
        }
    }
}
