package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "api_keys")
data class ApiKeyEntity(
    @PrimaryKey
    val key: String,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    val isActive: Boolean = true,
    val usageCount: Long = 0
)
