package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "videos")
data class VideoEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val description: String = "",
    val fileName: String,
    val filePath: String,
    val fileSizeBytes: Long,
    val mimeType: String = "video/mp4",
    val durationSeconds: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val uploaderApp: String = "External App",
    val clientIp: String = "127.0.0.1",
    val streamPath: String = ""
)
