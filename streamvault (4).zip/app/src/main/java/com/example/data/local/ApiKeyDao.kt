package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ApiKeyDao {
    @Query("SELECT * FROM api_keys ORDER BY createdAt DESC")
    fun getAllApiKeys(): Flow<List<ApiKeyEntity>>

    @Query("SELECT * FROM api_keys WHERE `key` = :key AND isActive = 1 LIMIT 1")
    suspend fun getActiveKey(key: String): ApiKeyEntity?

    @Query("SELECT COUNT(*) FROM api_keys WHERE isActive = 1")
    suspend fun getActiveKeyCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApiKey(apiKey: ApiKeyEntity)

    @Delete
    suspend fun deleteApiKey(apiKey: ApiKeyEntity)

    @Query("UPDATE api_keys SET usageCount = usageCount + 1 WHERE `key` = :key")
    suspend fun incrementUsage(key: String)
}
