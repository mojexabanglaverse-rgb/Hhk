package com.example.data.repository

import android.content.Context
import com.example.data.local.ApiKeyDao
import com.example.data.local.ApiKeyEntity
import com.example.data.local.VideoDao
import com.example.data.local.VideoEntity
import kotlinx.coroutines.flow.Flow
import java.io.File
import java.util.UUID

class VideoRepository(
    private val context: Context,
    private val videoDao: VideoDao,
    private val apiKeyDao: ApiKeyDao
) {
    val allVideos: Flow<List<VideoEntity>> = videoDao.getAllVideos()
    val videoCount: Flow<Int> = videoDao.getVideoCount()
    val totalStorageBytes: Flow<Long?> = videoDao.getTotalStorageBytes()
    val allApiKeys: Flow<List<ApiKeyEntity>> = apiKeyDao.getAllApiKeys()

    suspend fun ensureDefaultApiKey(): String {
        val count = apiKeyDao.getActiveKeyCount()
        if (count == 0) {
            val defaultKey = "sv_live_" + UUID.randomUUID().toString().replace("-", "").take(16)
            val entity = ApiKeyEntity(
                key = defaultKey,
                name = "Default Client Key (External Apps)",
                createdAt = System.currentTimeMillis(),
                isActive = true
            )
            apiKeyDao.insertApiKey(entity)
            return defaultKey
        }
        return ""
    }

    suspend fun createApiKey(name: String): ApiKeyEntity {
        val newKey = "sv_live_" + UUID.randomUUID().toString().replace("-", "").take(16)
        val entity = ApiKeyEntity(
            key = newKey,
            name = name.ifBlank { "Client Key" },
            createdAt = System.currentTimeMillis(),
            isActive = true
        )
        apiKeyDao.insertApiKey(entity)
        return entity
    }

    suspend fun deleteApiKey(apiKey: ApiKeyEntity) {
        apiKeyDao.deleteApiKey(apiKey)
    }

    suspend fun isValidApiKey(providedKey: String): Boolean {
        if (providedKey.isBlank()) return false
        val key = apiKeyDao.getActiveKey(providedKey)
        if (key != null) {
            apiKeyDao.incrementUsage(providedKey)
            return true
        }
        return false
    }

    suspend fun getVideoById(id: String): VideoEntity? = videoDao.getVideoById(id)

    suspend fun insertVideo(video: VideoEntity) {
        videoDao.insertVideo(video)
    }

    /**
     * Manual deletion ONLY:
     * Rule: Video is never automatically deleted. Only manual UI action with explicit 2-step
     * YES confirmation calls this function. No background tasks or APIs can invoke this.
     */
    suspend fun deleteVideo(video: VideoEntity): Boolean {
        try {
            // Delete actual file on disk
            val file = File(video.filePath)
            if (file.exists()) {
                file.delete()
            }
            videoDao.deleteVideo(video)
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    suspend fun deleteVideoById(id: String): Boolean {
        val video = videoDao.getVideoById(id) ?: return false
        return deleteVideo(video)
    }

    fun getVideosDirectory(): File {
        val dir = File(context.filesDir, "vault_videos")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }
}
