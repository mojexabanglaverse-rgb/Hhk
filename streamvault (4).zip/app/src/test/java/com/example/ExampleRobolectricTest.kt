package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.ApiKeyEntity
import com.example.data.local.AppDatabase
import com.example.data.local.VideoEntity
import com.example.data.repository.VideoRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var db: AppDatabase
    private lateinit var repository: VideoRepository
    private lateinit var context: Context

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = VideoRepository(context, db.videoDao(), db.apiKeyDao())
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `app name is StreamVault`() {
        val appName = context.getString(R.string.app_name)
        assertEquals("StreamVault", appName)
    }

    @Test
    fun `video repository stores and retrieves video entity in Room SQLite`() = runBlocking {
        val video = VideoEntity(
            id = "vid_test123",
            title = "Test Video",
            description = "External YouTube App Test",
            fileName = "test.mp4",
            filePath = "/fake/path/test.mp4",
            fileSizeBytes = 1048576L,
            mimeType = "video/mp4",
            uploaderApp = "YouTube Clone"
        )
        repository.insertVideo(video)

        val videos = repository.allVideos.first()
        assertEquals(1, videos.size)
        assertEquals("Test Video", videos[0].title)
        assertEquals("vid_test123", videos[0].id)
        assertEquals(1048576L, videos[0].fileSizeBytes)

        val count = repository.videoCount.first()
        assertEquals(1, count)

        // Test delete
        val deleted = repository.deleteVideo(video)
        assertTrue(deleted)
        val videosAfterDelete = repository.allVideos.first()
        assertEquals(0, videosAfterDelete.size)
    }

    @Test
    fun `api key validation and generation works`() = runBlocking {
        val created = repository.createApiKey("YouTube Client")
        assertNotNull(created.key)
        assertTrue(created.key.startsWith("sv_live_"))

        val isValid = repository.isValidApiKey(created.key)
        assertTrue(isValid)

        val isInvalid = repository.isValidApiKey("invalid_random_key")
        assertEquals(false, isInvalid)
    }

    @Test
    fun `zero auto-delete and YES confirmation strings are present`() {
        val yesBtn = context.getString(R.string.delete_button_yes)
        val confirmTitle = context.getString(R.string.delete_confirm_title)
        val confirmMsg = context.getString(R.string.delete_confirm_message)

        assertEquals("YES", yesBtn)
        assertTrue(confirmTitle.contains("ভিডিও ডিলিট নিশ্চিতকরণ"))
        assertTrue(confirmMsg.contains("YES"))
    }
}
