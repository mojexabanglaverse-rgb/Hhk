package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Post
import com.example.data.model.Story
import com.example.data.model.UserProfile
import com.example.data.model.Video
import com.example.ui.components.SocialPostCard
import com.example.ui.components.StoryRow
import com.example.ui.components.VideoCard
import com.example.ui.theme.VidBookBlue
import com.example.ui.theme.VidBookRed

@Composable
fun HomeScreen(
    currentUser: UserProfile?,
    stories: List<Story>,
    posts: List<Post>,
    featuredVideos: List<Video>,
    onAddStoryClick: () -> Unit,
    onStoryClick: (Story) -> Unit,
    onOpenUpload: () -> Unit,
    onPostLike: (Post) -> Unit,
    onPostComment: (Post) -> Unit,
    onPostShare: (Post) -> Unit,
    onVideoClick: (Video) -> Unit,
    onAuthorClick: (String) -> Unit = {},
    onChannelClick: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("home_screen_feed"),
        contentPadding = PaddingValues(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Stories Row at top (Facebook Style)
        item {
            StoryRow(
                stories = stories,
                userAvatarUrl = currentUser?.avatarUrl,
                onAddStoryClick = onAddStoryClick,
                onStoryClick = onStoryClick
            )
        }

        // 2. Facebook-style "What's on your mind?" quick create box
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp)
                    .clickable(onClick = onOpenUpload)
                    .testTag("quick_create_post_card"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(
                            model = currentUser?.avatarUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&q=80",
                            contentDescription = null,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .clip(RoundedCornerShape(20.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 14.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                text = "আপনার মাথায় কী চলছে? পোস্ট করুন…",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 13.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable(onClick = onOpenUpload)
                        ) {
                            Icon(Icons.Default.Image, contentDescription = null, tint = VidBookBlue, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ছবি শেয়ার", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable(onClick = onOpenUpload)
                        ) {
                            Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = VidBookRed, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ভিডিও আপলোড", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }

        // 3. Social Posts & Featured Videos Feed
        items(posts) { post ->
            SocialPostCard(
                post = post,
                onLikeClick = { onPostLike(post) },
                onCommentClick = { onPostComment(post) },
                onShareClick = { onPostShare(post) },
                onAuthorClick = onAuthorClick,
                modifier = Modifier.padding(horizontal = 10.dp)
            )
        }

        // Trending Video in Home Feed
        if (featuredVideos.isNotEmpty()) {
            item {
                Column(modifier = Modifier.padding(top = 6.dp)) {
                    Text(
                        text = "🔥 জনপ্রিয় ট্রেন্ডিং ভিডিও",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                    VideoCard(
                        video = featuredVideos.first(),
                        onClick = { onVideoClick(featuredVideos.first()) },
                        onChannelClick = onChannelClick
                    )
                }
            }
        }
    }
}
