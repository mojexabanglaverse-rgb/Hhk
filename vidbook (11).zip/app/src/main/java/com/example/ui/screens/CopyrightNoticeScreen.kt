package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.copyright.model.CopyrightNotice
import com.example.copyright.model.CopyrightNoticeStatus
import com.example.copyright.model.UserCopyrightStatus
import com.example.ui.components.toBanglaDigits
import com.example.ui.theme.VidBookBlue
import com.example.ui.theme.VidBookRed

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CopyrightNoticeScreen(
    copyrightStatus: UserCopyrightStatus,
    notices: List<CopyrightNotice>,
    onBack: () -> Unit,
    onSubmitDispute: (noticeId: String, reason: String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    var selectedFilter by remember { mutableIntStateOf(0) } // 0: All, 1: Active, 2: Resolved, 3: Disputed
    var disputeNotice by remember { mutableStateOf<CopyrightNotice?>(null) }
    var disputeReasonInput by remember { mutableStateOf("") }

    val filteredNotices = remember(notices, selectedFilter) {
        when (selectedFilter) {
            1 -> notices.filter { it.status == CopyrightNoticeStatus.ACTIVE }
            2 -> notices.filter { it.status == CopyrightNoticeStatus.RESOLVED }
            3 -> notices.filter { it.status == CopyrightNoticeStatus.DISPUTED }
            else -> notices
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("copyright_notice_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "কপিরাইট স্ট্যাটাস ও স্ট্রাইক",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("copyright_back_btn")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "ফিরে যান"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. YouTube-style 3-Strike System Visual Overview
            item {
                StrikeStatusDashboard(copyrightStatus = copyrightStatus)
            }

            // 2. Severe Penalty Alert Banners
            if (copyrightStatus.isMonetizationDisabled) {
                item {
                    PermanentMonetizationDisabledBanner()
                }
            } else if (copyrightStatus.isUploadBlocked) {
                item {
                    UploadSuspendedBanner(blockedUntil = copyrightStatus.uploadBlockedUntil)
                }
            }

            // 3. Filter Chips
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedFilter == 0,
                        onClick = { selectedFilter = 0 },
                        label = { Text("সবগুলো (${notices.size.toString().toBanglaDigits()})") }
                    )
                    FilterChip(
                        selected = selectedFilter == 1,
                        onClick = { selectedFilter = 1 },
                        label = { Text("সক্রিয় (${notices.count { it.status == CopyrightNoticeStatus.ACTIVE }.toString().toBanglaDigits()})") }
                    )
                    FilterChip(
                        selected = selectedFilter == 2,
                        onClick = { selectedFilter = 2 },
                        label = { Text("মীমাংসিত (${notices.count { it.status == CopyrightNoticeStatus.RESOLVED }.toString().toBanglaDigits()})") }
                    )
                    FilterChip(
                        selected = selectedFilter == 3,
                        onClick = { selectedFilter = 3 },
                        label = { Text("আপিল করা (${notices.count { it.status == CopyrightNoticeStatus.DISPUTED }.toString().toBanglaDigits()})") }
                    )
                }
            }

            // 4. Section Header
            item {
                Text(
                    text = "কপিরাইট নোটিশ তালিকা",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            // 5. Notices List
            if (filteredNotices.isEmpty()) {
                item {
                    EmptyNoticesState(hasZeroStrikes = copyrightStatus.strikeCount == 0)
                }
            } else {
                items(filteredNotices) { notice ->
                    CopyrightNoticeCard(
                        notice = notice,
                        onDisputeClick = {
                            disputeNotice = notice
                            disputeReasonInput = ""
                        }
                    )
                }
            }

            // 6. Educational Info Card (YouTube Fair Use & VidBook Rules)
            item {
                EducationalCopyrightCard()
            }
        }
    }

    // Dispute Dialog
    disputeNotice?.let { notice ->
        AlertDialog(
            onDismissRequest = { disputeNotice = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.Gavel,
                    contentDescription = null,
                    tint = VidBookBlue,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text("কপিরাইট আপিল জমা দিন (Dispute)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "ভিডিও: '${notice.videoTitle}'",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "আপনি যদি মনে করেন এই ভিডিওটি আপনার নিজস্ব সৃষ্টি বা ফেয়ার ইউজ (Fair Use)-এর আওতায় পড়ে, তবে আপিলের কারণ বিস্তারিত লিখুন:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = disputeReasonInput,
                        onValueChange = { disputeReasonInput = it },
                        placeholder = { Text("আপিলের সুনির্দিষ্ট কারণ লিখুন...", fontSize = 13.sp) },
                        modifier = Modifier.fillMaxWidth().height(110.dp),
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (disputeReasonInput.isNotBlank()) {
                            onSubmitDispute(notice.id, disputeReasonInput.trim())
                            disputeNotice = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VidBookBlue),
                    enabled = disputeReasonInput.isNotBlank()
                ) {
                    Text("আপিল পেশ করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { disputeNotice = null }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

@Composable
private fun StrikeStatusDashboard(copyrightStatus: UserCopyrightStatus) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = when (copyrightStatus.strikeCount) {
                0 -> Color(0xFFE8F5E9)
                1 -> Color(0xFFFFF3E0)
                2 -> Color(0xFFFFEBEE)
                else -> Color(0xFFFFEBEE)
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (copyrightStatus.strikeCount == 0) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = when (copyrightStatus.strikeCount) {
                            0 -> Color(0xFF2E7D32)
                            1 -> Color(0xFFE65100)
                            else -> VidBookRed
                        },
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "চ্যানেল স্ট্যাটাস",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Box(
                    modifier = Modifier
                        .background(
                            color = when (copyrightStatus.strikeCount) {
                                0 -> Color(0xFF2E7D32)
                                1 -> Color(0xFFE65100)
                                else -> VidBookRed
                            },
                            shape = RoundedCornerShape(12.dp)
                        )
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${copyrightStatus.strikeCount.toString().toBanglaDigits()}/৩ স্ট্রাইক",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 3 Strike Step Boxes
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Strike 1 Box
                StrikeStepItem(
                    stepNumber = 1,
                    title = "১ম স্ট্রাইক",
                    description = "সতর্কবার্তা",
                    isActive = copyrightStatus.strikeCount >= 1,
                    modifier = Modifier.weight(1f)
                )
                // Strike 2 Box
                StrikeStepItem(
                    stepNumber = 2,
                    title = "২য় স্ট্রাইক",
                    description = "আপলোড ৩০ দিন বন্ধ",
                    isActive = copyrightStatus.strikeCount >= 2,
                    modifier = Modifier.weight(1f)
                )
                // Strike 3 Box
                StrikeStepItem(
                    stepNumber = 3,
                    title = "৩য় স্ট্রাইক",
                    description = "ইনকাম স্থায়ী বন্ধ",
                    isActive = copyrightStatus.strikeCount >= 3,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun StrikeStepItem(
    stepNumber: Int,
    title: String,
    description: String,
    isActive: Boolean,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(
                color = if (isActive) VidBookRed.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.8f),
                shape = RoundedCornerShape(10.dp)
            )
            .border(
                width = if (isActive) 1.5.dp else 0.5.dp,
                color = if (isActive) VidBookRed else Color.LightGray,
                shape = RoundedCornerShape(10.dp)
            )
            .padding(8.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .background(if (isActive) VidBookRed else Color.Gray.copy(alpha = 0.3f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stepNumber.toString().toBanglaDigits(),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(
                text = description,
                fontSize = 9.sp,
                color = if (isActive) VidBookRed else Color.DarkGray,
                maxLines = 2,
                lineHeight = 12.sp
            )
        }
    }
}

@Composable
private fun PermanentMonetizationDisabledBanner() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = VidBookRed)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Block, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "❌ ইনকাম স্থায়ীভাবে বন্ধ",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "আপনার অ্যাকাউন্টে ৩টি কপিরাইট স্ট্রাইক আছে। আপনি আর ইনকাম করতে পারবেন না।",
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
private fun UploadSuspendedBanner(blockedUntil: Long) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFD32F2F))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Warning, contentDescription = null, tint = Color.White, modifier = Modifier.size(30.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "🚫 আপলোড ৩০ দিনের জন্য বন্ধ",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "২য় কপিরাইট স্ট্রাইকের ফলে ভিডিও ও রিলস আপলোড সাময়িকভাবে স্থগিত রাখা হয়েছে।",
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun CopyrightNoticeCard(
    notice: CopyrightNotice,
    onDisputeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // 1. Video Thumbnail & Video Details Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Video Thumbnail (ভিডিওর থাম্বনেইল)
                Box(
                    modifier = Modifier
                        .size(width = 110.dp, height = 68.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black.copy(alpha = 0.2f))
                ) {
                    AsyncImage(
                        model = notice.thumbnailUrl ?: "https://images.unsplash.com/photo-1518173946687-a4c8a383392e?w=800&q=80",
                        contentDescription = "ভিডিও থাম্বনেইল",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    // Video Title (ভিডিওর নাম)
                    Text(
                        text = notice.videoTitle,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // Strike Count Badge (Strike কাউন্ট)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .background(
                                    color = when (notice.strikeNumber) {
                                        1 -> Color(0xFFE65100)
                                        2 -> VidBookRed
                                        else -> VidBookRed
                                    },
                                    shape = RoundedCornerShape(6.dp)
                                )
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "স্ট্রাইক: ${notice.strikeNumber.toString().toBanglaDigits()}/৩",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        // Status Badge
                        Box(
                            modifier = Modifier
                                .background(
                                    color = when (notice.status) {
                                        CopyrightNoticeStatus.ACTIVE -> VidBookRed.copy(alpha = 0.12f)
                                        CopyrightNoticeStatus.RESOLVED -> Color(0xFFE8F5E9)
                                        CopyrightNoticeStatus.DISPUTED -> Color(0xFFFFF3E0)
                                    },
                                    shape = RoundedCornerShape(6.dp)
                                )
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = when (notice.status) {
                                    CopyrightNoticeStatus.ACTIVE -> "সক্রিয়"
                                    CopyrightNoticeStatus.RESOLVED -> "মীমাংসিত"
                                    CopyrightNoticeStatus.DISPUTED -> "আপিলকৃত"
                                },
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (notice.status) {
                                    CopyrightNoticeStatus.ACTIVE -> VidBookRed
                                    CopyrightNoticeStatus.RESOLVED -> Color(0xFF2E7D32)
                                    CopyrightNoticeStatus.DISPUTED -> Color(0xFFE65100)
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 2. "এই ভিডিওতে কপিরাইট সমস্যা আছে" লেখা (Prominent Red Banner)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = VidBookRed.copy(alpha = 0.12f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = VidBookRed,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "এই ভিডিওতে কপিরাইট সমস্যা আছে",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = VidBookRed
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 3. কার কপিরাইট সেটা দেখাবে
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Security, contentDescription = null, tint = VidBookRed, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "কার কপিরাইট: ", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    text = notice.copyrightOwner,
                    fontSize = 12.sp,
                    color = VidBookRed,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "কপিরাইট শনাক্তকরণ: ", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(text = notice.matchType, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            // 4. ৩ Strike হলে: ইনকাম বন্ধের নোটিশ
            if (notice.strikeNumber >= 3) {
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(VidBookRed, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = "❌ আপনার অ্যাকাউন্টে ৩টি কপিরাইট স্ট্রাইক আছে। আপনি আর ইনকাম করতে পারবেন না।",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
            }

            // Dispute Action
            if (notice.status == CopyrightNoticeStatus.ACTIVE) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(
                        onClick = onDisputeClick,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(Icons.Default.Gavel, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("আপিল করুন (Dispute)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            } else if (notice.status == CopyrightNoticeStatus.DISPUTED && !notice.disputeReason.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "আপনার আপিল: ${notice.disputeReason}",
                    fontSize = 11.sp,
                    color = VidBookBlue,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
            }
        }
    }
}

@Composable
private fun EmptyNoticesState(hasZeroStrikes: Boolean) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = null,
                tint = if (hasZeroStrikes) Color(0xFF2E7D32) else VidBookBlue,
                modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = if (hasZeroStrikes) "অভিনন্দন! কোনো কপিরাইট স্ট্রাইক নেই" else "কোনো নোটিশ পাওয়া যায়নি",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "আপনার কনটেন্ট সুরক্ষিত ও কমিউনিটি গাইডলাইন মেনে চলছে।",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun EducationalCopyrightCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.HelpOutline, contentDescription = null, tint = VidBookBlue, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("VidBook কপিরাইট নীতিমালা কী?", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Text(
                text = "• হুবহু অন্য চ্যানেলের নাটক, খবর বা গান আপলোড করা কপিরাইট আইন অনুযায়ী নিষিদ্ধ।\n" +
                       "• প্রথম স্ট্রাইকে কেবল সতর্কবার্তা পাঠানো হয়।\n" +
                       "• ২য় স্ট্রাইকে ভিডিও ও রিলস আপলোড ৩০ দিন স্থগিত থাকে।\n" +
                       "• ৩য় স্ট্রাইকে অ্যাকাউন্ট মনিটাইজেশন ও ইনকাম স্থায়ীভাবে বন্ধ হয়ে যায়।",
                fontSize = 11.sp,
                lineHeight = 16.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
