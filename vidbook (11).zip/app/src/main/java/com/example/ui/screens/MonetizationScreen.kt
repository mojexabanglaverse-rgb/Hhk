package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CurrencyBitcoin
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CreatorLevel
import com.example.data.model.CreatorMonetizationState
import com.example.data.model.WithdrawalCategory
import com.example.data.model.WithdrawalMethod
import com.example.data.model.WithdrawalRecord
import com.example.ui.components.toBanglaDigits
import com.example.ui.theme.VidBookBlue
import com.example.ui.theme.VidBookRed

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonetizationScreen(
    state: CreatorMonetizationState,
    onBack: () -> Unit,
    onRequestWithdrawal: (method: WithdrawalMethod, amount: Double, destination: String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    var isWithdrawalDialogOpen by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.MonetizationOn,
                            contentDescription = null,
                            tint = Color(0xFFFFB300),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ক্রিয়েটর মনিটাইজেশন",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("monetization_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "ফিরে যান"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .testTag("monetization_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Suspension Warning Banner (If 3 strikes or suspended)
            if (state.isSuspended || state.strikeCount >= 3) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("monetization_suspended_card"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(VidBookRed),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "Monetization SUSPENDED",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = VidBookRed
                                    )
                                    Text(
                                        text = "আপনার Monetization স্থায়ীভাবে বন্ধ হয়েছে",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = VidBookRed
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "৩টি কপিরাইট স্ট্রাইকের কারণে আপনার মনিটাইজেশন সম্পূর্ণ স্থগিত করা হয়েছে এবং আপনাকে Level 0 তে নামিয়ে আনা হয়েছে। নতুন করে আবেদন করতে কমিউনিটি গাইডলাইন্স মেনে চলুন।",
                                fontSize = 12.sp,
                                color = Color(0xFFC62828),
                                lineHeight = 17.sp
                            )
                        }
                    }
                }
            }

            // 2. Active Level Header Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("active_level_badge_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = state.level.badgeColor.copy(alpha = 0.15f),
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = state.level.badgeEmoji,
                                            fontSize = 24.sp
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "Level ${state.level.levelNumber} — ${state.level.title}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        if (state.level == CreatorLevel.LEVEL_3) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = "Monetized",
                                                tint = Color(0xFFFFB300),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = state.level.badgeName,
                                        fontSize = 12.sp,
                                        color = state.level.badgeColor,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = state.level.badgeColor.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = if (state.isSuspended) "স্থগিত" else "সক্রিয়",
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    color = if (state.isSuspended) VidBookRed else state.level.badgeColor,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "বর্তমান আনলকড ফিচারসমূহ:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            state.level.unlocks.forEach { unlock ->
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = state.level.badgeColor,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = unlock,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 3. Monetization Progress Bars (Requirement 2)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("monetization_progress_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Level 3 শর্ত ও অগ্রগতি (Monetization Eligibility)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "সম্পূর্ণ মনিটাইজেশন ও উইথড্রয়াল আনলক করতে নিচের সব শর্ত পূরণ করুন:",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 2.dp, bottom = 14.dp)
                        )

                        // 1. Follower Progress: ৪৫০/৬০০   ━━━━━━━━░░  ৭৫%
                        val followerProgress = (state.followersCount.toFloat() / state.requiredFollowers.toFloat()).coerceIn(0f, 1f)
                        val followerPct = (followerProgress * 100).toInt()
                        ProgressMetricRow(
                            icon = Icons.Default.People,
                            label = "ফলোয়ার",
                            ratioText = "${state.followersCount.toString().toBanglaDigits()}/${state.requiredFollowers.toString().toBanglaDigits()}",
                            percentText = "${followerPct.toString().toBanglaDigits()}%",
                            progress = followerProgress,
                            isPassed = state.followersCount >= state.requiredFollowers,
                            barColor = VidBookBlue
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // 2. Watch Time Progress: ২১০০/৩৩০০  ━━━━━━░░░░  ৬৩%
                        val watchTimeProgress = (state.watchTimeHours.toFloat() / state.requiredWatchTimeHours.toFloat()).coerceIn(0f, 1f)
                        val watchTimePct = (watchTimeProgress * 100).toInt()
                        ProgressMetricRow(
                            icon = Icons.Default.Timer,
                            label = "Watch Time",
                            ratioText = "${state.watchTimeHours.toInt().toString().toBanglaDigits()}/${state.requiredWatchTimeHours.toInt().toString().toBanglaDigits()} ঘণ্টা",
                            percentText = "${watchTimePct.toString().toBanglaDigits()}%",
                            progress = watchTimeProgress,
                            isPassed = state.watchTimeHours >= state.requiredWatchTimeHours,
                            barColor = Color(0xFF00C853)
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // 3. Strike Progress: ০/৩       ━━━━━━━━━━  ✅
                        val strikePassed = state.strikeCount == 0
                        ProgressMetricRow(
                            icon = Icons.Default.Warning,
                            label = "Strike",
                            ratioText = "${state.strikeCount.toString().toBanglaDigits()}/${state.maxStrikes.toString().toBanglaDigits()}",
                            percentText = if (strikePassed) "✅ নিরাপদ" else "⚠️ সতর্ক",
                            progress = if (strikePassed) 1f else ((state.maxStrikes - state.strikeCount).toFloat() / state.maxStrikes.toFloat()).coerceIn(0f, 1f),
                            isPassed = strikePassed,
                            barColor = if (strikePassed) Color(0xFF2E7D32) else VidBookRed
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // 4. Account Age Progress: ২৫/৩০ দিন  ━━━━━━━━░░  ৮৩%
                        val accountAgeProgress = (state.accountAgeDays.toFloat() / state.requiredAccountDays.toFloat()).coerceIn(0f, 1f)
                        val accountAgePct = (accountAgeProgress * 100).toInt()
                        ProgressMetricRow(
                            icon = Icons.Default.CalendarMonth,
                            label = "অ্যাকাউন্ট বয়স",
                            ratioText = "${state.accountAgeDays.toString().toBanglaDigits()}/${state.requiredAccountDays.toString().toBanglaDigits()} দিন",
                            percentText = "${accountAgePct.toString().toBanglaDigits()}%",
                            progress = accountAgeProgress,
                            isPassed = state.accountAgeDays >= state.requiredAccountDays,
                            barColor = Color(0xFFFF6D00)
                        )
                    }
                }
            }

            // 4. Earnings Dashboard (Requirement 5)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("earnings_dashboard_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFFFB300).copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AttachMoney,
                                        contentDescription = null,
                                        tint = Color(0xFFFFB300),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Earnings Dashboard",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                            }

                            if (state.level == CreatorLevel.LEVEL_3 && !state.isSuspended) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color(0xFFE8F5E9)
                                ) {
                                    Text(
                                        text = "উত্তোলন সক্রিয়",
                                        color = Color(0xFF2E7D32),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Earnings figures
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Total Earnings
                            Card(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("মোট আয় (Total)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "$${String.format("%.2f", state.totalEarnings)}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 20.sp,
                                        color = Color(0xFF2E7D32)
                                    )
                                    Text(
                                        text = "৳${(state.totalEarnings * 110).toInt().toString().toBanglaDigits()} (আনুমানিক)",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            // Daily Earnings
                            Card(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("প্রতিদিনের আয় (Daily)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "+$${String.format("%.2f", state.dailyEarnings)}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 20.sp,
                                        color = VidBookBlue
                                    )
                                    Text(
                                        text = "আজকের ভিডিও ও রিলস ইনকাম",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Withdrawal Button
                        val canWithdraw = state.level == CreatorLevel.LEVEL_3 && !state.isSuspended
                        Button(
                            onClick = { isWithdrawalDialogOpen = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("open_withdrawal_button"),
                            shape = RoundedCornerShape(12.dp),
                            enabled = canWithdraw,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFFFB300),
                                contentColor = Color.Black,
                                disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                                disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                        ) {
                            Icon(
                                imageVector = if (canWithdraw) Icons.Default.AccountBalanceWallet else Icons.Default.Lock,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (canWithdraw) "টাকা উত্তোলন করুন (Withdrawal)" else "উত্তোলন আনলক করতে Level 3 প্রয়োজন",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            // 5. Level System Details & Roadmap (Requirement 1)
            item {
                Text(
                    text = "লেভেল সিস্টেম ও সুযোগ-সুবিধা",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            items(CreatorLevel.values()) { level ->
                LevelInfoCard(
                    level = level,
                    isCurrent = state.level == level && !state.isSuspended
                )
            }

            // 6. Withdrawal History Section
            if (state.withdrawalHistory.isNotEmpty()) {
                item {
                    Text(
                        text = "উত্তোলন হিস্ট্রি",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                items(state.withdrawalHistory) { record ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFE8F5E9)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Payments,
                                        contentDescription = null,
                                        tint = Color(0xFF2E7D32),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "${record.methodName} — $${record.amount}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "${record.destination} • ${record.dateFormatted}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Text(
                                text = record.status,
                                fontSize = 11.sp,
                                color = Color(0xFFE65100),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }

    // 7. Withdrawal Dialog (Requirement 6)
    if (isWithdrawalDialogOpen) {
        WithdrawalDialog(
            balance = state.totalEarnings,
            onDismiss = { isWithdrawalDialogOpen = false },
            onSubmit = { method, amount, destination ->
                onRequestWithdrawal(method, amount, destination)
                isWithdrawalDialogOpen = false
            }
        )
    }
}

@Composable
fun ProgressMetricRow(
    icon: ImageVector,
    label: String,
    ratioText: String,
    percentText: String,
    progress: Float,
    isPassed: Boolean,
    barColor: Color
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = barColor,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = label,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = ratioText,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = barColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = percentText,
                        color = barColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Progress bar with rounded corners
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = barColor,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }
}

@Composable
fun LevelInfoCard(
    level: CreatorLevel,
    isCurrent: Boolean
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCurrent) level.badgeColor.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
        ),
        border = if (isCurrent) androidx.compose.foundation.BorderStroke(1.5.dp, level.badgeColor) else null
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = level.badgeEmoji, fontSize = 20.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Level ${level.levelNumber} — ${level.title}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = level.badgeColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = level.badgeName,
                        color = level.badgeColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            val conditions = when (level) {
                CreatorLevel.LEVEL_0 -> "নতুন ক্রিয়েটর (সব ফিচার বন্ধ, শুধু ভিডিও আপলোড করা যাবে)"
                CreatorLevel.LEVEL_1 -> "শর্ত: ১০০+ ফলোয়ার, ৫০০+ ঘণ্টা watch time"
                CreatorLevel.LEVEL_2 -> "শর্ত: ৩০০+ ফলোয়ার, ১৫০০+ ঘণ্টা watch time"
                CreatorLevel.LEVEL_3 -> "শর্ত: ৬০০+ ফলোয়ার, ৩৩০০+ ঘণ্টা watch time, ০ Strike, ৩০ দিন পুরনো"
            }

            Text(
                text = conditions,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "আনলক: ${level.unlocks.joinToString(", ")}",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = level.badgeColor
            )
        }
    }
}

/**
 * Withdrawal System Dialog (Requirement 6)
 * Supports Crypto (Min $100) & International (Min $50).
 * Displays processing time (3-7 days), 1 withdrawal per month rule.
 */
@Composable
fun WithdrawalDialog(
    balance: Double,
    onDismiss: () -> Unit,
    onSubmit: (method: WithdrawalMethod, amount: Double, destination: String) -> Unit
) {
    var selectedCategory by remember { mutableStateOf(WithdrawalCategory.CRYPTO) }
    var selectedMethod by remember { mutableStateOf(WithdrawalMethod.BTC) }
    var amountInput by remember { mutableStateOf("") }
    var destinationInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val methods = remember(selectedCategory) {
        WithdrawalMethod.values().filter { it.category == selectedCategory }
    }

    val minAmount = selectedMethod.minAmount
    val enteredAmount = amountInput.toDoubleOrNull() ?: 0.0
    val isAmountValid = enteredAmount >= minAmount && enteredAmount <= balance
    val isDestinationValid = destinationInput.trim().length >= 4

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AccountBalanceWallet,
                    contentDescription = null,
                    tint = Color(0xFFFFB300)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "টাকা উত্তোলন (Withdrawal)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
            }
        },
        text = {
            Column {
                // Balance and Rules note
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("মোট ব্যালেন্স:", fontSize = 12.sp)
                            Text(
                                text = "$${String.format("%.2f", balance)}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color(0xFF2E7D32)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "ℹ️ প্রতি মাসে একবার Withdrawal করা যাবে • Processing Time: ৩-৭ কার্যদিবস",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 14.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Category Tabs (Crypto vs International)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedCategory == WithdrawalCategory.CRYPTO,
                        onClick = {
                            selectedCategory = WithdrawalCategory.CRYPTO
                            selectedMethod = WithdrawalMethod.BTC
                            errorMessage = null
                        },
                        label = { Text("💰 ক্রিপ্টো (মিনিমাম $100)") },
                        modifier = Modifier.weight(1f),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFFFB300).copy(alpha = 0.2f),
                            selectedLabelColor = Color(0xFFE65100)
                        )
                    )
                    FilterChip(
                        selected = selectedCategory == WithdrawalCategory.INTERNATIONAL,
                        onClick = {
                            selectedCategory = WithdrawalCategory.INTERNATIONAL
                            selectedMethod = WithdrawalMethod.PAYPAL
                            errorMessage = null
                        },
                        label = { Text("🏦 আন্তর্জাতিক (মিনিমাম $50)") },
                        modifier = Modifier.weight(1f),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = VidBookBlue.copy(alpha = 0.2f),
                            selectedLabelColor = VidBookBlue
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "পেমেন্ট মেথড নির্বাচন করুন:",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(6.dp))

                // Method picker chips
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    methods.forEach { method ->
                        val isSelected = selectedMethod == method
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedMethod = method
                                    errorMessage = null
                                },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, VidBookBlue) else null
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (method.category == WithdrawalCategory.CRYPTO) Icons.Default.CurrencyBitcoin else Icons.Default.AccountBalance,
                                        contentDescription = null,
                                        tint = if (isSelected) VidBookBlue else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = method.displayName,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 12.sp
                                        )
                                        Text(
                                            text = method.networkOrDetails,
                                            fontSize = 9.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Text(
                                    text = "মিনিমাম $${method.minAmount.toInt()}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isSelected) VidBookBlue else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Amount input
                OutlinedTextField(
                    value = amountInput,
                    onValueChange = {
                        amountInput = it
                        errorMessage = null
                    },
                    label = { Text("উত্তোলনের পরিমাণ ($)") },
                    placeholder = { Text("মিনিমাম $${minAmount.toInt()}") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("withdrawal_amount_input"),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Destination input (Wallet address or Account number)
                OutlinedTextField(
                    value = destinationInput,
                    onValueChange = {
                        destinationInput = it
                        errorMessage = null
                    },
                    label = { Text("Wallet Address বা Account নম্বর") },
                    placeholder = { Text(selectedMethod.placeholder) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("withdrawal_destination_input"),
                    shape = RoundedCornerShape(8.dp)
                )

                // Validation or Error message
                if (balance < minAmount) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "⚠️ আপনার ব্যালেন্স কম। এই মেথডে উইথড্র করতে মিনিমাম $${minAmount.toInt()} প্রয়োজন।",
                        color = VidBookRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                } else if (enteredAmount > 0 && enteredAmount < minAmount) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "⚠️ মিনিমাম $${minAmount.toInt()} প্রয়োজন",
                        color = VidBookRed,
                        fontSize = 11.sp
                    )
                } else if (enteredAmount > balance) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "⚠️ পর্যাপ্ত ব্যালেন্স নেই (বর্তমান ব্যালেন্স $${String.format("%.2f", balance)})",
                        color = VidBookRed,
                        fontSize = 11.sp
                    )
                }

                errorMessage?.let { err ->
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = err, color = VidBookRed, fontSize = 11.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (balance < minAmount) {
                        errorMessage = "মিনিমাম $${minAmount.toInt()} প্রয়োজন"
                        return@Button
                    }
                    if (!isAmountValid) {
                        errorMessage = "সঠিক পরিমাণ প্রদান করুন (মিনিমাম $${minAmount.toInt()})"
                        return@Button
                    }
                    if (!isDestinationValid) {
                        errorMessage = "সঠিক Wallet Address বা Account নম্বর দিন"
                        return@Button
                    }
                    onSubmit(selectedMethod, enteredAmount, destinationInput.trim())
                },
                enabled = isAmountValid && isDestinationValid && balance >= minAmount,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB300), contentColor = Color.Black),
                modifier = Modifier.testTag("submit_withdrawal_button")
            ) {
                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (balance < minAmount) "মিনিমাম $${minAmount.toInt()} প্রয়োজন" else "অনুরোধ পাঠান",
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}
