package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.CreatorLevel
import com.example.data.model.CreatorMonetizationState
import com.example.data.model.UserProfile
import com.example.data.model.Video
import com.example.ui.components.toBanglaDigits
import com.example.ui.theme.VidBookBlue
import com.example.ui.theme.VidBookRed

enum class DashboardTimeRange(val title: String) {
    TODAY("আজ"),
    LAST_7_DAYS("গত ৭ দিন"),
    LAST_28_DAYS("গত ২৮ দিন")
}

data class DashboardMetrics(
    val views: String,
    val viewsChange: String,
    val earnings: String,
    val earningsBdt: String,
    val engagement: String,
    val engagementChange: String,
    val netFollowers: String,
    val netFollowersChange: String,
    val watchTimeMinutes: String,
    val threeSecondViews: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfessionalDashboardView(
    user: UserProfile?,
    topVideos: List<Video>,
    onBack: () -> Unit,
    onOpenAdvertise: () -> Unit,
    monetizationState: CreatorMonetizationState = CreatorMonetizationState(),
    onOpenMonetization: () -> Unit = {}
) {
    BackHandler { onBack() }

    var selectedRangeIndex by remember { mutableIntStateOf(2) } // Default: Last 28 days

    val metrics = when (selectedRangeIndex) {
        0 -> DashboardMetrics(
            views = "৫,২৪০",
            viewsChange = "+৮.২%",
            earnings = "$১৪.৫০",
            earningsBdt = "৳১,৫৯৫",
            engagement = "১,৮২০",
            engagementChange = "+৫.৪%",
            netFollowers = "+১৪২",
            netFollowersChange = "+১২.১%",
            watchTimeMinutes = "৩,৪০০ মিনিট",
            threeSecondViews = "৪,৯৮০"
        )
        1 -> DashboardMetrics(
            views = "৩৪,৫৮০",
            viewsChange = "+১৪.৫%",
            earnings = "$৮৫.২০",
            earningsBdt = "৳৯,৩৭২",
            engagement = "১১,৪০০",
            engagementChange = "+৯.৮%",
            netFollowers = "+৮৯০",
            netFollowersChange = "+১৮.০%",
            watchTimeMinutes = "২১,৫০০ মিনিট",
            threeSecondViews = "৩১,২০০"
        )
        else -> DashboardMetrics(
            views = "১,২৪,৬০০",
            viewsChange = "+১৮.৪%",
            earnings = "$৩৪২.৫০",
            earningsBdt = "৳৩৭,৬৭৫",
            engagement = "৪২,৮০০",
            engagementChange = "+১২.৩%",
            netFollowers = "+৩,৪২০",
            netFollowersChange = "+২৫.৬%",
            watchTimeMinutes = "৭৮,২০০ মিনিট",
            threeSecondViews = "১,১২,০০০"
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "প্রফেশনাল ড্যাশবোর্ড",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "ফিরে যান"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .testTag("professional_dashboard_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Creator Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = user?.avatarUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80",
                            contentDescription = user?.name,
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = user?.name ?: "তানভীর আহমেদ",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = VidBookBlue,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Text(
                                text = "ডিজিটাল কনটেন্ট ক্রিয়েটর • লেভেল ৩",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Time Filter Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DashboardTimeRange.values().forEachIndexed { index, range ->
                        FilterChip(
                            selected = selectedRangeIndex == index,
                            onClick = { selectedRangeIndex = index },
                            label = {
                                Text(
                                    text = range.title,
                                    fontSize = 12.sp,
                                    fontWeight = if (selectedRangeIndex == index) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = VidBookBlue,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Section Title
            item {
                Text(
                    text = "পারফরম্যান্স ওভারভিউ (${DashboardTimeRange.values()[selectedRangeIndex].title})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            // 4 Core Metrics Grid (Views, Earnings, Engagement, Net Followers)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // 1. Views
                        MetricCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.Visibility,
                            iconColor = VidBookBlue,
                            title = "ভিউস (Views)",
                            value = metrics.views,
                            change = metrics.viewsChange,
                            subLabel = "৩ সেকেন্ড ভিউ: ${metrics.threeSecondViews}"
                        )

                        // 2. Approximate Earnings
                        MetricCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.MonetizationOn,
                            iconColor = Color(0xFF2E7D32),
                            title = "আনুমানিক আয় (Earnings)",
                            value = metrics.earnings,
                            change = metrics.earningsBdt,
                            subLabel = "ইন-স্ট্রিম অ্যাডস ও স্টারস"
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // 3. Engagement
                        MetricCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.ThumbUp,
                            iconColor = Color(0xFFE65100),
                            title = "এনগেজমেন্ট (Engagement)",
                            value = metrics.engagement,
                            change = metrics.engagementChange,
                            subLabel = "লাইক, কমেন্ট ও শেয়ার"
                        )

                        // 4. Net Followers
                        MetricCard(
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.TrendingUp,
                            iconColor = Color(0xFF6A1B9A),
                            title = "নেট ফলোয়ার (Net Followers)",
                            value = metrics.netFollowers,
                            change = metrics.netFollowersChange,
                            subLabel = "মোট ফলোয়ার: ১,৪২০"
                        )
                    }
                }
            }

            // Watch Time & Retention Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Timeline, contentDescription = null, tint = VidBookRed, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("মোট ওয়াচটাইম", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                            Text(metrics.watchTimeMinutes, fontWeight = FontWeight.Bold, color = VidBookRed, fontSize = 14.sp)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { 0.76f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = VidBookRed,
                            trackColor = VidBookRed.copy(alpha = 0.2f)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("গড় দেখার সময়: ২ মিনিট ৪৫ সেকেন্ড (৭৬% অডিয়েন্স রিটেনশন)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            // Monetization Tools Status Section
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "মনিটাইজেশন ও লেভেল সিস্টেম",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = monetizationState.level.badgeColor.copy(alpha = 0.15f),
                            modifier = Modifier.clickable { onOpenMonetization() }
                        ) {
                            Text(
                                text = "বিস্তারিত দেখুন >",
                                color = monetizationState.level.badgeColor,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    // Level Banner Card
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenMonetization() }
                            .testTag("dashboard_monetization_card"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, monetizationState.level.badgeColor.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(monetizationState.level.badgeColor.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = monetizationState.level.badgeEmoji, fontSize = 20.sp)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "Level ${monetizationState.level.levelNumber} — ${monetizationState.level.title}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = if (monetizationState.isSuspended) "মনিটাইজেশন স্থগিত রয়েছে" else "মোট আয়: $${String.format("%.2f", monetizationState.totalEarnings)} • উত্তোলন সক্রিয়",
                                        fontSize = 11.sp,
                                        color = if (monetizationState.isSuspended) VidBookRed else Color(0xFF2E7D32)
                                    )
                                }
                            }

                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                                contentDescription = null,
                                tint = monetizationState.level.badgeColor,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    MonetizationToolItem(
                        title = "ইন-স্ট্রিম বিজ্ঞাপন (In-Stream Ads)",
                        status = "সক্রিয়",
                        earnings = "$২৪০.০০",
                        icon = Icons.Default.PlayArrow,
                        iconTint = VidBookRed
                    )

                    MonetizationToolItem(
                        title = "স্টারস ও ভার্চুয়াল গিফট (Stars)",
                        status = "সক্রিয়",
                        earnings = "$৬৮.৫০",
                        icon = Icons.Default.Star,
                        iconTint = Color(0xFFFFB300)
                    )

                    MonetizationToolItem(
                        title = "ব্র্যান্ড পার্টনারশিপ ও স্পন্সরশিপ",
                        status = "অনুমোদিত",
                        earnings = "$৩৪.০০",
                        icon = Icons.Default.Campaign,
                        iconTint = VidBookBlue
                    )
                }
            }

            // Top Content List
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "সেরা পারফর্মিং কনটেন্ট (Top Content)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )

                    if (topVideos.isEmpty()) {
                        Text(
                            text = "আপনার আপলোড করা ভিডিওগুলো এখানে প্রদর্শিত হবে।",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        topVideos.take(3).forEach { video ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AsyncImage(
                                        model = video.thumbnailUrl,
                                        contentDescription = video.title,
                                        modifier = Modifier
                                            .size(54.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = video.title,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 13.sp,
                                            maxLines = 1
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "ভিউ: ${(video.viewsCount * 32).toString().toBanglaDigits()} • আয়: $${(video.viewsCount * 0.12).toInt()}.০০",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Advertise / Boost Call to Action
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = VidBookBlue.copy(alpha = 0.1f))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("আরও বেশি মানুষের কাছে পৌঁছান", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("আপনার কনটেন্ট বুস্ট করে দ্রুত ভিউ এবং ফলোয়ার বাড়ান।", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = onOpenAdvertise,
                            colors = ButtonDefaults.buttonColors(containerColor = VidBookBlue),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("বিজ্ঞাপন দিন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    iconColor: Color,
    title: String,
    value: String,
    change: String,
    subLabel: String
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Medium
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = change,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (change.startsWith("+") || change.startsWith("৳")) Color(0xFF2E7D32) else VidBookBlue
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subLabel,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun MonetizationToolItem(
    title: String,
    status: String,
    earnings: String,
    icon: ImageVector,
    iconTint: Color
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(iconTint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text("স্ট্যাটাস: $status", fontSize = 11.sp, color = Color(0xFF2E7D32))
            }
            Text(earnings, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}
