package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Comment
import com.example.data.model.CreatorLevel
import com.example.data.model.CreatorMonetizationState
import com.example.data.model.NotificationItem
import com.example.data.model.NotificationType
import com.example.data.model.Post
import com.example.data.model.Story
import com.example.data.model.UserProfile
import com.example.data.model.Video
import com.example.data.model.WithdrawalMethod
import com.example.data.repository.VidBookRepository
import com.example.copyright.model.CopyrightScanEvidence
import com.example.copyright.model.CopyrightStatus
import com.example.copyright.model.CopyrightNotice
import com.example.copyright.model.UserCopyrightStatus
import com.example.ui.screens.ChannelInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ScreenTab {
    HOME,
    VIDEOS,
    REELS,
    NOTIFICATIONS,
    PROFILE
}

class VidBookViewModel(application: Application) : AndroidViewModel(application) {

    val repository = VidBookRepository(application)

    // App Navigation State
    private val _currentTab = MutableStateFlow(ScreenTab.HOME)
    val currentTab: StateFlow<ScreenTab> = _currentTab.asStateFlow()

    // Dark Mode Toggle
    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    // Search & Filter State
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("সবগুলো")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    // Active Video Player State
    private val _activePlayingVideo = MutableStateFlow<Video?>(null)
    val activePlayingVideo: StateFlow<Video?> = _activePlayingVideo.asStateFlow()

    // Active Story Viewer State
    private val _viewingStory = MutableStateFlow<Story?>(null)
    val viewingStory: StateFlow<Story?> = _viewingStory.asStateFlow()

    // Active Comments Target (Post or Video)
    private val _activeCommentsTarget = MutableStateFlow<Pair<String, String>?>(null) // Pair(id, title)
    val activeCommentsTarget: StateFlow<Pair<String, String>?> = _activeCommentsTarget.asStateFlow()

    private val _activeCommentsList = MutableStateFlow<List<Comment>>(emptyList())
    val activeCommentsList: StateFlow<List<Comment>> = _activeCommentsList.asStateFlow()

    // Pre-Upload Copyright Scanning State
    private val _isScanningCopyright = MutableStateFlow(false)
    val isScanningCopyright: StateFlow<Boolean> = _isScanningCopyright.asStateFlow()

    private val _scanProgress = MutableStateFlow(0f)
    val scanProgress: StateFlow<Float> = _scanProgress.asStateFlow()

    private val _scanStage = MutableStateFlow("Checking video rights and duplicate content...")
    val scanStage: StateFlow<String> = _scanStage.asStateFlow()

    private val _copyrightEvidence = MutableStateFlow<CopyrightScanEvidence?>(null)
    val copyrightEvidence: StateFlow<CopyrightScanEvidence?> = _copyrightEvidence.asStateFlow()

    // Dialogs State
    private val _isUploadDialogOpen = MutableStateFlow(false)
    val isUploadDialogOpen: StateFlow<Boolean> = _isUploadDialogOpen.asStateFlow()

    private val _isAuthDialogOpen = MutableStateFlow(false)
    val isAuthDialogOpen: StateFlow<Boolean> = _isAuthDialogOpen.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    // StreamVault Server Configuration
    private val _streamVaultBaseUrl = MutableStateFlow(repository.getStreamVaultBaseUrl())
    val streamVaultBaseUrl: StateFlow<String> = _streamVaultBaseUrl.asStateFlow()

    fun updateStreamVaultUrl(newUrl: String) {
        val trimmed = newUrl.trim()
        val finalUrl = if (trimmed.endsWith("/")) trimmed else "$trimmed/"
        repository.updateStreamVaultBaseUrl(finalUrl)
        _streamVaultBaseUrl.value = repository.getStreamVaultBaseUrl()
        showSnackbar("StreamVault সার্ভার IP সফলভাবে সেভ করা হয়েছে!")
    }

    // User Profile
    val currentUser: StateFlow<UserProfile?> = repository.authManager.currentUserState

    // Feeds from Repository
    val stories: StateFlow<List<Story>> = repository.activeStories.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val posts: StateFlow<List<Post>> = repository.allPosts.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val reels: StateFlow<List<Video>> = repository.shorts.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val notifications: StateFlow<List<NotificationItem>> = repository.allNotifications.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Copyright Status & Notices (Real 3-Strike System & YouTube-style Notice Center)
    val userCopyrightStatus: StateFlow<UserCopyrightStatus> = repository.userCopyrightStatus.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = UserCopyrightStatus()
    )

    val copyrightNotices: StateFlow<List<CopyrightNotice>> = repository.copyrightNotices.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _isCopyrightNoticeScreenOpen = MutableStateFlow(false)
    val isCopyrightNoticeScreenOpen: StateFlow<Boolean> = _isCopyrightNoticeScreenOpen.asStateFlow()

    fun openCopyrightNoticeScreen() {
        _isCopyrightNoticeScreenOpen.value = true
    }

    fun closeCopyrightNoticeScreen() {
        _isCopyrightNoticeScreenOpen.value = false
    }

    fun submitCopyrightNoticeDispute(noticeId: String, reason: String) {
        viewModelScope.launch {
            repository.submitCopyrightNoticeDispute(noticeId, reason)
            showSnackbar("আপনার আপিল সফলভাবে জমা হয়েছে। পর্যালোচনার ফলাফল শীঘ্রই জানানো হবে।")
        }
    }

    // Monetization System & Level System
    val monetizationState: StateFlow<CreatorMonetizationState> = repository.monetizationState.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = CreatorMonetizationState()
    )

    private val _isMonetizationScreenOpen = MutableStateFlow(false)
    val isMonetizationScreenOpen: StateFlow<Boolean> = _isMonetizationScreenOpen.asStateFlow()

    fun openMonetizationScreen() {
        _isMonetizationScreenOpen.value = true
    }

    fun closeMonetizationScreen() {
        _isMonetizationScreenOpen.value = false
    }

    fun requestWithdrawal(method: WithdrawalMethod, amount: Double, destination: String) {
        viewModelScope.launch {
            val result = repository.requestWithdrawal(method, amount, destination)
            showSnackbar(result.second)
        }
    }

    // Active Post Detail View (Facebook Style navigation from Notifications & Home)
    private val _activeViewingPost = MutableStateFlow<Post?>(null)
    val activeViewingPost: StateFlow<Post?> = _activeViewingPost.asStateFlow()

    fun openPostDetail(post: Post) {
        _activeViewingPost.value = post
    }

    fun closePostDetail() {
        _activeViewingPost.value = null
    }

    fun handleNotificationClick(notification: NotificationItem) {
        viewModelScope.launch {
            repository.markNotificationAsRead(notification.id)
        }

        when (notification.type) {
            NotificationType.LIKE -> {
                // Like notification: Open that post (or video if targetId points to video)
                val targetId = notification.targetId ?: "post_1"
                val matchedPost = posts.value.find { it.id == targetId }
                    ?: posts.value.firstOrNull()
                if (matchedPost != null) {
                    openPostDetail(matchedPost)
                } else {
                    val matchedVideo = filteredVideos.value.find { it.id == targetId }
                    if (matchedVideo != null) openVideoDetail(matchedVideo)
                }
            }
            NotificationType.COMMENT -> {
                // Comment notification: Open that post with comments section open
                val targetId = notification.targetId ?: "post_1"
                val matchedPost = posts.value.find { it.id == targetId }
                    ?: posts.value.firstOrNull()
                if (matchedPost != null) {
                    openPostDetail(matchedPost)
                    openComments(matchedPost.id, matchedPost.content.take(30))
                } else {
                    val matchedVideo = filteredVideos.value.find { it.id == targetId }
                        ?: filteredVideos.value.firstOrNull()
                    if (matchedVideo != null) {
                        openVideoDetail(matchedVideo)
                        openComments(matchedVideo.id, matchedVideo.title)
                    }
                }
            }
            NotificationType.NEW_VIDEO -> {
                // New Video notification: Open that video
                val targetId = notification.targetId ?: "vid_1"
                val matchedVideo = filteredVideos.value.find { it.id == targetId }
                    ?: reels.value.find { it.id == targetId }
                    ?: filteredVideos.value.firstOrNull()
                if (matchedVideo != null) {
                    openVideoDetail(matchedVideo)
                } else {
                    setTab(ScreenTab.VIDEOS)
                }
            }
            NotificationType.FOLLOW, NotificationType.SUBSCRIBE -> {
                // Follow notification: Open that user's Channel
                val channelId = notification.targetId ?: "ch_natok"
                openChannel(channelId)
            }
            NotificationType.SYSTEM -> {
                if (notification.targetId == "monetization" || notification.message.contains("Level")) {
                    openMonetizationScreen()
                } else {
                    showSnackbar(notification.message)
                }
            }
            NotificationType.COPYRIGHT -> {
                openCopyrightNoticeScreen()
            }
        }
    }

    // Filtered Video Feed
    val filteredVideos: StateFlow<List<Video>> = combine(
        repository.longVideos,
        _selectedCategory,
        _searchQuery
    ) { videoList, category, query ->
        videoList.filter { video ->
            val matchesCategory = (category == "সবগুলো" || video.category == category)
            val matchesQuery = query.isBlank() ||
                video.title.contains(query, ignoreCase = true) ||
                video.channelName.contains(query, ignoreCase = true) ||
                video.description.contains(query, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // User Actions
    fun setTab(tab: ScreenTab) {
        _currentTab.value = tab
    }

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun openVideoDetail(video: Video) {
        _activePlayingVideo.value = video
        incrementViewCount(video.id)
    }

    fun incrementViewCount(videoId: String) {
        // Immediate UI update for the active video
        _activePlayingVideo.value = _activePlayingVideo.value?.let {
            if (it.id == videoId) it.copy(viewsCount = it.viewsCount + 1) else it
        }

        viewModelScope.launch {
            repository.incrementViews(videoId)
        }
    }

    fun closeVideoDetail() {
        _activePlayingVideo.value = null
    }

    // Active Channel Screen Navigation
    private val _activeChannelId = MutableStateFlow<String?>(null)
    val activeChannelId: StateFlow<String?> = _activeChannelId.asStateFlow()

    fun openChannel(channelId: String) {
        _activeChannelId.value = channelId
    }

    fun closeChannel() {
        _activeChannelId.value = null
    }

    fun getChannelInfo(channelId: String): ChannelInfo {
        val allVids = filteredVideos.value
        val matchingVideo = allVids.find { it.channelId == channelId }
        val matchingPost = posts.value.find { it.authorId == channelId }
        val isSub = matchingVideo?.isSubscribed ?: false

        val name = matchingVideo?.channelName
            ?: matchingPost?.authorName
            ?: when (channelId) {
                "ch_natok" -> "বাংলা নাটক স্টুডিও"
                "ch_news" -> "সময় সংবাদ লাইভ"
                "ch_tech" -> "টেক বাংলাদেশ"
                "ch_music" -> "সুর ও সঙ্গীত"
                "ch_01" -> "VidBook অরিজিনালস"
                "user_bd_01" -> currentUser.value?.name ?: "তানভীর আহমেদ"
                else -> "ক্রিয়েটর চ্যানেল"
            }

        val avatar = matchingVideo?.channelAvatar
            ?: matchingPost?.authorAvatar
            ?: when (channelId) {
                "user_bd_01" -> currentUser.value?.avatarUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80"
                else -> "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=400&q=80"
            }

        val cover = when (channelId) {
            "ch_natok" -> "https://images.unsplash.com/photo-1518791841217-8f162f1e1131?w=1200&q=80"
            "ch_news" -> "https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=1200&q=80"
            "user_bd_01" -> currentUser.value?.coverUrl ?: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&q=80"
            else -> "https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&q=80"
        }

        return ChannelInfo(
            id = channelId,
            name = name,
            avatarUrl = avatar,
            coverUrl = cover,
            isVerified = matchingVideo?.isChannelVerified ?: (matchingPost?.isAuthorVerified ?: true),
            subscribersCount = if (channelId == "user_bd_01") (currentUser.value?.subscribersCount ?: 950) else 850000,
            isSubscribed = isSub
        )
    }

    fun getVideosForChannel(channelId: String): List<Video> {
        val allVids = filteredVideos.value
        val directMatches = allVids.filter { it.channelId == channelId }
        if (directMatches.isNotEmpty()) return directMatches

        return if (channelId == "ch_natok") {
            allVids.filter { it.category == "নাটক" }
        } else {
            allVids.take(4)
        }
    }

    fun openStory(story: Story) {
        _viewingStory.value = story
        viewModelScope.launch {
            repository.markStorySeen(story.id)
        }
    }

    fun closeStory() {
        _viewingStory.value = null
    }

    fun openComments(targetId: String, title: String) {
        _activeCommentsTarget.value = Pair(targetId, title)
        viewModelScope.launch {
            repository.getCommentsForTarget(targetId).collect { comments ->
                _activeCommentsList.value = comments
            }
        }
    }

    fun closeComments() {
        _activeCommentsTarget.value = null
    }

    fun setUploadDialogOpen(open: Boolean) {
        _isUploadDialogOpen.value = open
    }

    fun setAuthDialogOpen(open: Boolean) {
        _isAuthDialogOpen.value = open
    }

    fun showSnackbar(msg: String) {
        _snackbarMessage.value = msg
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    // Interaction Handlers
    fun togglePostLike(post: Post) {
        viewModelScope.launch {
            repository.togglePostLike(post.id, post.isLiked, post.likesCount)
        }
    }

    fun toggleVideoLike(video: Video) {
        viewModelScope.launch {
            repository.toggleVideoLike(video.id, video.isLiked, video.likesCount)
            _activePlayingVideo.value = _activePlayingVideo.value?.let {
                if (it.id == video.id) it.copy(isLiked = !video.isLiked, likesCount = if (!video.isLiked) video.likesCount + 1 else video.likesCount - 1) else it
            }
        }
    }

    fun toggleChannelSubscribe(channelId: String, currentSubscribed: Boolean) {
        viewModelScope.launch {
            repository.toggleSubscription(channelId, currentSubscribed)
            _activePlayingVideo.value = _activePlayingVideo.value?.let {
                if (it.channelId == channelId) it.copy(isSubscribed = !currentSubscribed) else it
            }
            showSnackbar(if (!currentSubscribed) "চ্যানেল সাবস্ক্রাইব করা হয়েছে!" else "আনসাবস্ক্রাইব করা হয়েছে")
        }
    }

    // Follow State Tracking: Set of followed user IDs and real-time follower counts
    private val _followedUserIds = MutableStateFlow<Set<String>>(emptySet())
    val followedUserIds: StateFlow<Set<String>> = _followedUserIds.asStateFlow()

    private val _userFollowersCountMap = MutableStateFlow<Map<String, Int>>(emptyMap())
    val userFollowersCountMap: StateFlow<Map<String, Int>> = _userFollowersCountMap.asStateFlow()

    /**
     * Toggles follow status for a user.
     * Follow: follower count +1, Unfollow: follower count -1.
     * Updates Firebase Firestore and updates UI immediately.
     */
    fun toggleFollow(userId: String) {
        val isCurrentlyFollowing = _followedUserIds.value.contains(userId)
        val newFollowState = !isCurrentlyFollowing
        val delta = if (newFollowState) 1 else -1

        // Update followed users set immediately
        _followedUserIds.value = if (newFollowState) {
            _followedUserIds.value + userId
        } else {
            _followedUserIds.value - userId
        }

        // Update follower count map immediately for UI
        val currentCount = _userFollowersCountMap.value[userId]
            ?: currentUser.value?.takeIf { it.id == userId }?.followersCount
            ?: 1420
        val updatedCount = (currentCount + delta).coerceAtLeast(0)
        _userFollowersCountMap.value = _userFollowersCountMap.value + (userId to updatedCount)

        viewModelScope.launch {
            repository.toggleFollow(userId, isCurrentlyFollowing)
            showSnackbar(if (newFollowState) "ইউজারকে ফলো করা হয়েছে (+১ ফলোয়ার)" else "আনফলো করা হয়েছে (-১ ফলোয়ার)")
        }
    }

    fun createPost(content: String, imageUri: String?) {
        viewModelScope.launch {
            repository.createPost(content, imageUri)
            _activePlayingVideo.value = null
            _searchQuery.value = ""
            _currentTab.value = ScreenTab.HOME
            showSnackbar("পোস্ট সফলভাবে প্রকাশিত হয়েছে!")
            setUploadDialogOpen(false)
        }
    }

    fun uploadVideo(
        title: String,
        description: String,
        category: String,
        videoUri: String,
        thumbnailUri: String,
        isShort: Boolean
    ) {
        viewModelScope.launch {
            repository.uploadVideo(title, description, category, videoUri, thumbnailUri, isShort)
            _activePlayingVideo.value = null
            _searchQuery.value = ""
            _selectedCategory.value = "সবগুলো"
            if (isShort) {
                _currentTab.value = ScreenTab.REELS
            } else {
                _currentTab.value = ScreenTab.VIDEOS
            }
            showSnackbar(if (isShort) "শর্ট ভিডিও আপলোড সম্পন্ন হয়েছে" else "ভিডিও আপলোড সম্পন্ন হয়েছে")
            clearCopyrightScan()
            setUploadDialogOpen(false)
        }
    }

    suspend fun performPreUploadCopyrightScan(videoUri: String, videoTitle: String): CopyrightScanEvidence {
        _isScanningCopyright.value = true
        _scanProgress.value = 0.05f
        _scanStage.value = "যাচাইকরণ হচ্ছে..."
        _copyrightEvidence.value = null

        val result = repository.scanCandidateVideo(
            videoUriOrPath = videoUri,
            videoTitle = videoTitle.ifBlank { "Unspecified Candidate Title" },
            onProgress = { stage, progress ->
                _scanStage.value = stage
                _scanProgress.value = progress
            }
        )

        _copyrightEvidence.value = result
        _isScanningCopyright.value = false
        _scanProgress.value = 1.0f

        return result
    }

    fun scanVideoForCopyright(videoUri: String, videoTitle: String) {
        if (videoUri.isBlank()) return
        viewModelScope.launch {
            performPreUploadCopyrightScan(videoUri, videoTitle)
        }
    }

    fun clearCopyrightScan() {
        _isScanningCopyright.value = false
        _scanProgress.value = 0f
        _scanStage.value = "Checking video rights and duplicate content..."
        _copyrightEvidence.value = null
    }

    fun submitCopyrightDispute(evidence: CopyrightScanEvidence, reason: String) {
        viewModelScope.launch {
            repository.submitDispute(evidence, reason)
            showSnackbar("কপিরাইট আপিল জমা হয়েছে। মডারেশন টিম ২৪ ঘণ্টার মধ্যে পর্যালোচনা করবে।")
        }
    }

    fun addStory(mediaUrl: String, caption: String) {
        viewModelScope.launch {
            repository.addStory(mediaUrl, caption)
            showSnackbar("স্টোরি যোগ করা হয়েছে (২৪ ঘণ্টা থাকবে)")
        }
    }

    fun addComment(text: String) {
        val target = _activeCommentsTarget.value ?: return
        if (text.isBlank()) return
        viewModelScope.launch {
            repository.addComment(target.first, text)
            showSnackbar("মন্তব্য প্রকাশিত হয়েছে")
        }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsAsRead()
            showSnackbar("সকল নোটিফিকেশন পড়া হয়েছে")
        }
    }

    fun login(email: String, pass: String) {
        viewModelScope.launch {
            val res = repository.authManager.loginWithEmail(email, pass)
            if (res.isSuccess) {
                showSnackbar("সফলভাবে লগইন হয়েছে! স্বাগতম ${res.getOrNull()?.name}")
                setAuthDialogOpen(false)
            } else {
                showSnackbar("লগইন ব্যর্থ হয়েছে: ${res.exceptionOrNull()?.message}")
            }
        }
    }

    fun register(email: String, pass: String, name: String) {
        viewModelScope.launch {
            val res = repository.authManager.registerWithEmail(email, pass, name)
            if (res.isSuccess) {
                showSnackbar("রেজিস্ট্রেশন সফল! স্বাগতম $name")
                setAuthDialogOpen(false)
            } else {
                showSnackbar("রেজিস্ট্রেশন ব্যর্থ হয়েছে: ${res.exceptionOrNull()?.message}")
            }
        }
    }

    fun logout() {
        repository.authManager.logout()
        showSnackbar("লগআউট সম্পন্ন হয়েছে")
    }

    fun updateProfile(name: String, bio: String) {
        repository.authManager.updateProfile(name, bio)
        showSnackbar("প্রোফাইল আপডেট হয়েছে")
    }

    fun updateFullProfile(
        name: String,
        username: String,
        bio: String,
        avatarUri: String? = null,
        coverUri: String? = null
    ) {
        viewModelScope.launch {
            showSnackbar("প্রোফাইল আপডেট হচ্ছে...")
            repository.updateFullProfile(name, username, bio, avatarUri, coverUri)
            showSnackbar("প্রোফাইল সফলভাবে আপডেট হয়েছে!")
        }
    }

    fun updateAvatarPhoto(avatarUri: String) {
        viewModelScope.launch {
            showSnackbar("প্রোফাইল ছবি আপলোড হচ্ছে...")
            repository.updateAvatarPhoto(avatarUri)
            showSnackbar("প্রোফাইল ছবি সফলভাবে পরিবর্তিত হয়েছে!")
        }
    }

    fun updateCoverPhoto(coverUri: String) {
        viewModelScope.launch {
            showSnackbar("কভার ছবি আপলোড হচ্ছে...")
            repository.updateCoverPhoto(coverUri)
            showSnackbar("কভার ছবি সফলভাবে পরিবর্তিত হয়েছে!")
        }
    }
}
