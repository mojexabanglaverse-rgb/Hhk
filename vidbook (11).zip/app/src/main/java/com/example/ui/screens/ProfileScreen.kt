package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.copyright.model.UserCopyrightStatus
import com.example.data.model.CreatorLevel
import com.example.data.model.CreatorMonetizationState
import com.example.data.model.Post
import com.example.data.model.UserProfile
import com.example.data.model.Video
import com.example.ui.components.AdvertiseDialog
import com.example.ui.components.SocialPostCard
import com.example.ui.components.VideoCard
import com.example.ui.components.toBanglaDigits
import com.example.ui.theme.VidBookBlue
import com.example.ui.theme.VidBookRed

@Composable
fun ProfileScreen(
    user: UserProfile?,
    myPosts: List<Post>,
    myVideos: List<Video>,
    onAddStoryClick: () -> Unit = {},
    onShowSnackbar: (String) -> Unit = {},
    onOpenAuthDialog: () -> Unit,
    onLogout: () -> Unit,
    onUpdateProfile: (name: String, bio: String) -> Unit = { _, _ -> },
    onSaveFullProfile: (name: String, username: String, bio: String, avatarUri: String?, coverUri: String?) -> Unit = { _, _, _, _, _ -> },
    onUpdateAvatarPhoto: (String) -> Unit = {},
    onUpdateCoverPhoto: (String) -> Unit = {},
    onVideoClick: (Video) -> Unit,
    isOwnProfile: Boolean = true,
    isFollowing: Boolean = false,
    followersCountOverride: Int? = null,
    onToggleFollow: ((String) -> Unit)? = null,
    copyrightStatus: UserCopyrightStatus = UserCopyrightStatus(),
    onOpenCopyrightScreen: () -> Unit = {},
    monetizationState: CreatorMonetizationState = CreatorMonetizationState(),
    onOpenMonetization: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    // 0: All, 1: Photos, 2: Videos, 3: Reels, 4: More
    var selectedTab by remember { mutableIntStateOf(0) }
    var isEditingProfile by remember { mutableStateOf(false) }
    var isProfessionalDashboardOpen by remember { mutableStateOf(false) }
    var isAdvertiseDialogOpen by remember { mutableStateOf(false) }

    // Cover Photo Picker (Android Photo Picker - Zero Permission)
    val coverPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let {
            onUpdateCoverPhoto(it.toString())
        }
    }

    // Avatar Photo Picker (Android Photo Picker - Zero Permission)
    val avatarPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let {
            onUpdateAvatarPhoto(it.toString())
        }
    }

    // If Editing Profile is active, render full-screen Facebook style Edit Profile view
    if (isEditingProfile) {
        EditProfileScreenView(
            user = user,
            onBack = { isEditingProfile = false },
            onSave = { name, username, bio, avatarUri, coverUri ->
                onSaveFullProfile(name, username, bio, avatarUri, coverUri)
                isEditingProfile = false
            }
        )
        return
    }

    // If Professional Dashboard is open, render the dedicated full-screen view
    if (isProfessionalDashboardOpen) {
        ProfessionalDashboardView(
            user = user,
            topVideos = myVideos,
            onBack = { isProfessionalDashboardOpen = false },
            onOpenAdvertise = {
                isProfessionalDashboardOpen = false
                isAdvertiseDialogOpen = true
            },
            monetizationState = monetizationState,
            onOpenMonetization = {
                isProfessionalDashboardOpen = false
                onOpenMonetization()
            }
        )
        return
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("profile_screen"),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // Cover & Avatar Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
            ) {
                // Cover Photo
                AsyncImage(
                    model = user?.coverUrl ?: "https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&q=80",
                    contentDescription = "কভার ফটো",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp),
                    contentScale = ContentScale.Crop
                )

                // Camera Icon on Cover Photo (Own Profile only)
                if (isOwnProfile) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 104.dp, end = 12.dp)
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.65f))
                            .clickable {
                                coverPhotoPicker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                            .testTag("cover_camera_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = "কভার ফটো পরিবর্তন করুন",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Top Settings / Logout
                if (isOwnProfile) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.End
                    ) {
                        IconButton(
                            onClick = onOpenAuthDialog,
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                        ) {
                            Icon(Icons.Default.Settings, contentDescription = "সেটিংস", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = onLogout,
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                        ) {
                            Icon(Icons.Default.ExitToApp, contentDescription = "লগআউট", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                    }
                }

                // Profile Avatar with Camera Icon (Own Profile only)
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 16.dp)
                ) {
                    AsyncImage(
                        model = user?.avatarUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80",
                        contentDescription = user?.name,
                        modifier = Modifier
                            .size(96.dp)
                            .clip(CircleShape)
                            .border(3.dp, MaterialTheme.colorScheme.surface, CircleShape),
                        contentScale = ContentScale.Crop
                    )

                    if (isOwnProfile) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(VidBookBlue)
                                .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape)
                                .clickable {
                                    avatarPhotoPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                                .testTag("avatar_camera_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = "প্রোফাইল ছবি পরিবর্তন করুন",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        // Profile Bio & Creator Details
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = user?.name ?: "তানভীর আহমেদ",
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "ভেরিফাইড ক্রিয়েটর",
                        tint = VidBookBlue,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Text(
                    text = "ডিজিটাল কনটেন্ট ক্রিয়েটর • ${user?.username ?: "@tanvir_ahmed"}",
                    fontSize = 13.sp,
                    color = VidBookRed,
                    fontWeight = FontWeight.Medium
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = user?.bio?.ifBlank { "VidBook কমিউনিটিতে ভিডিও ও সোশ্যাল কনটেন্ট ক্রিয়েটর।" } ?: "VidBook কমিউনিটিতে স্বাগতম!",
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Stats Cards (Followers, Following, Subscribers, Videos)
                val liveFollowerCount = followersCountOverride ?: user?.followersCount ?: 1420
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    StatBox(label = "ফলোয়ার", value = liveFollowerCount.toString().toBanglaDigits())
                    StatBox(label = "ফলো করছেন", value = (user?.followingCount ?: 280).toString().toBanglaDigits())
                    StatBox(label = "সাবস্ক্রাইবার", value = (user?.subscribersCount ?: 950).toString().toBanglaDigits())
                    StatBox(label = "ভিডিও", value = (user?.totalVideos ?: 8).toString().toBanglaDigits())
                }

                Spacer(modifier = Modifier.height(14.dp))

                // ACTION BUTTONS: Facebook Style
                if (isOwnProfile) {
                    // ROW 1: Add to Story & Edit Profile
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = onAddStoryClick,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("add_to_story_btn"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = VidBookBlue)
                        ) {
                            Icon(Icons.Default.AddCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("+ স্টোরিতে যোগ করুন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Edit Profile Button (Opens dedicated screen)
                        OutlinedButton(
                            onClick = { isEditingProfile = true },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("edit_profile_btn"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("প্রোফাইল সম্পাদনা", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // ROW 2: Professional Dashboard & Advertise (Only Upper Button is kept per Requirement 1)
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { isProfessionalDashboardOpen = true },
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag("professional_dashboard_btn"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Analytics,
                                contentDescription = null,
                                tint = VidBookBlue,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "প্রফেশনাল ড্যাশবোর্ড",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        OutlinedButton(
                            onClick = { isAdvertiseDialogOpen = true },
                            modifier = Modifier
                                .weight(0.9f)
                                .testTag("advertise_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color(0xFFE65100)
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Campaign,
                                contentDescription = null,
                                tint = Color(0xFFE65100),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("বিজ্ঞাপন দিন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Copyright Status Card
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenCopyrightScreen() }
                            .testTag("profile_copyright_status_card"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = when (copyrightStatus.strikeCount) {
                                0 -> Color(0xFFE8F5E9).copy(alpha = 0.8f)
                                1 -> Color(0xFFFFF3E0).copy(alpha = 0.9f)
                                else -> Color(0xFFFFEBEE).copy(alpha = 0.95f)
                            }
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when (copyrightStatus.strikeCount) {
                                                0 -> Color(0xFF2E7D32)
                                                1 -> Color(0xFFE65100)
                                                else -> VidBookRed
                                            }
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (copyrightStatus.strikeCount == 0) Icons.Default.Security else Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "কপিরাইট স্ট্যাটাস",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = when (copyrightStatus.strikeCount) {
                                            0 -> "০টি স্ট্রাইক • চ্যানেল সম্পূর্ণ সুরক্ষিত"
                                            1 -> "১টি স্ট্রাইক • সতর্কবার্তা জারি রয়েছে"
                                            2 -> "২টি স্ট্রাইক • আপলোড ৩০ দিন স্থগিত"
                                            else -> "৩টি স্ট্রাইক • মনিটাইজেশন চিরতরে বন্ধ"
                                        },
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                                contentDescription = "কপিরাইট স্ট্যাটাস দেখুন",
                                tint = when (copyrightStatus.strikeCount) {
                                    0 -> Color(0xFF2E7D32)
                                    1 -> Color(0xFFE65100)
                                    else -> VidBookRed
                                },
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // 3 Strike Notice (Only on Profile screen when 3 strikes reached)
                    if (copyrightStatus.strikeCount >= 3 || copyrightStatus.isMonetizationDisabled) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenCopyrightScreen() }
                                .testTag("three_strikes_profile_banner"),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = VidBookRed)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "ইনকাম স্থায়ীভাবে বন্ধ",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "আপনার অ্যাকাউন্টে ৩টি কপিরাইট স্ট্রাইক আছে। আপনি আর ইনকাম করতে পারবেন না।",
                                        color = Color.White.copy(alpha = 0.95f),
                                        fontSize = 12.sp,
                                        lineHeight = 16.sp
                                    )
                                }
                            }
                        }
                    }
                } else {
                    // OTHER USER'S PROFILE: Follow / Unfollow button only (Requirement 3: অন্যের প্রোফাইলে এডিট বাটন দেখাবে না)
                    if (onToggleFollow != null) {
                        Button(
                            onClick = { onToggleFollow(user?.id ?: "user_bd_01") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(42.dp)
                                .testTag("profile_toggle_follow_btn"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isFollowing) MaterialTheme.colorScheme.surfaceVariant else VidBookBlue
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = if (isFollowing) Icons.Default.Check else Icons.Default.PersonAdd,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp),
                                tint = if (isFollowing) MaterialTheme.colorScheme.onSurface else Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isFollowing) "ফলো করছেন (Following)" else "ফলো করুন (Follow)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isFollowing) MaterialTheme.colorScheme.onSurface else Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Creator Monetization Level & Earnings Card (Only on Own Profile)
                if (isOwnProfile) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenMonetization() }
                            .testTag("profile_monetization_card"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(monetizationState.level.badgeColor.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = monetizationState.level.badgeEmoji, fontSize = 18.sp)
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "ক্রিয়েটর মনিটাইজেশন",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = monetizationState.level.badgeColor.copy(alpha = 0.15f)
                                        ) {
                                            Text(
                                                text = "Level ${monetizationState.level.levelNumber}",
                                                color = monetizationState.level.badgeColor,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = if (monetizationState.isSuspended) "মনিটাইজেশন স্থগিত রয়েছে" else "${monetizationState.level.title} • মোট আয়: $${String.format("%.2f", monetizationState.totalEarnings)}",
                                        fontSize = 11.sp,
                                        color = if (monetizationState.isSuspended) VidBookRed else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                                contentDescription = "মনিটাইজেশন দেখুন",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }

        // Facebook Profile Tabs Row: 0: All, 1: Photos, 2: Videos, 3: Reels, 4: More
        item {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 16.dp,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = VidBookBlue
            ) {
                listOf("সকল পোস্ট", "ফটো", "ভিডিও", "রিলস", "আরও").forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == index) VidBookBlue else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    )
                }
            }
        }

        // Tab Content
        when (selectedTab) {
            0 -> {
                // Tab 0: All Posts
                if (myPosts.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "এখনও কোনো পোস্ট করা হয়নি",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    items(myPosts) { post ->
                        SocialPostCard(
                            post = post,
                            onLikeClick = {},
                            onCommentClick = {},
                            onShareClick = {},
                            onAuthorClick = {}
                        )
                    }
                }
            }
            1 -> {
                // Tab 1: Photos Grid
                val photos = myPosts.mapNotNull { it.imageUrl }
                if (photos.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(48.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("কোনো ছবি পাওয়া যায়নি", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                } else {
                    item {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(3),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(320.dp)
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(photos) { photoUrl ->
                                AsyncImage(
                                    model = photoUrl,
                                    contentDescription = "প্রোফাইল ছবি",
                                    modifier = Modifier
                                        .aspectRatio(1f)
                                        .clip(RoundedCornerShape(4.dp)),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                    }
                }
            }
            2 -> {
                // Tab 2: Videos
                val longVideos = myVideos.filter { !it.isShort }
                if (longVideos.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.PlayCircleOutline, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(48.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("কোনো দীর্ঘ ভিডিও আপলোড করা হয়নি", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                } else {
                    items(longVideos) { video ->
                        VideoCard(
                            video = video,
                            onClick = { onVideoClick(video) },
                            onChannelClick = {}
                        )
                    }
                }
            }
            3 -> {
                // Tab 3: Reels
                val shortVideos = myVideos.filter { it.isShort }
                if (shortVideos.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Movie, contentDescription = null, tint = VidBookRed, modifier = Modifier.size(48.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("এখনও কোনো রিলস আপলোড হয়নি", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                } else {
                    item {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(3),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(360.dp)
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(shortVideos) { reel ->
                                Box(
                                    modifier = Modifier
                                        .aspectRatio(9f / 16f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .clickable { onVideoClick(reel) }
                                ) {
                                    AsyncImage(
                                        model = reel.thumbnailUrl,
                                        contentDescription = reel.title,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                    Row(
                                        modifier = Modifier
                                            .align(Alignment.BottomStart)
                                            .padding(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                        Text(text = "${reel.viewsCount} ভিউ", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            4 -> {
                // Tab 4: More Info
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "ক্রিয়েটর প্রোফাইল ও পেজ তথ্য",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )

                        MoreInfoItem(
                            icon = Icons.Default.Verified,
                            title = "ভেরিফিকেশন স্ট্যাটাস",
                            subtitle = "VidBook অফিশিয়াল ভেরিফাইড ক্রিয়েটর ব্যাজ সক্রিয়"
                        )

                        MoreInfoItem(
                            icon = Icons.Default.MonetizationOn,
                            title = "মনিটাইজেশন পার্টনার প্রোগ্রাম",
                            subtitle = "ইন-স্ট্রিম অ্যাডস ও স্টারস সক্রিয় (পেআউট IBBL-এ যুক্ত)"
                        )

                        MoreInfoItem(
                            icon = Icons.Default.Security,
                            title = "কন্টেন্ট পলিসি ও কপিরাইট হিস্ট্রি",
                            subtitle = "১০০% নিরাপদ ও ক্লিন প্রোফাইল (কোনো স্ট্রাইক নেই)"
                        )

                        MoreInfoItem(
                            icon = Icons.Default.Info,
                            title = "ক্যাটাগরি ও এরিয়া",
                            subtitle = "ডিজিটাল বিনোদন ও প্রযুক্তি • ঢাকা, বাংলাদেশ"
                        )
                    }
                }
            }
        }
    }

    // Advertise Campaign Dialog
    if (isAdvertiseDialogOpen) {
        AdvertiseDialog(
            onDismiss = { isAdvertiseDialogOpen = false },
            onStartCampaign = { goal, budget ->
                onShowSnackbar("বিজ্ঞাপন প্রচার সফলভাবে শুরু হয়েছে! লক্ষ্য: $goal ($budget)")
            }
        )
    }
}

/**
 * Facebook-style Full Screen Edit Profile Screen (Requirement 2).
 * Allows updating Name, Username, Bio, Avatar, and Cover Photo.
 * Photos upload to Cloudinary and profile data updates in Firebase Firestore.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProfileScreenView(
    user: UserProfile?,
    onBack: () -> Unit,
    onSave: (name: String, username: String, bio: String, avatarUri: String?, coverUri: String?) -> Unit
) {
    BackHandler { onBack() }

    var nameInput by remember(user) { mutableStateOf(user?.name ?: "") }
    var usernameInput by remember(user) {
        val u = user?.username ?: ""
        mutableStateOf(if (u.startsWith("@")) u.removePrefix("@") else u)
    }
    var bioInput by remember(user) { mutableStateOf(user?.bio ?: "") }
    var selectedAvatarUri by remember { mutableStateOf<String?>(null) }
    var selectedCoverUri by remember { mutableStateOf<String?>(null) }

    val avatarPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let { selectedAvatarUri = it.toString() }
    }

    val coverPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let { selectedCoverUri = it.toString() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "প্রোফাইল সম্পাদনা",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "ফিরে যান"
                        )
                    }
                },
                actions = {
                    Button(
                        onClick = {
                            onSave(nameInput, usernameInput, bioInput, selectedAvatarUri, selectedCoverUri)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VidBookBlue),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Text("সেভ করুন", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile Picture Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "প্রোফাইল ছবি",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        TextButton(
                            onClick = {
                                avatarPicker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                        ) {
                            Text("সম্পাদনা", color = VidBookBlue, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(contentAlignment = Alignment.BottomEnd) {
                            AsyncImage(
                                model = selectedAvatarUri ?: user?.avatarUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80",
                                contentDescription = "প্রোফাইল ছবি",
                                modifier = Modifier
                                    .size(110.dp)
                                    .clip(CircleShape)
                                    .border(3.dp, MaterialTheme.colorScheme.primary, CircleShape),
                                contentScale = ContentScale.Crop
                            )
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(VidBookBlue)
                                    .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape)
                                    .clickable {
                                        avatarPicker.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }

            // Cover Photo Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "কভার ছবি",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        TextButton(
                            onClick = {
                                coverPicker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                        ) {
                            Text("সম্পাদনা", color = VidBookBlue, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                coverPicker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                    ) {
                        AsyncImage(
                            model = selectedCoverUri ?: user?.coverUrl ?: "https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&q=80",
                            contentDescription = "কভার ছবি",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(8.dp)
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.7f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            // Bio & Details Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "ব্যক্তিগত তথ্য ও বায়ো",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )

                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("পূর্ণ নাম (Name)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    OutlinedTextField(
                        value = usernameInput,
                        onValueChange = { usernameInput = it.replace(" ", "").lowercase() },
                        label = { Text("ইউজারনেম (Username)") },
                        prefix = { Text("@", fontWeight = FontWeight.Bold, color = VidBookBlue) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    OutlinedTextField(
                        value = bioInput,
                        onValueChange = { bioInput = it },
                        label = { Text("বায়ো (Bio)") },
                        placeholder = { Text("আপনার সম্পর্কে সংক্ষিপ্ত পরিচিতি লিখুন...") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        maxLines = 4,
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Primary Save Button
            Button(
                onClick = {
                    onSave(nameInput, usernameInput, bioInput, selectedAvatarUri, selectedCoverUri)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = VidBookBlue),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "তথ্য সংরক্ষণ করুন",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }
    }
}

@Composable
fun MoreInfoItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(VidBookBlue.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = VidBookBlue, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun DashboardMiniStat(label: String, value: String, change: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
        Text(text = change, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF2E7D32))
        Text(text = label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun StatBox(label: String, value: String) {
    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier.width(80.dp)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                fontWeight = FontWeight.Black,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = label,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
