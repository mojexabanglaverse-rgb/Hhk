package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.VidBookBlue
import com.example.ui.theme.VidBookRed

@Composable
fun AdvertiseDialog(
    onDismiss: () -> Unit,
    onStartCampaign: (goal: String, budget: String) -> Unit
) {
    var selectedGoalIndex by remember { mutableIntStateOf(0) }
    val goals = listOf(
        "ভিডিও ভিউ ও ওয়াচটাইম বৃদ্ধি",
        "নতুন ফলোয়ার আকর্ষণ",
        "মেসেজ ও সোশ্যাল এনগেজমেন্ট"
    )

    var selectedBudgetIndex by remember { mutableIntStateOf(1) }
    val budgets = listOf(
        Pair("৳৩০০", "২ দিন • আনুমানিক ৩,০০০ - ৭,০০০ রিচ"),
        Pair("৳৫০০", "৩ দিন • আনুমানিক ৬,০০০ - ১৪,০০০ রিচ"),
        Pair("৳১,০০০", "৭ দিন • আনুমানিক ১৫,০০০ - ৩৫,০০০ রিচ")
    )

    var targetAudience by remember { mutableStateOf("বাংলাদেশ (১৮-৪৫ বছর, সব জেলা)") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Campaign,
                    contentDescription = null,
                    tint = VidBookBlue,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "VidBook অ্যাড সেন্টার — বিজ্ঞাপন দিন",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "বিজ্ঞাপনের মূল লক্ষ্য নির্বাচন করুন:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    goals.forEachIndexed { index, goal ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedGoalIndex = index },
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (selectedGoalIndex == index) VidBookBlue.copy(alpha = 0.12f)
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (selectedGoalIndex == index) Icons.Default.CheckCircle else Icons.Default.Visibility,
                                    contentDescription = null,
                                    tint = if (selectedGoalIndex == index) VidBookBlue else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = goal,
                                    fontSize = 12.sp,
                                    fontWeight = if (selectedGoalIndex == index) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedGoalIndex == index) VidBookBlue else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                Text(
                    text = "বাজেট ও সময়কাল নির্বাচন:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    budgets.forEachIndexed { index, (amount, duration) ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedBudgetIndex = index },
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (selectedBudgetIndex == index) Color(0xFF2E7D32).copy(alpha = 0.12f)
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = amount,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = if (selectedBudgetIndex == index) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = duration,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (selectedBudgetIndex == index) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = Color(0xFF2E7D32),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Text(
                    text = "অডিয়েন্স ও এলাকা:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                OutlinedTextField(
                    value = targetAudience,
                    onValueChange = { targetAudience = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val goal = goals[selectedGoalIndex]
                    val budget = budgets[selectedBudgetIndex].first
                    onStartCampaign(goal, budget)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = VidBookBlue),
                modifier = Modifier.testTag("start_ad_campaign_btn")
            ) {
                Text("বিজ্ঞাপন শুরু করুন", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}
