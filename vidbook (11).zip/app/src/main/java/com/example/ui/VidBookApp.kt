package com.example.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AuthDialog
import com.example.ui.components.CommentsBottomSheet
import com.example.ui.components.StoryViewerModal
import com.example.ui.components.UploadDialog
import com.example.ui.components.VidBookBottomBar
import com.example.ui.components.VidBookTopBar
import com.example.ui.screens.ChannelScreen
import com.example.ui.screens.CopyrightNoticeScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MonetizationScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.PostDetailScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ReelsScreen
import com.example.ui.screens.VideoDetailScreen
import com.example.ui.screens.VideosScreen

@Composable
fun VidBookApp(
    viewModel: VidBookViewModel,
    modifier: Modifier = Modifier
) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val activePlayingVideo by viewModel.activePlayingVideo.collectAsStateWithLifecycle()
    val viewingStory by viewModel.viewingStory.collectAsStateWithLifecycle()
    val activeCommentsTarget by viewModel.activeCommentsTarget.collectAsStateWithLifecycle()
    val activeCommentsList by viewModel.activeCommentsList.collectAsStateWithLifecycle()
    val isUploadDialogOpen by viewModel.isUploadDialogOpen.collectAsStateWithLifecycle()
    val isAuthDialogOpen by viewModel.isAuthDialogOpen.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()

    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val stories by viewModel.stories.collectAsStateWithLifecycle()
    val posts by viewModel.posts.collectAsStateWithLifecycle()
    val videos by viewModel.filteredVideos.collectAsStateWithLifecycle()
    val reels by viewModel.reels.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()

    val isScanningCopyright by viewModel.isScanningCopyright.collectAsStateWithLifecycle()
    val scanProgress by viewModel.scanProgress.collectAsStateWithLifecycle()
    val scanStage by viewModel.scanStage.collectAsStateWithLifecycle()
    val copyrightEvidence by viewModel.copyrightEvidence.collectAsStateWithLifecycle()
    val streamVaultUrl by viewModel.streamVaultBaseUrl.collectAsStateWithLifecycle()
    val followedUserIds by viewModel.followedUserIds.collectAsStateWithLifecycle()
    val userFollowersCountMap by viewModel.userFollowersCountMap.collectAsStateWithLifecycle()
    val activeChannelId by viewModel.activeChannelId.collectAsStateWithLifecycle()
    val userCopyrightStatus by viewModel.userCopyrightStatus.collectAsStateWithLifecycle()
    val copyrightNotices by viewModel.copyrightNotices.collectAsStateWithLifecycle()
    val isCopyrightNoticeScreenOpen by viewModel.isCopyrightNoticeScreenOpen.collectAsStateWithLifecycle()

    val monetizationState by viewModel.monetizationState.collectAsStateWithLifecycle()
    val isMonetizationScreenOpen by viewModel.isMonetizationScreenOpen.collectAsStateWithLifecycle()
    val activeViewingPost by viewModel.activeViewingPost.collectAsStateWithLifecycle()

    val unreadNotifsCount = remember(notifications) {
        notifications.count { !it.isRead }
    }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            // Hide top bar when viewing fullscreen Reels, playing video, or viewing Channel
            if (activePlayingVideo == null && currentTab != ScreenTab.REELS && activeChannelId == null) {
                VidBookTopBar(
                    searchQuery = searchQuery,
                    onSearchQueryChange = { viewModel.setSearchQuery(it) },
                    isDarkMode = isDarkMode,
                    onToggleDarkMode = { viewModel.toggleDarkMode() },
                    onOpenUpload = { viewModel.setUploadDialogOpen(true) }
                )
            }
        },
        bottomBar = {
            // Hide bottom bar when in full video detail player or viewing Channel
            if (activePlayingVideo == null && activeChannelId == null) {
                VidBookBottomBar(
                    currentTab = currentTab,
                    onTabSelected = { viewModel.setTab(it) },
                    onUploadClick = { viewModel.setUploadDialogOpen(true) },
                    unreadNotifsCount = unreadNotifsCount
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main Navigation Screen Container
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "ScreenTransition"
            ) { tab ->
                when (tab) {
                    ScreenTab.HOME -> HomeScreen(
                        currentUser = currentUser,
                        stories = stories,
                        posts = posts,
                        featuredVideos = videos,
                        onAddStoryClick = { viewModel.setUploadDialogOpen(true) },
                        onStoryClick = { viewModel.openStory(it) },
                        onOpenUpload = { viewModel.setUploadDialogOpen(true) },
                        onPostLike = { viewModel.togglePostLike(it) },
                        onPostComment = { viewModel.openComments(it.id, it.content.take(30)) },
                        onPostShare = { viewModel.showSnackbar("পোস্ট শেয়ার করা হয়েছে!") },
                        onVideoClick = { viewModel.openVideoDetail(it) },
                        onAuthorClick = { viewModel.openChannel(it) },
                        onChannelClick = { viewModel.openChannel(it) }
                    )

                    ScreenTab.VIDEOS -> VideosScreen(
                        videos = videos,
                        selectedCategory = selectedCategory,
                        onSelectCategory = { viewModel.selectCategory(it) },
                        searchQuery = searchQuery,
                        onVideoClick = { viewModel.openVideoDetail(it) },
                        onChannelClick = { viewModel.openChannel(it) }
                    )

                    ScreenTab.REELS -> ReelsScreen(
                        reels = reels,
                        onLikeClick = { viewModel.toggleVideoLike(it) },
                        onCommentClick = { viewModel.openComments(it.id, it.title) },
                        onSubscribeClick = { viewModel.toggleChannelSubscribe(it.channelId, it.isSubscribed) }
                    )

                    ScreenTab.NOTIFICATIONS -> NotificationsScreen(
                        notifications = notifications,
                        onMarkAllAsRead = { viewModel.markAllNotificationsRead() },
                        onNotificationClick = { viewModel.handleNotificationClick(it) }
                    )

                    ScreenTab.PROFILE -> ProfileScreen(
                        user = currentUser,
                        myPosts = posts.filter { it.authorId == (currentUser?.id ?: "user_bd_01") },
                        myVideos = videos.filter { it.channelId == (currentUser?.id ?: "ch_01") || it.channelId == "ch_natok" },
                        onAddStoryClick = { viewModel.setUploadDialogOpen(true) },
                        onShowSnackbar = { viewModel.showSnackbar(it) },
                        onOpenAuthDialog = { viewModel.setAuthDialogOpen(true) },
                        onLogout = { viewModel.logout() },
                        onUpdateProfile = { name, bio -> viewModel.updateProfile(name, bio) },
                        onSaveFullProfile = { name, username, bio, avatarUri, coverUri ->
                            viewModel.updateFullProfile(name, username, bio, avatarUri, coverUri)
                        },
                        onUpdateAvatarPhoto = { viewModel.updateAvatarPhoto(it) },
                        onUpdateCoverPhoto = { viewModel.updateCoverPhoto(it) },
                        onVideoClick = { viewModel.openVideoDetail(it) },
                        isOwnProfile = true,
                        isFollowing = followedUserIds.contains(currentUser?.id ?: "user_bd_01"),
                        followersCountOverride = userFollowersCountMap[currentUser?.id ?: "user_bd_01"],
                        onToggleFollow = { viewModel.toggleFollow(it) },
                        copyrightStatus = userCopyrightStatus,
                        onOpenCopyrightScreen = { viewModel.openCopyrightNoticeScreen() },
                        monetizationState = monetizationState,
                        onOpenMonetization = { viewModel.openMonetizationScreen() }
                    )
                }
            }

            // Dedicated Fullscreen / High Detail Video Player Screen
            activePlayingVideo?.let { playingVideo ->
                VideoDetailScreen(
                    video = playingVideo,
                    upNextVideos = videos,
                    onBack = { viewModel.closeVideoDetail() },
                    onLikeClick = { viewModel.toggleVideoLike(playingVideo) },
                    onSubscribeClick = { viewModel.toggleChannelSubscribe(playingVideo.channelId, playingVideo.isSubscribed) },
                    onCommentClick = { viewModel.openComments(playingVideo.id, playingVideo.title) },
                    onSelectUpNext = { viewModel.openVideoDetail(it) },
                    onIncrementViewCount = { viewModel.incrementViewCount(it) },
                    onChannelClick = { viewModel.openChannel(it) }
                )
            }

            // YouTube & Facebook Style Channel / Profile Page
            activeChannelId?.let { channelId ->
                val channelInfo = viewModel.getChannelInfo(channelId)
                val channelVideos = viewModel.getVideosForChannel(channelId)
                ChannelScreen(
                    channel = channelInfo,
                    videos = channelVideos,
                    onBack = { viewModel.closeChannel() },
                    onVideoClick = { viewModel.openVideoDetail(it) },
                    onSubscribeClick = {
                        viewModel.toggleChannelSubscribe(channelId, channelInfo.isSubscribed)
                    }
                )
            }

            // 24h Story Viewer Modal
            viewingStory?.let { story ->
                StoryViewerModal(
                    story = story,
                    onClose = { viewModel.closeStory() },
                    onReply = { reply ->
                        viewModel.showSnackbar("স্টোরিতে রিপ্লাই পাঠানো হয়েছে: $reply")
                    }
                )
            }

            // Comments Bottom Sheet
            activeCommentsTarget?.let { target ->
                CommentsBottomSheet(
                    targetTitle = target.second,
                    comments = activeCommentsList,
                    onDismiss = { viewModel.closeComments() },
                    onAddComment = { text -> viewModel.addComment(text) }
                )
            }

            // Upload Post / Video Dialog
            if (isUploadDialogOpen) {
                UploadDialog(
                    onDismiss = {
                        viewModel.clearCopyrightScan()
                        viewModel.setUploadDialogOpen(false)
                    },
                    onPublishPost = { content, imageUri ->
                        viewModel.createPost(content, imageUri)
                    },
                    onUploadVideo = { title, desc, cat, vUri, thumbUri, isShort ->
                        viewModel.uploadVideo(title, desc, cat, vUri, thumbUri, isShort)
                    },
                    isScanningCopyright = isScanningCopyright,
                    scanProgress = scanProgress,
                    scanStage = scanStage,
                    copyrightEvidence = copyrightEvidence,
                    userCopyrightStatus = userCopyrightStatus,
                    onScanVideo = { uri, title -> viewModel.scanVideoForCopyright(uri, title) },
                    onClearScan = { viewModel.clearCopyrightScan() },
                    onSubmitDispute = { evidence, reason -> viewModel.submitCopyrightDispute(evidence, reason) }
                )
            }

            // YouTube-style Copyright Notice & Strike Center Screen
            if (isCopyrightNoticeScreenOpen) {
                CopyrightNoticeScreen(
                    copyrightStatus = userCopyrightStatus,
                    notices = copyrightNotices,
                    onBack = { viewModel.closeCopyrightNoticeScreen() },
                    onSubmitDispute = { noticeId, reason ->
                        viewModel.submitCopyrightNoticeDispute(noticeId, reason)
                    }
                )
            }

            // Creator Monetization & Withdrawal Screen (Level 0 to Level 3)
            if (isMonetizationScreenOpen) {
                MonetizationScreen(
                    state = monetizationState,
                    onBack = { viewModel.closeMonetizationScreen() },
                    onRequestWithdrawal = { method, amount, destination ->
                        viewModel.requestWithdrawal(method, amount, destination)
                    }
                )
            }

            // Facebook-style Single Post Detail Screen (when clicking Post/Like/Comment notification)
            activeViewingPost?.let { viewingPost ->
                PostDetailScreen(
                    post = viewingPost,
                    comments = activeCommentsList,
                    onBack = { viewModel.closePostDetail() },
                    onLikeClick = { viewModel.togglePostLike(viewingPost) },
                    onCommentClick = { viewModel.openComments(viewingPost.id, viewingPost.content.take(30)) },
                    onShareClick = { viewModel.showSnackbar("পোস্ট শেয়ার করা হয়েছে!") },
                    onAuthorClick = { viewModel.openChannel(it) },
                    onAddComment = { viewModel.addComment(it) }
                )
            }

            // Firebase Authentication Dialog
            if (isAuthDialogOpen) {
                AuthDialog(
                    onDismiss = { viewModel.setAuthDialogOpen(false) },
                    onLogin = { email, pass -> viewModel.login(email, pass) },
                    onRegister = { email, pass, name -> viewModel.register(email, pass, name) }
                )
            }
        }
    }
}
