package com.example.data.remote

import android.util.Log
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

/**
 * Production-ready Firestore Manager for VidBook.
 * Updates user follower counts and video view counts directly in Firebase Firestore.
 */
object FirebaseFirestoreManager {

    private const val TAG = "FirestoreManager"

    private val firestore: FirebaseFirestore? by lazy {
        try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.w(TAG, "Firebase Firestore not initialized or google-services.json missing.", e)
            null
        }
    }

    /**
     * Updates the follower count for a user in Firestore (users/{userId}).
     * Increments by +1 on follow, -1 on unfollow.
     */
    suspend fun updateFollowerCount(userId: String, delta: Long): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val userRef = db.collection("users").document(userId)
            userRef.set(
                mapOf(
                    "followersCount" to FieldValue.increment(delta),
                    "lastUpdated" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()
            Log.d(TAG, "Updated followersCount for $userId by $delta in Firestore")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to update followersCount in Firestore for $userId", e)
            Result.failure(e)
        }
    }

    /**
     * Updates full user profile details in Firestore (users/{userId}).
     */
    suspend fun updateUserProfileInFirestore(
        userId: String,
        name: String,
        username: String,
        bio: String,
        avatarUrl: String? = null,
        coverUrl: String? = null
    ): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val userRef = db.collection("users").document(userId)
            val data = mutableMapOf<String, Any?>(
                "name" to name,
                "username" to username,
                "bio" to bio,
                "lastUpdated" to FieldValue.serverTimestamp()
            )
            if (!avatarUrl.isNullOrBlank()) data["avatarUrl"] = avatarUrl
            if (!coverUrl.isNullOrBlank()) data["coverUrl"] = coverUrl
            userRef.set(data, SetOptions.merge()).await()
            Log.d(TAG, "Updated user profile for $userId in Firestore")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to update profile in Firestore for $userId", e)
            Result.failure(e)
        }
    }

    /**
     * Increments the view count for a video in Firestore (videos/{videoId}).
     */
    suspend fun incrementVideoViewCount(videoId: String): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val videoRef = db.collection("videos").document(videoId)
            videoRef.set(
                mapOf(
                    "viewsCount" to FieldValue.increment(1),
                    "lastViewed" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()
            Log.d(TAG, "Incremented viewsCount for $videoId in Firestore")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to increment viewsCount in Firestore for $videoId", e)
            Result.failure(e)
        }
    }

    /**
     * Saves or updates a user's copyright status (strikes, upload block, monetization ban) in Firestore.
     */
    suspend fun saveUserCopyrightStatus(
        userId: String,
        strikeCount: Int,
        isUploadBlocked: Boolean,
        uploadBlockedUntil: Long,
        isMonetizationDisabled: Boolean
    ): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val statusRef = db.collection("users").document(userId).collection("copyright").document("status")
            statusRef.set(
                mapOf(
                    "strikeCount" to strikeCount,
                    "isUploadBlocked" to isUploadBlocked,
                    "uploadBlockedUntil" to uploadBlockedUntil,
                    "isMonetizationDisabled" to isMonetizationDisabled,
                    "lastUpdated" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()
            Log.d(TAG, "Saved copyright status for $userId in Firestore: strikes=$strikeCount")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to save copyright status for $userId in Firestore", e)
            Result.failure(e)
        }
    }

    /**
     * Saves a copyright notice for a user in Firestore (users/{userId}/copyright_notices/{noticeId}).
     */
    suspend fun saveCopyrightNotice(
        userId: String,
        noticeId: String,
        videoTitle: String,
        thumbnailUrl: String? = null,
        copyrightOwner: String,
        matchType: String,
        strikeNumber: Int,
        status: String,
        date: String,
        timestamp: Long,
        penaltyDescription: String
    ): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val noticeRef = db.collection("users").document(userId)
                .collection("copyright_notices").document(noticeId)
            val data = mutableMapOf<String, Any?>(
                "id" to noticeId,
                "userId" to userId,
                "videoTitle" to videoTitle,
                "copyrightOwner" to copyrightOwner,
                "matchType" to matchType,
                "strikeNumber" to strikeNumber,
                "status" to status,
                "date" to date,
                "timestamp" to timestamp,
                "penaltyDescription" to penaltyDescription,
                "createdAt" to FieldValue.serverTimestamp()
            )
            if (!thumbnailUrl.isNullOrBlank()) {
                data["thumbnailUrl"] = thumbnailUrl
            }
            noticeRef.set(data, SetOptions.merge()).await()
            Log.d(TAG, "Saved copyright notice $noticeId for $userId in Firestore")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to save copyright notice in Firestore", e)
            Result.failure(e)
        }
    }

    /**
     * Updates dispute reason for a copyright notice in Firestore.
     */
    suspend fun submitDisputeInFirestore(
        userId: String,
        noticeId: String,
        disputeReason: String
    ): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val noticeRef = db.collection("users").document(userId)
                .collection("copyright_notices").document(noticeId)
            noticeRef.set(
                mapOf(
                    "status" to "DISPUTED",
                    "disputeReason" to disputeReason,
                    "disputedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Saves complete Monetization status in Firebase Firestore (users/{userId}/monetization/status).
     * Includes level, watchTimeMinutes, followersCount, strikeCount, monetizationStatus, earnings.
     */
    suspend fun saveMonetizationState(
        userId: String,
        level: Int,
        watchTimeMinutes: Long,
        followersCount: Int,
        strikeCount: Int,
        monetizationStatus: String,
        totalEarnings: Double,
        dailyEarnings: Double,
        isSuspended: Boolean
    ): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val docRef = db.collection("users").document(userId)
                .collection("monetization").document("status")
            docRef.set(
                mapOf(
                    "level" to level,
                    "watchTimeMinutes" to watchTimeMinutes,
                    "followersCount" to followersCount,
                    "strikeCount" to strikeCount,
                    "monetizationStatus" to monetizationStatus,
                    "earnings" to mapOf(
                        "total" to totalEarnings,
                        "daily" to dailyEarnings
                    ),
                    "isSuspended" to isSuspended,
                    "lastUpdated" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()
            Log.d(TAG, "Saved monetization state for $userId: Level $level, status=$monetizationStatus")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to save monetization state for $userId in Firestore", e)
            Result.failure(e)
        }
    }

    /**
     * Records a withdrawal in Firebase Firestore (users/{userId}/withdrawals/{withdrawalId}).
     */
    suspend fun recordWithdrawalInFirestore(
        userId: String,
        withdrawalId: String,
        method: String,
        amount: Double,
        destination: String,
        status: String,
        dateFormatted: String
    ): Result<Unit> {
        val db = firestore ?: return Result.success(Unit)
        return try {
            val docRef = db.collection("users").document(userId)
                .collection("withdrawals").document(withdrawalId)
            docRef.set(
                mapOf(
                    "id" to withdrawalId,
                    "userId" to userId,
                    "method" to method,
                    "amount" to amount,
                    "destination" to destination,
                    "status" to status,
                    "date" to dateFormatted,
                    "timestamp" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()
            Log.d(TAG, "Recorded withdrawal $withdrawalId for $userId: $$amount via $method")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to record withdrawal in Firestore", e)
            Result.failure(e)
        }
    }
}
