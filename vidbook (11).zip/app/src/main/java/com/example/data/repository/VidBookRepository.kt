package com.example.data.repository

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.example.data.local.CommentEntity
import com.example.data.local.NotificationEntity
import com.example.data.local.PostEntity
import com.example.data.local.StoryEntity
import com.example.data.local.VidBookDatabase
import com.example.data.local.VideoEntity
import com.example.data.model.Comment
import com.example.data.model.NotificationItem
import com.example.data.model.NotificationType
import com.example.data.model.Post
import com.example.data.model.Story
import com.example.data.model.UserProfile
import com.example.data.model.Video
import com.example.data.remote.CloudinaryService
import com.example.data.remote.FirebaseAuthManager
import com.example.data.remote.FirebaseFirestoreManager
import com.example.data.remote.StreamVaultClient
import com.example.copyright.data.CopyrightDao
import com.example.copyright.data.CopyrightModerationActionEntity
import com.example.copyright.data.CopyrightReferenceEntity
import com.example.copyright.engine.CopyrightScanEngine
import com.example.copyright.fingerprint.AudioFingerprintExtractor
import com.example.copyright.fingerprint.PerceptualVideoHasher
import com.example.copyright.fingerprint.Sha256Hasher
import com.example.copyright.model.CopyrightScanEvidence
import com.example.copyright.model.CopyrightNotice
import com.example.copyright.model.CopyrightNoticeStatus
import com.example.copyright.model.UserCopyrightStatus
import com.example.data.model.CreatorLevel
import com.example.data.model.CreatorMonetizationState
import com.example.data.model.WithdrawalMethod
import com.example.data.model.WithdrawalRecord
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class VidBookRepository(private val context: Context) {

    private val db = VidBookDatabase.getDatabase(context)
    private val postDao = db.postDao()
    private val videoDao = db.videoDao()
    private val storyDao = db.storyDao()
    private val commentDao = db.commentDao()
    private val notificationDao = db.notificationDao()
    val copyrightDao: CopyrightDao = db.copyrightDao()
    val copyrightEngine = CopyrightScanEngine(context, copyrightDao, videoDao)

    val authManager = FirebaseAuthManager(context)

    private val prefs = context.getSharedPreferences("vidbook_copyright_prefs", Context.MODE_PRIVATE)

    private val _userCopyrightStatus = MutableStateFlow(
        UserCopyrightStatus(
            strikeCount = prefs.getInt("strike_count", 0),
            isUploadBlocked = prefs.getBoolean("is_upload_blocked", false) && prefs.getLong("upload_blocked_until", 0L) > System.currentTimeMillis(),
            uploadBlockedUntil = prefs.getLong("upload_blocked_until", 0L),
            isMonetizationDisabled = prefs.getBoolean("is_monetization_disabled", false)
        )
    )
    val userCopyrightStatus: Flow<UserCopyrightStatus> = _userCopyrightStatus

    private val _copyrightNotices = MutableStateFlow<List<CopyrightNotice>>(emptyList())
    val copyrightNotices: Flow<List<CopyrightNotice>> = _copyrightNotices

    // Monetization System State (Level 0 to Level 3, Watch Time, Earnings & Withdrawals)
    private val _monetizationState = MutableStateFlow(
        CreatorMonetizationState(
            level = CreatorLevel.LEVEL_2,
            followersCount = 450,
            requiredFollowers = 600,
            watchTimeHours = 2100.0,
            requiredWatchTimeHours = 3300.0,
            strikeCount = prefs.getInt("strike_count", 0),
            maxStrikes = 3,
            accountAgeDays = 25,
            requiredAccountDays = 30,
            isSuspended = prefs.getInt("strike_count", 0) >= 3 || prefs.getBoolean("is_monetization_disabled", false),
            totalEarnings = 342.50,
            dailyEarnings = 18.40
        )
    )
    val monetizationState: Flow<CreatorMonetizationState> = _monetizationState

    // In-memory prepend buffer to ensure newly created posts & videos appear immediately at index 0
    private val _createdPosts = MutableStateFlow<List<Post>>(emptyList())
    private val _uploadedVideos = MutableStateFlow<List<Video>>(emptyList())

    init {
        StreamVaultClient.init(context)
        loadSavedNotices()
        loadMonetizationFromPrefs()
        CoroutineScope(Dispatchers.IO).launch {
            seedInitialDataIfEmpty()
        }
    }

    private fun loadSavedNotices() {
        val count = prefs.getInt("notice_count", 0)
        val loaded = mutableListOf<CopyrightNotice>()
        for (i in 0 until count) {
            val id = prefs.getString("notice_${i}_id", null) ?: continue
            val videoTitle = prefs.getString("notice_${i}_title", "ভিডিও") ?: "ভিডিও"
            val thumb = prefs.getString("notice_${i}_thumb", null)
            val owner = prefs.getString("notice_${i}_owner", "স্বত্বাধিকারী") ?: "স্বত্বাধিকারী"
            val matchType = prefs.getString("notice_${i}_match_type", "কপিরাইট ম্যাচ") ?: "কপিরাইট ম্যাচ"
            val strikeNum = prefs.getInt("notice_${i}_strike", 1)
            val statusStr = prefs.getString("notice_${i}_status", "ACTIVE") ?: "ACTIVE"
            val date = prefs.getString("notice_${i}_date", "আজ") ?: "আজ"
            val timestamp = prefs.getLong("notice_${i}_timestamp", System.currentTimeMillis())
            val penalty = prefs.getString("notice_${i}_penalty", "") ?: ""
            val disputeReason = prefs.getString("notice_${i}_dispute", null)

            val status = try {
                CopyrightNoticeStatus.valueOf(statusStr)
            } catch (e: Exception) {
                CopyrightNoticeStatus.ACTIVE
            }

            loaded.add(
                CopyrightNotice(
                    id = id,
                    userId = authManager.currentUserState.value?.id ?: "user_bd_01",
                    videoTitle = videoTitle,
                    thumbnailUrl = thumb,
                    copyrightOwner = owner,
                    matchType = matchType,
                    strikeNumber = strikeNum,
                    status = status,
                    date = date,
                    timestamp = timestamp,
                    penaltyDescription = penalty,
                    disputeReason = disputeReason
                )
            )
        }
        _copyrightNotices.value = loaded
    }

    private fun saveNoticesToPrefs(list: List<CopyrightNotice>) {
        val editor = prefs.edit()
        editor.putInt("notice_count", list.size)
        list.forEachIndexed { i, notice ->
            editor.putString("notice_${i}_id", notice.id)
            editor.putString("notice_${i}_title", notice.videoTitle)
            editor.putString("notice_${i}_thumb", notice.thumbnailUrl)
            editor.putString("notice_${i}_owner", notice.copyrightOwner)
            editor.putString("notice_${i}_match_type", notice.matchType)
            editor.putInt("notice_${i}_strike", notice.strikeNumber)
            editor.putString("notice_${i}_status", notice.status.name)
            editor.putString("notice_${i}_date", notice.date)
            editor.putLong("notice_${i}_timestamp", notice.timestamp)
            editor.putString("notice_${i}_penalty", notice.penaltyDescription)
            editor.putString("notice_${i}_dispute", notice.disputeReason)
        }
        editor.apply()
    }

    private fun calculateLevel(followers: Int, watchTime: Double, strikes: Int, accountAgeDays: Int, isSuspended: Boolean): CreatorLevel {
        if (isSuspended || strikes >= 3) return CreatorLevel.LEVEL_0
        return when {
            followers >= 600 && watchTime >= 3300.0 && strikes == 0 && accountAgeDays >= 30 -> CreatorLevel.LEVEL_3
            followers >= 300 && watchTime >= 1500.0 -> CreatorLevel.LEVEL_2
            followers >= 100 && watchTime >= 500.0 -> CreatorLevel.LEVEL_1
            else -> CreatorLevel.LEVEL_0
        }
    }

    private fun loadMonetizationFromPrefs() {
        val followers = prefs.getInt("monetization_followers", 450)
        val watchTime = prefs.getFloat("monetization_watch_time", 2100.0f).toDouble()
        val strikes = prefs.getInt("strike_count", 0)
        val accountAge = prefs.getInt("monetization_account_age", 25)
        val isSuspended = strikes >= 3 || prefs.getBoolean("is_monetization_disabled", false)
        val totalEarnings = prefs.getFloat("monetization_total_earnings", 342.50f).toDouble()
        val dailyEarnings = prefs.getFloat("monetization_daily_earnings", 18.40f).toDouble()
        val lastWdMonth = prefs.getString("monetization_last_wd_month", null)

        val historyCount = prefs.getInt("wd_history_count", 0)
        val history = mutableListOf<WithdrawalRecord>()
        for (i in 0 until historyCount) {
            val id = prefs.getString("wd_${i}_id", null) ?: continue
            val methodId = prefs.getString("wd_${i}_method_id", "btc") ?: "btc"
            val methodName = prefs.getString("wd_${i}_method_name", "Bitcoin (BTC)") ?: "Bitcoin (BTC)"
            val amount = prefs.getFloat("wd_${i}_amount", 0f).toDouble()
            val destination = prefs.getString("wd_${i}_dest", "") ?: ""
            val status = prefs.getString("wd_${i}_status", "Processing (৩-৭ কার্যদিবস)") ?: "Processing (৩-৭ কার্যদিবস)"
            val timestamp = prefs.getLong("wd_${i}_timestamp", System.currentTimeMillis())
            val dateFormatted = prefs.getString("wd_${i}_date", "আজ") ?: "আজ"
            history.add(
                WithdrawalRecord(
                    id = id,
                    methodId = methodId,
                    methodName = methodName,
                    amount = amount,
                    destination = destination,
                    status = status,
                    timestamp = timestamp,
                    dateFormatted = dateFormatted
                )
            )
        }

        val level = calculateLevel(followers, watchTime, strikes, accountAge, isSuspended)
        _monetizationState.value = CreatorMonetizationState(
            level = level,
            followersCount = followers,
            requiredFollowers = 600,
            watchTimeHours = watchTime,
            requiredWatchTimeHours = 3300.0,
            strikeCount = strikes,
            maxStrikes = 3,
            accountAgeDays = accountAge,
            requiredAccountDays = 30,
            isSuspended = isSuspended,
            totalEarnings = totalEarnings,
            dailyEarnings = dailyEarnings,
            withdrawalHistory = history,
            lastWithdrawalMonthYear = lastWdMonth
        )
    }

    private fun saveMonetizationToPrefs(state: CreatorMonetizationState) {
        val editor = prefs.edit()
        editor.putInt("monetization_followers", state.followersCount)
        editor.putFloat("monetization_watch_time", state.watchTimeHours.toFloat())
        editor.putInt("monetization_account_age", state.accountAgeDays)
        editor.putFloat("monetization_total_earnings", state.totalEarnings.toFloat())
        editor.putFloat("monetization_daily_earnings", state.dailyEarnings.toFloat())
        editor.putString("monetization_last_wd_month", state.lastWithdrawalMonthYear)

        editor.putInt("wd_history_count", state.withdrawalHistory.size)
        state.withdrawalHistory.forEachIndexed { i, record ->
            editor.putString("wd_${i}_id", record.id)
            editor.putString("wd_${i}_method_id", record.methodId)
            editor.putString("wd_${i}_method_name", record.methodName)
            editor.putFloat("wd_${i}_amount", record.amount.toFloat())
            editor.putString("wd_${i}_dest", record.destination)
            editor.putString("wd_${i}_status", record.status)
            editor.putLong("wd_${i}_timestamp", record.timestamp)
            editor.putString("wd_${i}_date", record.dateFormatted)
        }
        editor.apply()
    }

    fun isUserUploadBlocked(): Pair<Boolean, String?> {
        val status = _userCopyrightStatus.value
        val now = System.currentTimeMillis()
        if (status.isUploadBlocked && status.uploadBlockedUntil > now) {
            val remainingDays = ((status.uploadBlockedUntil - now) / (24 * 3600 * 1000L)).coerceAtLeast(1)
            return Pair(true, "আপনার অ্যাকাউন্টে ২য় কপিরাইট স্ট্রাইকের কারণে ভিডিও আপলোড সুবিধা আরও $remainingDays দিনের জন্য স্থগিত রয়েছে।")
        }
        return Pair(false, null)
    }

    suspend fun recordCopyrightStrike(
        evidence: CopyrightScanEvidence,
        videoTitle: String,
        videoUri: String? = null,
        thumbnailUrl: String? = null
    ): UserCopyrightStatus {
        val current = _userCopyrightStatus.value
        val newStrikeCount = (current.strikeCount + 1).coerceAtMost(3)
        val currentUserId = authManager.currentUserState.value?.id ?: "user_bd_01"

        val isUploadBlocked = newStrikeCount >= 2
        val uploadBlockedUntil = if (newStrikeCount >= 2) {
            System.currentTimeMillis() + 30L * 24 * 3600 * 1000L
        } else {
            0L
        }
        val isMonetizationDisabled = newStrikeCount >= 3 || current.isMonetizationDisabled

        val newStatus = UserCopyrightStatus(
            strikeCount = newStrikeCount,
            isUploadBlocked = isUploadBlocked,
            uploadBlockedUntil = uploadBlockedUntil,
            isMonetizationDisabled = isMonetizationDisabled,
            lastUpdated = System.currentTimeMillis()
        )

        // Save status locally
        prefs.edit()
            .putInt("strike_count", newStrikeCount)
            .putBoolean("is_upload_blocked", isUploadBlocked)
            .putLong("upload_blocked_until", uploadBlockedUntil)
            .putBoolean("is_monetization_disabled", isMonetizationDisabled)
            .apply()
        _userCopyrightStatus.value = newStatus

        // Format date in Bengali style
        val dateFormat = SimpleDateFormat("dd MMM, yyyy", Locale("bn", "BD"))
        val dateString = try { dateFormat.format(Date()) } catch (e: Exception) { "আজ" }

        val matchTypeDisplay = when {
            evidence.exactSha256Match -> "SHA-256 হুবহু ডুপ্লিকেট"
            evidence.matchType == "PERCEPTUAL_VIDEO" -> "Visual Fingerprint (ভিজ্যুয়াল ফ্রেম মিল)"
            evidence.matchType == "AUDIO_ONLY" -> "Audio Fingerprint (অডিও মিল)"
            else -> "Visual ও Audio Fingerprint মাল্টি-মডাল মিল"
        }

        val penaltyDescription = when (newStrikeCount) {
            1 -> "১ম স্ট্রাইক: সতর্কবার্তা প্রদান করা হয়েছে।"
            2 -> "২য় স্ট্রাইক: ভিডিও ও রিলস আপলোড সুবিধা স্থগিত করা হয়েছে।"
            else -> "আপনার অ্যাকাউন্টে ৩টি কপিরাইট স্ট্রাইক আছে। আপনি আর ইনকাম করতে পারবেন না।"
        }

        val noticeId = "notice_${System.currentTimeMillis()}"
        val copyrightOwner = evidence.matchedReferenceTitle ?: "অরিজিনাল স্বত্বাধিকারী (VidBook Registry)"

        val notice = CopyrightNotice(
            id = noticeId,
            userId = currentUserId,
            videoTitle = videoTitle,
            videoUri = videoUri,
            thumbnailUrl = thumbnailUrl,
            copyrightOwner = copyrightOwner,
            matchType = matchTypeDisplay,
            strikeNumber = newStrikeCount,
            status = CopyrightNoticeStatus.ACTIVE,
            date = dateString,
            timestamp = System.currentTimeMillis(),
            penaltyDescription = penaltyDescription
        )

        val updatedNotices = listOf(notice) + _copyrightNotices.value
        _copyrightNotices.value = updatedNotices
        saveNoticesToPrefs(updatedNotices)

        // Firebase Firestore persistence
        CoroutineScope(Dispatchers.IO).launch {
            FirebaseFirestoreManager.saveUserCopyrightStatus(
                userId = currentUserId,
                strikeCount = newStrikeCount,
                isUploadBlocked = isUploadBlocked,
                uploadBlockedUntil = uploadBlockedUntil,
                isMonetizationDisabled = isMonetizationDisabled
            )

            FirebaseFirestoreManager.saveCopyrightNotice(
                userId = currentUserId,
                noticeId = noticeId,
                videoTitle = videoTitle,
                thumbnailUrl = thumbnailUrl,
                copyrightOwner = copyrightOwner,
                matchType = matchTypeDisplay,
                strikeNumber = newStrikeCount,
                status = "ACTIVE",
                date = dateString,
                timestamp = System.currentTimeMillis(),
                penaltyDescription = penaltyDescription
            )
        }

        // 4. ৩ Strike হলে: Monetization SUSPENDED, Level 0 তে নামবে, লাল রঙে দেখাবে
        if (newStrikeCount >= 3) {
            val currMonetization = _monetizationState.value
            val suspendedMonetization = currMonetization.copy(
                strikeCount = newStrikeCount,
                isSuspended = true,
                level = CreatorLevel.LEVEL_0
            )
            _monetizationState.value = suspendedMonetization
            saveMonetizationToPrefs(suspendedMonetization)
            CoroutineScope(Dispatchers.IO).launch {
                FirebaseFirestoreManager.saveMonetizationState(
                    userId = currentUserId,
                    level = 0,
                    watchTimeMinutes = (suspendedMonetization.watchTimeHours * 60).toLong(),
                    followersCount = suspendedMonetization.followersCount,
                    strikeCount = newStrikeCount,
                    monetizationStatus = "SUSPENDED",
                    totalEarnings = suspendedMonetization.totalEarnings,
                    dailyEarnings = suspendedMonetization.dailyEarnings,
                    isSuspended = true
                )
            }
        }

        return newStatus
    }

    suspend fun requestWithdrawal(
        method: WithdrawalMethod,
        amount: Double,
        destination: String
    ): Pair<Boolean, String> {
        val current = _monetizationState.value
        val currentUserId = authManager.currentUserState.value?.id ?: "user_bd_01"

        if (current.isSuspended || current.level != CreatorLevel.LEVEL_3) {
            return Pair(false, "উত্তোলন সুবিধা শুধুমাত্র সক্রিয় Level 3 ক্রিয়েটরদের জন্য প্রযোজ্য।")
        }
        if (amount < method.minAmount) {
            return Pair(false, "মিনিমাম $${method.minAmount.toInt()} প্রয়োজন।")
        }
        if (amount > current.totalEarnings) {
            return Pair(false, "আপনার অ্যাকাউন্টে পর্যাপ্ত ব্যালেন্স নেই।")
        }

        val monthFormat = SimpleDateFormat("yyyy-MM", Locale.US)
        val currentMonth = monthFormat.format(Date())
        if (current.lastWithdrawalMonthYear == currentMonth) {
            return Pair(false, "প্রতি মাসে একবারই Withdrawal করা যাবে। আগামী মাসে আবার চেষ্টা করুন।")
        }

        val dateFormat = SimpleDateFormat("dd MMM, yyyy", Locale("bn", "BD"))
        val dateStr = try { dateFormat.format(Date()) } catch (e: Exception) { "আজ" }
        val recordId = "wd_${System.currentTimeMillis()}"

        val record = WithdrawalRecord(
            id = recordId,
            methodId = method.id,
            methodName = method.displayName,
            amount = amount,
            destination = destination,
            status = "Processing (৩-৭ কার্যদিবস)",
            timestamp = System.currentTimeMillis(),
            dateFormatted = dateStr
        )

        val updatedBalance = (current.totalEarnings - amount).coerceAtLeast(0.0)
        val updatedHistory = listOf(record) + current.withdrawalHistory
        val newState = current.copy(
            totalEarnings = updatedBalance,
            withdrawalHistory = updatedHistory,
            lastWithdrawalMonthYear = currentMonth
        )
        _monetizationState.value = newState
        saveMonetizationToPrefs(newState)

        CoroutineScope(Dispatchers.IO).launch {
            FirebaseFirestoreManager.recordWithdrawalInFirestore(
                userId = currentUserId,
                withdrawalId = recordId,
                method = method.displayName,
                amount = amount,
                destination = destination,
                status = record.status,
                dateFormatted = dateStr
            )
            FirebaseFirestoreManager.saveMonetizationState(
                userId = currentUserId,
                level = newState.level.levelNumber,
                watchTimeMinutes = (newState.watchTimeHours * 60).toLong(),
                followersCount = newState.followersCount,
                strikeCount = newState.strikeCount,
                monetizationStatus = if (newState.isSuspended) "SUSPENDED" else "ACTIVE",
                totalEarnings = newState.totalEarnings,
                dailyEarnings = newState.dailyEarnings,
                isSuspended = newState.isSuspended
            )
        }

        addSystemNotification(
            title = "উত্তোলন অনুরোধ গৃহীত হয়েছে",
            message = "$${amount} ${method.displayName}-এ উইথড্র করার অনুরোধ সফলভাবে জমা হয়েছে। ৩-৭ কার্যদিবসে সম্পন্ন হবে।"
        )

        return Pair(true, "উত্তোলনের অনুরোধ সফলভাবে পাঠানো হয়েছে ($${amount} via ${method.displayName})!")
    }

    suspend fun updateMonetizationProgress(followersDelta: Int, watchTimeHoursDelta: Double) {
        val current = _monetizationState.value
        val oldLevel = current.level
        val newFollowers = (current.followersCount + followersDelta).coerceAtLeast(0)
        val newWatchTime = (current.watchTimeHours + watchTimeHoursDelta).coerceAtLeast(0.0)
        val newLevel = calculateLevel(newFollowers, newWatchTime, current.strikeCount, current.accountAgeDays, current.isSuspended)

        val newState = current.copy(
            followersCount = newFollowers,
            watchTimeHours = newWatchTime,
            level = newLevel
        )
        _monetizationState.value = newState
        saveMonetizationToPrefs(newState)

        if (newLevel.levelNumber > oldLevel.levelNumber) {
            addSystemNotification(
                title = "🎉 অভিনন্দন!",
                message = "🎉 অভিনন্দন! আপনি Level ${newLevel.levelNumber} এ উন্নীত হয়েছেন!"
            )
        }
    }

    suspend fun addSystemNotification(title: String, message: String, targetId: String? = null) {
        val notif = NotificationEntity(
            id = "notif_${System.currentTimeMillis()}",
            typeString = "SYSTEM",
            title = title,
            message = message,
            avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&q=80",
            timeAgo = "এইমাত্র",
            isRead = false,
            targetId = targetId,
            timestamp = System.currentTimeMillis()
        )
        notificationDao.insertNotification(notif)
    }

    suspend fun submitCopyrightNoticeDispute(noticeId: String, disputeReason: String) {
        val currentUserId = authManager.currentUserState.value?.id ?: "user_bd_01"
        val updated = _copyrightNotices.value.map { notice ->
            if (notice.id == noticeId) {
                notice.copy(
                    status = CopyrightNoticeStatus.DISPUTED,
                    disputeReason = disputeReason
                )
            } else {
                notice
            }
        }
        _copyrightNotices.value = updated
        saveNoticesToPrefs(updated)

        copyrightDao.insertModerationAction(
            CopyrightModerationActionEntity(
                id = "disp_${System.currentTimeMillis()}",
                matchId = noticeId,
                action = "DISPUTE_SUBMITTED",
                adminNotes = "নোটিশ আপিল: $disputeReason"
            )
        )

        CoroutineScope(Dispatchers.IO).launch {
            FirebaseFirestoreManager.submitDisputeInFirestore(
                userId = currentUserId,
                noticeId = noticeId,
                disputeReason = disputeReason
            )
        }
    }

    fun getStreamVaultBaseUrl(): String = StreamVaultClient.getBaseUrl()

    fun updateStreamVaultBaseUrl(newUrl: String) {
        StreamVaultClient.setBaseUrl(newUrl, context)
    }

    // --- Social Posts (Facebook Style) ---
    val allPosts: Flow<List<Post>> = combine(postDao.getAllPosts(), _createdPosts) { entities, newlyCreated ->
        val models = entities.map { it.toModel() }
        val newlyIds = newlyCreated.map { it.id }.toSet()
        val remainingDb = models.filterNot { it.id in newlyIds }
        newlyCreated + remainingDb
    }

    suspend fun togglePostLike(postId: String, currentIsLiked: Boolean, currentLikes: Int) {
        val newIsLiked = !currentIsLiked
        val newLikesCount = if (newIsLiked) currentLikes + 1 else (currentLikes - 1).coerceAtLeast(0)
        postDao.updateLike(postId, newIsLiked, newLikesCount)
    }

    suspend fun createPost(content: String, rawImageUri: String? = null) {
        val currentUser = authManager.currentUserState.value
        val authorName = currentUser?.name ?: "তানভীর আহমেদ"
        val authorAvatar = currentUser?.avatarUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80"
        val authorId = currentUser?.id ?: "user_bd_01"

        var uploadedImageUrl: String? = null
        if (!rawImageUri.isNullOrBlank()) {
            val result = CloudinaryService.uploadImage(rawImageUri, folder = "posts")
            uploadedImageUrl = result.getOrNull() ?: rawImageUri
        }

        val newPost = PostEntity(
            id = "post_${System.currentTimeMillis()}",
            authorId = authorId,
            authorName = authorName,
            authorAvatar = authorAvatar,
            isAuthorVerified = true,
            timeAgo = "এইমাত্র",
            content = content,
            imageUrl = uploadedImageUrl,
            videoUrl = null,
            likesCount = 0,
            commentsCount = 0,
            sharesCount = 0,
            isLiked = false,
            isSaved = false,
            timestamp = System.currentTimeMillis()
        )
        // Add new post to the front of the list so it displays at the very top immediately
        _createdPosts.value = listOf(newPost.toModel()) + _createdPosts.value
        postDao.insertPost(newPost)
    }

    // --- Stories (Facebook Style) ---
    val activeStories: Flow<List<Story>> = storyDao.getActiveStories(System.currentTimeMillis()).map { entities ->
        entities.map { it.toModel() }
    }

    suspend fun addStory(mediaUrl: String, caption: String) {
        val currentUser = authManager.currentUserState.value
        val userName = currentUser?.name ?: "আপনার স্টোরি"
        val userAvatar = currentUser?.avatarUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80"
        val userId = currentUser?.id ?: "user_bd_01"

        val newStory = StoryEntity(
            id = "story_${System.currentTimeMillis()}",
            userId = userId,
            userName = userName,
            userAvatar = userAvatar,
            mediaUrl = mediaUrl,
            isVideo = false,
            caption = caption,
            timeAgo = "এইমাত্র",
            isSeen = false,
            timestamp = System.currentTimeMillis(),
            expiresAt = System.currentTimeMillis() + 24 * 60 * 60 * 1000L
        )
        storyDao.insertStory(newStory)
    }

    suspend fun markStorySeen(storyId: String) {
        storyDao.markSeen(storyId)
    }

    // --- Videos & Shorts (YouTube Style) ---
    val longVideos: Flow<List<Video>> = combine(videoDao.getLongVideos(), _uploadedVideos) { entities, newlyCreated ->
        val models = entities.map { it.toModel() }
        val newlyLong = newlyCreated.filterNot { it.isShort }
        val ids = newlyLong.map { it.id }.toSet()
        val remainingDb = models.filterNot { it.id in ids }
        newlyLong + remainingDb
    }

    val shorts: Flow<List<Video>> = combine(videoDao.getShorts(), _uploadedVideos) { entities, newlyCreated ->
        val models = entities.map { it.toModel() }
        val newlyShorts = newlyCreated.filter { it.isShort }
        val ids = newlyShorts.map { it.id }.toSet()
        val remainingDb = models.filterNot { it.id in ids }
        newlyShorts + remainingDb
    }

    fun getVideosByCategory(category: String): Flow<List<Video>> {
        return if (category == "সবগুলো") {
            longVideos
        } else {
            longVideos.map { list -> list.filter { it.category == category } }
        }
    }

    suspend fun getVideoById(id: String): Video? {
        return videoDao.getVideoById(id)?.toModel()
    }

    suspend fun toggleVideoLike(videoId: String, currentIsLiked: Boolean, currentLikes: Int) {
        val newIsLiked = !currentIsLiked
        val newLikesCount = if (newIsLiked) currentLikes + 1 else (currentLikes - 1).coerceAtLeast(0)
        videoDao.updateLike(videoId, newIsLiked, newLikesCount)
    }

    suspend fun toggleSubscription(channelId: String, currentIsSubscribed: Boolean) {
        videoDao.updateChannelSubscription(channelId, !currentIsSubscribed)
    }

    suspend fun incrementViews(videoId: String) {
        videoDao.incrementViews(videoId)
        // Update view count in Firebase Firestore as well
        FirebaseFirestoreManager.incrementVideoViewCount(videoId)
    }

    suspend fun toggleFollow(targetUserId: String, isCurrentlyFollowing: Boolean): Boolean {
        val newFollowState = !isCurrentlyFollowing
        val delta = if (newFollowState) 1L else -1L

        // Update in Firebase Firestore
        FirebaseFirestoreManager.updateFollowerCount(targetUserId, delta)

        // If target user is the logged in user, update local session
        if (authManager.currentUserState.value?.id == targetUserId) {
            authManager.updateFollowersCount(delta.toInt())
        }

        return newFollowState
    }

    suspend fun uploadVideo(
        title: String,
        description: String,
        category: String,
        rawVideoUri: String,
        thumbnailUri: String,
        isShort: Boolean
    ) {
        val currentUser = authManager.currentUserState.value
        val channelName = currentUser?.name ?: "আমার চ্যানেল"
        val channelAvatar = currentUser?.avatarUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80"
        val channelId = currentUser?.id ?: "ch_01"

        // StreamVault API call
        val streamVaultResp = StreamVaultClient.uploadToStreamVault(title, category, rawVideoUri)
        val finalVideoUrl = streamVaultResp.videoUrl ?: rawVideoUri
        val finalThumbnail = if (thumbnailUri.isNotBlank()) thumbnailUri else (streamVaultResp.thumbnailUrl ?: "https://images.unsplash.com/photo-1518173946687-a4c8a383392e?w=800&q=80")

        // Extract actual video duration using MediaMetadataRetriever
        val actualDurationFormatted: String = try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, Uri.parse(rawVideoUri))
            val ms = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            retriever.release()
            if (ms > 0L) {
                val totalSeconds = ms / 1000L
                val minutes = totalSeconds / 60L
                val seconds = totalSeconds % 60L
                String.format("%02d:%02d", minutes, seconds)
            } else {
                if (isShort) "00:45" else "12:30"
            }
        } catch (e: Exception) {
            if (isShort) "00:45" else "12:30"
        }

        // Real-time Copyright Check (SHA-256 hash, Visual fingerprint, Audio fingerprint)
        val scanEvidence = copyrightEngine.scanVideo(finalVideoUrl, title)
        if (scanEvidence.status == com.example.copyright.model.CopyrightStatus.BLOCKED) {
            // কপিরাইট ভিডিও আপলোড হলে:
            // ১. ওয়ার্নিং দেখাবে না (No warning on screen)
            // ২. ভিডিও ফিডে দেখাবে না (Not inserted into videoDao or _uploadedVideos)
            // ৩. শুধু Copyright Section এ যাবে
            recordCopyrightStrike(
                evidence = scanEvidence,
                videoTitle = title,
                videoUri = finalVideoUrl,
                thumbnailUrl = finalThumbnail
            )
            return
        }

        val newVideo = VideoEntity(
            id = "vid_${System.currentTimeMillis()}",
            title = title,
            description = description,
            videoUrl = finalVideoUrl,
            thumbnailUrl = finalThumbnail,
            channelId = channelId,
            channelName = channelName,
            channelAvatar = channelAvatar,
            isChannelVerified = true,
            viewsCount = 1,
            timeAgo = "এইমাত্র",
            duration = actualDurationFormatted,
            category = category,
            likesCount = 0,
            isLiked = false,
            isSubscribed = false,
            isShort = isShort,
            timestamp = System.currentTimeMillis()
        )
        // Add new video to the front of the list so it displays at the very top immediately
        _uploadedVideos.value = listOf(newVideo.toModel()) + _uploadedVideos.value
        videoDao.insertVideo(newVideo)

        // Automatically register newly published video in the Copyright / Duplicate registry
        // so that duplicate uploads of this video are prevented platform-wide.
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val sha = Sha256Hasher.computeSha256(finalVideoUrl.toByteArray())
                val frames = PerceptualVideoHasher.sampleVideoFrames(context, finalVideoUrl, 180000L, 11)
                val audio = AudioFingerprintExtractor.extractAudioFingerprint(context, finalVideoUrl, 180000L)
                val frameStr = frames.joinToString(";") { "${it.timestampMs},${it.pHashHex},${it.dHashHex}" }
                val audioStr = audio.landmarkHashes.joinToString(",")

                copyrightDao.insertReference(
                    CopyrightReferenceEntity(
                        id = "ref_user_${newVideo.id}",
                        ownerId = channelId,
                        title = title,
                        source = "VidBook Platform Upload",
                        sha256 = sha,
                        audioFingerprint = audioStr,
                        videoFingerprint = if (frames.isNotEmpty()) frames.first().pHashHex else "0000000000000000",
                        frameFingerprints = frameStr,
                        durationMs = 180000L
                    )
                )
            } catch (ignored: Exception) {}
        }
    }

    suspend fun scanCandidateVideo(
        videoUriOrPath: String,
        videoTitle: String,
        onProgress: (stage: String, progress: Float) -> Unit = { _, _ -> }
    ): CopyrightScanEvidence {
        return copyrightEngine.scanVideo(videoUriOrPath, videoTitle, onProgress = onProgress)
    }

    suspend fun submitDispute(scanEvidence: CopyrightScanEvidence, disputeReason: String) {
        val action = CopyrightModerationActionEntity(
            id = "disp_${System.currentTimeMillis()}",
            matchId = scanEvidence.matchedReferenceId ?: scanEvidence.scanId,
            action = "DISPUTE_SUBMITTED",
            adminNotes = "ব্যবহারকারীর আপিল: $disputeReason (ম্যাচ ধরণ: ${scanEvidence.decision.name})"
        )
        copyrightDao.insertModerationAction(action)
    }

    // --- Profile Editing with Cloudinary & Firebase Firestore ---
    suspend fun updateFullProfile(
        name: String,
        username: String,
        bio: String,
        rawAvatarUri: String? = null,
        rawCoverUri: String? = null
    ): UserProfile {
        var finalAvatarUrl = authManager.currentUserState.value?.avatarUrl
        var finalCoverUrl = authManager.currentUserState.value?.coverUrl

        // Upload avatar to Cloudinary if local file URI
        if (!rawAvatarUri.isNullOrBlank() && !rawAvatarUri.startsWith("http://") && !rawAvatarUri.startsWith("https://")) {
            val res = CloudinaryService.uploadImage(rawAvatarUri, folder = "avatars")
            finalAvatarUrl = res.getOrNull() ?: rawAvatarUri
        } else if (!rawAvatarUri.isNullOrBlank()) {
            finalAvatarUrl = rawAvatarUri
        }

        // Upload cover to Cloudinary if local file URI
        if (!rawCoverUri.isNullOrBlank() && !rawCoverUri.startsWith("http://") && !rawCoverUri.startsWith("https://")) {
            val res = CloudinaryService.uploadImage(rawCoverUri, folder = "covers")
            finalCoverUrl = res.getOrNull() ?: rawCoverUri
        } else if (!rawCoverUri.isNullOrBlank()) {
            finalCoverUrl = rawCoverUri
        }

        authManager.updateFullProfile(
            name = name,
            username = username,
            bio = bio,
            avatarUrl = finalAvatarUrl,
            coverUrl = finalCoverUrl
        )

        val updatedUser = authManager.currentUserState.value!!

        // Save to Firebase Firestore
        CoroutineScope(Dispatchers.IO).launch {
            FirebaseFirestoreManager.updateUserProfileInFirestore(
                userId = updatedUser.id,
                name = updatedUser.name,
                username = updatedUser.username,
                bio = updatedUser.bio,
                avatarUrl = updatedUser.avatarUrl,
                coverUrl = updatedUser.coverUrl
            )
        }

        return updatedUser
    }

    suspend fun updateAvatarPhoto(rawAvatarUri: String): String {
        var uploadedUrl = rawAvatarUri
        if (!rawAvatarUri.startsWith("http://") && !rawAvatarUri.startsWith("https://")) {
            val res = CloudinaryService.uploadImage(rawAvatarUri, folder = "avatars")
            uploadedUrl = res.getOrNull() ?: rawAvatarUri
        }
        val current = authManager.currentUserState.value
        if (current != null) {
            authManager.updateFullProfile(
                name = current.name,
                username = current.username,
                bio = current.bio,
                avatarUrl = uploadedUrl
            )
            CoroutineScope(Dispatchers.IO).launch {
                FirebaseFirestoreManager.updateUserProfileInFirestore(
                    userId = current.id,
                    name = current.name,
                    username = current.username,
                    bio = current.bio,
                    avatarUrl = uploadedUrl
                )
            }
        }
        return uploadedUrl
    }

    suspend fun updateCoverPhoto(rawCoverUri: String): String {
        var uploadedUrl = rawCoverUri
        if (!rawCoverUri.startsWith("http://") && !rawCoverUri.startsWith("https://")) {
            val res = CloudinaryService.uploadImage(rawCoverUri, folder = "covers")
            uploadedUrl = res.getOrNull() ?: rawCoverUri
        }
        val current = authManager.currentUserState.value
        if (current != null) {
            authManager.updateFullProfile(
                name = current.name,
                username = current.username,
                bio = current.bio,
                coverUrl = uploadedUrl
            )
            CoroutineScope(Dispatchers.IO).launch {
                FirebaseFirestoreManager.updateUserProfileInFirestore(
                    userId = current.id,
                    name = current.name,
                    username = current.username,
                    bio = current.bio,
                    coverUrl = uploadedUrl
                )
            }
        }
        return uploadedUrl
    }

    // --- Comments ---
    fun getCommentsForTarget(targetId: String): Flow<List<Comment>> {
        return commentDao.getCommentsForTarget(targetId).map { entities ->
            entities.map { it.toModel() }
        }
    }

    suspend fun addComment(targetId: String, text: String) {
        val currentUser = authManager.currentUserState.value
        val authorName = currentUser?.name ?: "তানভীর আহমেদ"
        val authorAvatar = currentUser?.avatarUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80"

        val newComment = CommentEntity(
            id = "comment_${System.currentTimeMillis()}",
            targetId = targetId,
            authorName = authorName,
            authorAvatar = authorAvatar,
            text = text,
            timeAgo = "এইমাত্র",
            likesCount = 0,
            isLiked = false,
            timestamp = System.currentTimeMillis()
        )
        commentDao.insertComment(newComment)
    }

    // --- Notifications ---
    val allNotifications: Flow<List<NotificationItem>> = notificationDao.getAllNotifications().map { entities ->
        entities.map { it.toModel() }
    }

    suspend fun markAllNotificationsAsRead() {
        notificationDao.markAllAsRead()
    }

    suspend fun markNotificationAsRead(id: String) {
        notificationDao.markAsRead(id)
    }

    // --- Pre-population with authentic Bangladeshi Content ---
    private suspend fun seedInitialDataIfEmpty() {
        // Seed Stories
        val initialStories = listOf(
            StoryEntity(
                id = "story_1",
                userId = "u_twh",
                userName = "তৌহিদ আফ্রিদি",
                userAvatar = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80",
                mediaUrl = "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=800&q=80",
                isVideo = false,
                caption = "আজকের নতুন ব্লগের শুটিং চলছে কক্সবাজারে! 🏖️",
                timeAgo = "২ ঘণ্টা আগে",
                isSeen = false,
                timestamp = System.currentTimeMillis() - 2 * 3600 * 1000L,
                expiresAt = System.currentTimeMillis() + 22 * 3600 * 1000L
            ),
            StoryEntity(
                id = "story_2",
                userId = "u_rafsan",
                userName = "রাফসান ছোটভাই",
                userAvatar = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&q=80",
                mediaUrl = "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&q=80",
                isVideo = false,
                caption = "পুরান ঢাকার সেরা বিরিয়ানি রিভিউ আসছে শীঘ্রই! 🍗",
                timeAgo = "৪ ঘণ্টা আগে",
                isSeen = false,
                timestamp = System.currentTimeMillis() - 4 * 3600 * 1000L,
                expiresAt = System.currentTimeMillis() + 20 * 3600 * 1000L
            ),
            StoryEntity(
                id = "story_3",
                userId = "u_natok",
                userName = "বাংলা ড্রামা ক্লাব",
                userAvatar = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80",
                mediaUrl = "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=800&q=80",
                isVideo = false,
                caption = "ঈদের বিশেষ নাটকের ট্রেলার রিলিজ হয়েছে! ✨",
                timeAgo = "৬ ঘণ্টা আগে",
                isSeen = false,
                timestamp = System.currentTimeMillis() - 6 * 3600 * 1000L,
                expiresAt = System.currentTimeMillis() + 18 * 3600 * 1000L
            ),
            StoryEntity(
                id = "story_4",
                userId = "u_cricket",
                userName = "বিসিবি টাইগার্স",
                userAvatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&q=80",
                mediaUrl = "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=800&q=80",
                isVideo = false,
                caption = "মিরপুর স্টেডিয়ামে আজকের অনুশীলন শেষ 🏏🇧🇩",
                timeAgo = "৮ ঘণ্টা আগে",
                isSeen = false,
                timestamp = System.currentTimeMillis() - 8 * 3600 * 1000L,
                expiresAt = System.currentTimeMillis() + 16 * 3600 * 1000L
            )
        )
        storyDao.insertStories(initialStories)

        // Seed Social Posts
        val initialPosts = listOf(
            PostEntity(
                id = "post_1",
                authorId = "u_channel_i",
                authorName = "চ্যানেল আই ডিজিটাল",
                authorAvatar = "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=200&q=80",
                isAuthorVerified = true,
                timeAgo = "১ ঘণ্টা আগে",
                content = "আজ সন্ধ্যায় প্রচার হবে মোশাররফ করিম অভিনীত রোমাঞ্চকর পারিবারিক কমেডি নাটক 'গ্রামের মেম্বার'। নাটকটি দেখতে VidBook এর ভিডিও ট্যাবে চোখ রাখুন!",
                imageUrl = "https://images.unsplash.com/photo-1518173946687-a4c8a383392e?w=900&q=80",
                videoUrl = null,
                likesCount = 3840,
                commentsCount = 245,
                sharesCount = 120,
                isLiked = true,
                isSaved = false,
                timestamp = System.currentTimeMillis() - 3600 * 1000L
            ),
            PostEntity(
                id = "post_2",
                authorId = "u_somoy",
                authorName = "সময় সংবাদ লাইভ",
                authorAvatar = "https://images.unsplash.com/photo-1585829365295-ab7cd400c167?w=200&q=80",
                isAuthorVerified = true,
                timeAgo = "৩ ঘণ্টা আগে",
                content = "পদ্মা সেতু দিয়ে নতুন রুটে ট্রেন চলাচল শুরু। দক্ষিণবঙ্গের মানুষের যাতায়াতে এক যুগান্তকারী পরিবর্তন। আপনার মতামত জানান কমেন্টে।",
                imageUrl = "https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?w=900&q=80",
                videoUrl = null,
                likesCount = 8920,
                commentsCount = 890,
                sharesCount = 430,
                isLiked = false,
                isSaved = true,
                timestamp = System.currentTimeMillis() - 3 * 3600 * 1000L
            ),
            PostEntity(
                id = "post_3",
                authorId = "u_foodie",
                authorName = "ঢাকা ফুড ভ্লগ",
                authorAvatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&q=80",
                isAuthorVerified = false,
                timeAgo = "৫ ঘণ্টা আগে",
                content = "ধানমন্ডিতে নতুন একটা ট্রেডিশনাল কাচ্চি হাউজের সন্ধান পেলাম! এত নরম মাংস এবং অসাধারণ জাফরানি সুবাস। কার কার কাচ্চি পছন্দ?",
                imageUrl = "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=900&q=80",
                videoUrl = null,
                likesCount = 1530,
                commentsCount = 142,
                sharesCount = 35,
                isLiked = false,
                isSaved = false,
                timestamp = System.currentTimeMillis() - 5 * 3600 * 1000L
            )
        )
        postDao.insertPosts(initialPosts)

        // Seed Videos
        val initialVideos = listOf(
            VideoEntity(
                id = "vid_1",
                title = "বিয়ে বিভ্রাট - বাংলা হাসির নাটক | মোশাররফ করিম, তানিয়া বৃষ্টি | নতুন নাটক",
                description = "পরিচালক: কাজল আরেফিন অমি। সম্পূর্ণ হাসির রোমান্টিক নাটক 'বিয়ে বিভ্রাট'। বন্ধুদের সাথে শেয়ার করতে ভুলবেন না!",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                thumbnailUrl = "https://images.unsplash.com/photo-1518173946687-a4c8a383392e?w=800&q=80",
                channelId = "ch_natok",
                channelName = "বাংলা নাটক এক্সপ্রেস",
                channelAvatar = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80",
                isChannelVerified = true,
                viewsCount = 1450000,
                timeAgo = "২ দিন আগে",
                duration = "৩৮:২৫",
                category = "বাংলা নাটক",
                likesCount = 42500,
                isLiked = true,
                isSubscribed = true,
                isShort = false,
                timestamp = System.currentTimeMillis() - 2 * 86400 * 1000L
            ),
            VideoEntity(
                id = "vid_2",
                title = "আজকের প্রধান সংবাদ বুলেটিন | দেশ-বিদেশের তাজা খবর | রাত ১০টার খবর",
                description = "দৈনন্দিন রাজনীতিক, অর্থনৈতিক ও আবহাওয়া সংক্রান্ত বিশেষ সংবাদ আপডেট।",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                thumbnailUrl = "https://images.unsplash.com/photo-1585829365295-ab7cd400c167?w=800&q=80",
                channelId = "ch_news",
                channelName = "একাত্তর বার্তা",
                channelAvatar = "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=200&q=80",
                isChannelVerified = true,
                viewsCount = 389000,
                timeAgo = "৪ ঘণ্টা আগে",
                duration = "১৫:১০",
                category = "সংবাদ",
                likesCount = 11200,
                isLiked = false,
                isSubscribed = false,
                isShort = false,
                timestamp = System.currentTimeMillis() - 4 * 3600 * 1000L
            ),
            VideoEntity(
                id = "vid_3",
                title = "সাকিব আল হাসানের অলরাউন্ড নৈপুণ্যে অসাধারণ জয়! ম্যাচ হাইলাইটস",
                description = "রোমাঞ্চকর শেষ ওভারে বাংলাদেশের শ্বাসরুদ্ধকর বিজয়। দেখুন ম্যাচের সেরা মুহূর্তগুলো।",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                thumbnailUrl = "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=800&q=80",
                channelId = "ch_sports",
                channelName = "টাইগার্স ক্রিকেট জোন",
                channelAvatar = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&q=80",
                isChannelVerified = true,
                viewsCount = 980000,
                timeAgo = "১ দিন আগে",
                duration = "০৮:৪৫",
                category = "খেলাধুলা",
                likesCount = 68000,
                isLiked = true,
                isSubscribed = true,
                isShort = false,
                timestamp = System.currentTimeMillis() - 86400 * 1000L
            ),
            VideoEntity(
                id = "vid_4",
                title = "মায়াবী সুরের বাউল গান - নদী ও জীবনের মেলবন্ধন | লাইভ স্টুডিও সেশন",
                description = "বাংলার ঐতিহ্যবাহী লোকসংগীতের আধুনিক সংকলন। প্রাণ জুড়ানো সুর।",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                thumbnailUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&q=80",
                channelId = "ch_music",
                channelName = "সুরবিতান মিউজিক",
                channelAvatar = "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&q=80",
                isChannelVerified = false,
                viewsCount = 210000,
                timeAgo = "৩ দিন আগে",
                duration = "০৫:২০",
                category = "মিউজিক",
                likesCount = 14300,
                isLiked = false,
                isSubscribed = false,
                isShort = false,
                timestamp = System.currentTimeMillis() - 3 * 86400 * 1000L
            )
        )
        videoDao.insertVideos(initialVideos)

        // Seed Shorts / Reels
        val initialShorts = listOf(
            VideoEntity(
                id = "short_1",
                title = "নাটকের ভাইরাল ডায়লগ! 😂 আপনিও কি এমন বন্ধু চেনেন? #shorts #banglanatok",
                description = "হাসির নাটক ক্লিপ। সাবস্ক্রাইব করুন!",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4",
                thumbnailUrl = "https://images.unsplash.com/photo-1518173946687-a4c8a383392e?w=800&q=80",
                channelId = "ch_fun",
                channelName = "হাসির কারখানা",
                channelAvatar = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80",
                isChannelVerified = true,
                viewsCount = 850000,
                timeAgo = "গতকাল",
                duration = "0:35",
                category = "শর্টস",
                likesCount = 54200,
                isLiked = true,
                isSubscribed = true,
                isShort = true,
                timestamp = System.currentTimeMillis() - 86400 * 1000L
            ),
            VideoEntity(
                id = "short_2",
                title = "কক্সবাজার সমুদ্র সৈকতের মোহনীয় সূর্যাস্ত 🌊🌅 #bangladesh #travel",
                description = "প্রকৃতির অপরূপ রূপ। দেখুন এবং শেয়ার করুন।",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
                thumbnailUrl = "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&q=80",
                channelId = "ch_travel",
                channelName = "ভ্রমণ বাংলাদেশ",
                channelAvatar = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&q=80",
                isChannelVerified = true,
                viewsCount = 320000,
                timeAgo = "২ দিন আগে",
                duration = "0:28",
                category = "শর্টস",
                likesCount = 28900,
                isLiked = false,
                isSubscribed = false,
                isShort = true,
                timestamp = System.currentTimeMillis() - 2 * 86400 * 1000L
            ),
            VideoEntity(
                id = "short_3",
                title = "স্মার্টফোনের ৩টি গোপন ট্রিকস যা জানা জরুরি! 📱⚡ #tech #tips",
                description = "দৈনন্দিন কাজে লাগবে এমন ৩টি সুপার সেটিংস।",
                videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4",
                thumbnailUrl = "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800&q=80",
                channelId = "ch_tech",
                channelName = "টেক মাস্টার বিডি",
                channelAvatar = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&q=80",
                isChannelVerified = true,
                viewsCount = 410000,
                timeAgo = "৩ দিন আগে",
                duration = "0:45",
                category = "শর্টস",
                likesCount = 39400,
                isLiked = false,
                isSubscribed = false,
                isShort = true,
                timestamp = System.currentTimeMillis() - 3 * 86400 * 1000L
            )
        )
        videoDao.insertVideos(initialShorts)

        // Seed Comments
        val initialComments = listOf(
            CommentEntity(
                id = "c_1",
                targetId = "vid_1",
                authorName = "রাকিবুল হাসান",
                authorAvatar = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&q=80",
                text = "মোশাররফ করিম ভাইয়ের অভিনয় বরাবরের মতোই অসাধারণ! পুরো হাসতে হাসতে শেষ।",
                timeAgo = "১ দিন আগে",
                likesCount = 142,
                isLiked = true,
                timestamp = System.currentTimeMillis() - 86400 * 1000L
            ),
            CommentEntity(
                id = "c_2",
                targetId = "vid_1",
                authorName = "সাদিয়া আফরিন",
                authorAvatar = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80",
                text = "নাটকের ডায়লগ ও ব্যাকগ্রাউন্ড মিউজিক এক কথায় দারুণ হয়েছে। শুভকামনা পুরো টিমকে।",
                timeAgo = "১২ ঘণ্টা আগে",
                likesCount = 58,
                isLiked = false,
                timestamp = System.currentTimeMillis() - 12 * 3600 * 1000L
            ),
            CommentEntity(
                id = "c_3",
                targetId = "post_1",
                authorName = "মাহমুদ হাসান",
                authorAvatar = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80",
                text = "আজ সন্ধ্যায় অবশ্যই দেখব। মেম্বার চরিত্রের জন্য মোশাররফ করিম পারফেক্ট!",
                timeAgo = "৪৫ মিনিট আগে",
                likesCount = 23,
                isLiked = false,
                timestamp = System.currentTimeMillis() - 45 * 60 * 1000L
            )
        )
        initialComments.forEach { commentDao.insertComment(it) }

        // Seed Notifications
        val initialNotifications = listOf(
            NotificationEntity(
                id = "notif_1",
                typeString = "NEW_VIDEO",
                title = "বাংলা নাটক এক্সপ্রেস",
                message = "নতুন ভিডিও আপলোড করেছে: 'বিয়ে বিভ্রাট - বাংলা হাসির নাটক'",
                avatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80",
                timeAgo = "২ ঘণ্টা আগে",
                isRead = false,
                targetId = "vid_1",
                timestamp = System.currentTimeMillis() - 2 * 3600 * 1000L
            ),
            NotificationEntity(
                id = "notif_2",
                typeString = "LIKE",
                title = "লাইক নোটিফিকেশন",
                message = "রাকিবুল হাসান ও আরও ১২ জন আপনার পোস্টে লাইক দিয়েছেন",
                avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&q=80",
                timeAgo = "৪ ঘণ্টা আগে",
                isRead = false,
                targetId = "post_1",
                timestamp = System.currentTimeMillis() - 4 * 3600 * 1000L
            ),
            NotificationEntity(
                id = "notif_3",
                typeString = "COMMENT",
                title = "নতুন মন্তব্য",
                message = "সাদিয়া আফরিন আপনার পোস্টে মন্তব্য করেছেন",
                avatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80",
                timeAgo = "গতকাল",
                isRead = true,
                targetId = "post_1",
                timestamp = System.currentTimeMillis() - 86400 * 1000L
            ),
            NotificationEntity(
                id = "notif_4",
                typeString = "FOLLOW",
                title = "নতুন ফলোয়ার",
                message = "বাংলা ড্রামা ক্লাব আপনাকে ফলো করা শুরু করেছে",
                avatarUrl = "https://images.unsplash.com/photo-1518791841217-8f162f1e1131?w=200&q=80",
                timeAgo = "১ দিন আগে",
                isRead = false,
                targetId = "ch_natok",
                timestamp = System.currentTimeMillis() - 86400 * 1000L
            ),
            NotificationEntity(
                id = "notif_5",
                typeString = "SYSTEM",
                title = "🎉 অভিনন্দন!",
                message = "🎉 অভিনন্দন! আপনি Level 2 এ উন্নীত হয়েছেন!",
                avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&q=80",
                timeAgo = "আজ",
                isRead = false,
                targetId = "monetization",
                timestamp = System.currentTimeMillis() - 3600 * 1000L
            )
        )
        notificationDao.insertNotifications(initialNotifications)

        // Seed Copyright & Reference Database with Known Content
        if (copyrightDao.getActiveReferencesList().isEmpty()) {
            val dramaCandidateUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
            val newsCandidateUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"

            val sampleRefSha1 = Sha256Hasher.computeSha256(dramaCandidateUrl.toByteArray())
            val sampleRefSha2 = Sha256Hasher.computeSha256(newsCandidateUrl.toByteArray())
            val sampleRefSha3 = Sha256Hasher.computeSha256("sample_bangla_drama_biyebibhrat_master".toByteArray())
            val sampleRefSha4 = Sha256Hasher.computeSha256("sample_bangla_song_anupam_master".toByteArray())

            fun makeRefFrames(seed: String, count: Int = 11): String {
                val seedBytes = seed.toByteArray()
                return (0 until count).joinToString(";") { i ->
                    val timeMs = i * 60000L
                    val md = java.security.MessageDigest.getInstance("SHA-256")
                    md.update(seedBytes)
                    md.update(java.nio.ByteBuffer.allocate(8).putLong(timeMs).array())
                    val d = md.digest()
                    val pHash = String.format("%016x", java.nio.ByteBuffer.wrap(d, 0, 8).long)
                    val dHash = String.format("%016x", java.nio.ByteBuffer.wrap(d, 8, 8).long)
                    "$timeMs,$pHash,$dHash"
                }
            }

            fun makeRefAudio(seed: String, count: Int = 20): String {
                val seedBytes = seed.toByteArray()
                return (0 until count).joinToString(",") { i ->
                    val md = java.security.MessageDigest.getInstance("SHA-256")
                    md.update(seedBytes)
                    md.update(java.nio.ByteBuffer.allocate(4).putInt(i).array())
                    val d = md.digest()
                    (java.nio.ByteBuffer.wrap(d, 0, 8).long and 0xFFFFFFFFL).toString()
                }
            }

            val references = listOf(
                CopyrightReferenceEntity(
                    id = "ref_drama_01",
                    ownerId = "owner_drama_express",
                    title = "বিয়ে বিভ্রাট - Mosharraf Karim Official Drama (Bangla Drama Express)",
                    source = "Bangla Drama Express Broadcast Network",
                    sha256 = sampleRefSha1, // Matches BigBuckBunny test candidate
                    audioFingerprint = makeRefAudio(dramaCandidateUrl),
                    videoFingerprint = "7a8b9c0d1e2f3a4b",
                    frameFingerprints = makeRefFrames(dramaCandidateUrl),
                    durationMs = 900000L
                ),
                CopyrightReferenceEntity(
                    id = "ref_news_02",
                    ownerId = "owner_jamuna_tv",
                    title = "যমুনা টেলিভিশন লাইভ বুলেটিন (Jamuna TV Exclusive)",
                    source = "Jamuna Television Satellite Feed",
                    sha256 = sampleRefSha2,
                    audioFingerprint = makeRefAudio(newsCandidateUrl),
                    videoFingerprint = "b1c2d3e4f5a6b7c8",
                    frameFingerprints = makeRefFrames(newsCandidateUrl),
                    durationMs = 600000L
                ),
                CopyrightReferenceEntity(
                    id = "ref_bachelor_03",
                    ownerId = "owner_dhruba_tv",
                    title = "ব্যাচেলর পয়েন্ট সিজন ৪ (Dhruba TV Original)",
                    source = "Dhruba Entertainment Network",
                    sha256 = sampleRefSha3,
                    audioFingerprint = makeRefAudio("sample_bangla_drama_biyebibhrat_master"),
                    videoFingerprint = "e1f2a3b4c5d6e7f8",
                    frameFingerprints = makeRefFrames("sample_bangla_drama_biyebibhrat_master"),
                    durationMs = 1200000L
                ),
                CopyrightReferenceEntity(
                    id = "ref_music_04",
                    ownerId = "owner_anupam",
                    title = "তুমি জানো না - Official Music Video (Anupam Recording Media)",
                    source = "Anupam Music Master Records",
                    sha256 = sampleRefSha4,
                    audioFingerprint = makeRefAudio("sample_bangla_song_anupam_master"),
                    videoFingerprint = "c4d5e6f7a8b9c0d1",
                    frameFingerprints = makeRefFrames("sample_bangla_song_anupam_master"),
                    durationMs = 240000L
                )
            )
            copyrightDao.insertReferences(references)
        }
    }

    // Entity to Model Converters
    private fun PostEntity.toModel() = Post(
        id = id,
        authorId = authorId,
        authorName = authorName,
        authorAvatar = authorAvatar,
        isAuthorVerified = isAuthorVerified,
        timeAgo = timeAgo,
        content = content,
        imageUrl = imageUrl,
        videoUrl = videoUrl,
        likesCount = likesCount,
        commentsCount = commentsCount,
        sharesCount = sharesCount,
        isLiked = isLiked,
        isSaved = isSaved,
        timestamp = timestamp
    )

    private fun VideoEntity.toModel() = Video(
        id = id,
        title = title,
        description = description,
        videoUrl = videoUrl,
        thumbnailUrl = thumbnailUrl,
        channelId = channelId,
        channelName = channelName,
        channelAvatar = channelAvatar,
        isChannelVerified = isChannelVerified,
        viewsCount = viewsCount,
        timeAgo = timeAgo,
        duration = duration,
        category = category,
        likesCount = likesCount,
        isLiked = isLiked,
        isSubscribed = isSubscribed,
        isShort = isShort,
        timestamp = timestamp
    )

    private fun StoryEntity.toModel() = Story(
        id = id,
        userId = userId,
        userName = userName,
        userAvatar = userAvatar,
        mediaUrl = mediaUrl,
        isVideo = isVideo,
        caption = caption,
        timeAgo = timeAgo,
        isSeen = isSeen,
        timestamp = timestamp,
        expiresAt = expiresAt
    )

    private fun CommentEntity.toModel() = Comment(
        id = id,
        targetId = targetId,
        authorName = authorName,
        authorAvatar = authorAvatar,
        text = text,
        timeAgo = timeAgo,
        likesCount = likesCount,
        isLiked = isLiked,
        timestamp = timestamp
    )

    private fun NotificationEntity.toModel() = NotificationItem(
        id = id,
        type = try { NotificationType.valueOf(typeString) } catch (e: Exception) { NotificationType.LIKE },
        title = title,
        message = message,
        avatarUrl = avatarUrl,
        timeAgo = timeAgo,
        isRead = isRead,
        targetId = targetId,
        timestamp = timestamp
    )
}
