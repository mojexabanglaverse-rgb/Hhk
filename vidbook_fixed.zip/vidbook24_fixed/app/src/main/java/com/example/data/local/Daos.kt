package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PostDao {
    @Query("SELECT * FROM posts ORDER BY timestamp DESC")
    fun getAllPosts(): Flow<List<PostEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPosts(posts: List<PostEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: PostEntity)

    @Update
    suspend fun updatePost(post: PostEntity)

    @Query("UPDATE posts SET isLiked = :isLiked, likesCount = :likesCount WHERE id = :id")
    suspend fun updateLike(id: String, isLiked: Boolean, likesCount: Int)

    @Query("DELETE FROM posts WHERE id = :id")
    suspend fun deletePost(id: String)

    @Query("DELETE FROM posts WHERE id IN ('post_1', 'post_2', 'post_3') OR id LIKE 'post_%' OR id LIKE 'sample_%' OR authorId IN ('user_bd_01', 'user_sample_01', 'ch_01', 'ch_natok', 'ch_news', 'ch_tech', 'ch_music')")
    suspend fun deleteSamplePosts()

    @Query("DELETE FROM posts")
    suspend fun clearAllPosts()
}

@Dao
interface VideoDao {
    @Query("SELECT * FROM videos WHERE isShort = 0 ORDER BY timestamp DESC")
    fun getLongVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE isShort = 1 ORDER BY timestamp DESC")
    fun getShorts(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE id = :id")
    suspend fun getVideoById(id: String): VideoEntity?

    @Query("SELECT * FROM videos WHERE category = :category AND isShort = 0 ORDER BY timestamp DESC")
    fun getVideosByCategory(category: String): Flow<List<VideoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVideos(videos: List<VideoEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVideo(video: VideoEntity)

    @Query("UPDATE videos SET viewsCount = viewsCount + 1 WHERE id = :id")
    suspend fun incrementViews(id: String)

    @Query("UPDATE videos SET isLiked = :isLiked, likesCount = :likesCount WHERE id = :id")
    suspend fun updateLike(id: String, isLiked: Boolean, likesCount: Int)

    @Query("UPDATE videos SET isSubscribed = :isSubscribed WHERE channelId = :channelId")
    suspend fun updateChannelSubscription(channelId: String, isSubscribed: Boolean)

    @Query("DELETE FROM videos WHERE id IN ('vid_1', 'vid_2', 'vid_3', 'vid_4', 'short_1', 'short_2', 'short_3') OR id LIKE 'vid_%' OR id LIKE 'short_%' OR id LIKE 'sample_%' OR channelId IN ('user_bd_01', 'ch_01', 'ch_natok', 'ch_news', 'ch_tech', 'ch_music')")
    suspend fun deleteSampleVideos()

    @Query("DELETE FROM videos")
    suspend fun clearAllVideos()
}

@Dao
interface StoryDao {
    @Query("SELECT * FROM stories WHERE status = 'ACTIVE' ORDER BY createdAt DESC")
    fun getAllActiveStories(): Flow<List<StoryEntity>>

    @Query("SELECT * FROM stories WHERE status = 'ACTIVE' AND expiresAt > :currentTime ORDER BY createdAt DESC")
    fun getActiveStories(currentTime: Long): Flow<List<StoryEntity>>

    @Query("SELECT * FROM stories WHERE status = 'ACTIVE' AND expiresAt <= :currentTime")
    suspend fun getExpiredStories(currentTime: Long): List<StoryEntity>

    @Query("SELECT * FROM stories WHERE userId = :userId AND status IN ('EXPIRED', 'ARCHIVED') ORDER BY createdAt DESC")
    fun getArchivedStories(userId: String): Flow<List<StoryEntity>>

    @Query("SELECT * FROM stories WHERE userId = :userId ORDER BY createdAt DESC")
    fun getAllStoriesForUser(userId: String): Flow<List<StoryEntity>>

    @Query("SELECT * FROM stories WHERE id = :id")
    suspend fun getStoryById(id: String): StoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStories(stories: List<StoryEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStory(story: StoryEntity)

    @Query("UPDATE stories SET status = :status WHERE id = :id")
    suspend fun updateStoryStatus(id: String, status: String)

    @Query("UPDATE stories SET isSeen = 1, isViewed = 1, viewCount = viewCount + 1 WHERE id = :id")
    suspend fun markSeen(id: String)

    @Query("DELETE FROM stories WHERE id = :id")
    suspend fun deleteStory(id: String)

    @Query("DELETE FROM stories WHERE id IN ('story_1', 'story_2', 'story_3', 'story_4') OR id LIKE 'story_%' OR id LIKE 'sample_%' OR userId IN ('user_bd_01', 'user_sample_01')")
    suspend fun deleteSampleStories()

    @Query("DELETE FROM stories")
    suspend fun clearAllStories()
}

@Dao
interface StoryInteractionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertViewer(viewer: StoryViewerEntity)

    @Query("SELECT * FROM story_viewers WHERE storyId = :storyId ORDER BY viewedAt DESC")
    fun getViewers(storyId: String): Flow<List<StoryViewerEntity>>

    @Query("SELECT COUNT(*) FROM story_viewers WHERE storyId = :storyId")
    suspend fun getViewerCount(storyId: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReaction(reaction: StoryReactionEntity)

    @Query("SELECT * FROM story_reactions WHERE storyId = :storyId ORDER BY timestamp DESC")
    fun getReactions(storyId: String): Flow<List<StoryReactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReply(reply: StoryReplyEntity)

    @Query("SELECT * FROM story_replies WHERE storyId = :storyId ORDER BY timestamp DESC")
    fun getReplies(storyId: String): Flow<List<StoryReplyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHighlight(highlight: StoryHighlightEntity)

    @Query("SELECT * FROM story_highlights WHERE userId = :userId ORDER BY createdAt DESC")
    fun getHighlights(userId: String): Flow<List<StoryHighlightEntity>>

    @Query("DELETE FROM story_highlights WHERE id = :id")
    suspend fun deleteHighlight(id: String)

    @Query("SELECT * FROM story_privacy WHERE userId = :userId")
    suspend fun getStoryPrivacy(userId: String): StoryPrivacyEntity?

    @Query("SELECT * FROM story_privacy WHERE userId = :userId")
    fun getStoryPrivacyFlow(userId: String): Flow<StoryPrivacyEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateStoryPrivacy(privacy: StoryPrivacyEntity)

    @Query("DELETE FROM story_privacy WHERE userId = :userId")
    suspend fun deleteStoryPrivacy(userId: String)

    @Query("DELETE FROM story_viewers WHERE storyId = :storyId")
    suspend fun deleteStoryViewers(storyId: String)

    @Query("DELETE FROM story_reactions WHERE storyId = :storyId")
    suspend fun deleteStoryReactions(storyId: String)

    @Query("DELETE FROM story_replies WHERE storyId = :storyId")
    suspend fun deleteStoryReplies(storyId: String)

    @Query("DELETE FROM story_viewers WHERE storyId NOT IN (SELECT id FROM stories)")
    suspend fun deleteOrphanStoryViewers(): Int

    @Query("DELETE FROM story_reactions WHERE storyId NOT IN (SELECT id FROM stories)")
    suspend fun deleteOrphanStoryReactions(): Int

    @Query("DELETE FROM story_replies WHERE storyId NOT IN (SELECT id FROM stories)")
    suspend fun deleteOrphanStoryReplies(): Int
}

@Dao
interface VideoClassificationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClassification(classification: VideoClassificationEntity)

    @Query("SELECT * FROM video_classifications WHERE videoId = :videoId")
    suspend fun getClassification(videoId: String): VideoClassificationEntity?
}

@Dao
interface UserSettingsDao {
    @Query("SELECT * FROM user_settings WHERE userId = :userId")
    suspend fun getUserSettings(userId: String): UserSettingsEntity?

    @Query("SELECT * FROM user_settings WHERE userId = :userId")
    fun getUserSettingsFlow(userId: String): Flow<UserSettingsEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateSettings(settings: UserSettingsEntity)
}

@Dao
interface CommentDao {
    @Query("SELECT * FROM comments WHERE targetId = :targetId ORDER BY timestamp DESC")
    fun getCommentsForTarget(targetId: String): Flow<List<CommentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComment(comment: CommentEntity)

    @Query("DELETE FROM comments WHERE id IN ('c_1', 'c_2', 'c_3') OR id LIKE 'c_%' OR id LIKE 'sample_%' OR id LIKE 'comment_sample_%'")
    suspend fun deleteSampleComments()

    @Query("DELETE FROM comments")
    suspend fun clearAllComments()
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(notifications: List<NotificationEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: String)

    @Query("UPDATE notifications SET isRead = 1")
    suspend fun markAllAsRead()

    @Query("DELETE FROM notifications WHERE id IN ('notif_1', 'notif_2', 'notif_3', 'notif_4', 'notif_5') OR id LIKE 'notif_%' OR id LIKE 'sample_%' OR targetId IN ('post_1', 'post_2', 'vid_1', 'vid_2', 'short_1', 'monetization')")
    suspend fun deleteSampleNotifications()

    @Query("DELETE FROM notifications")
    suspend fun clearAllNotifications()
}
