package com.example

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.VidBookApp
import com.example.ui.VidBookViewModel
import com.example.ui.theme.VidBookTheme
import com.firebase.ui.auth.AuthUI
import com.firebase.ui.auth.FirebaseAuthUIActivityResultContract
import com.google.firebase.auth.FirebaseAuth

class MainActivity : ComponentActivity() {

    private lateinit var signInLauncher: ActivityResultLauncher<Intent>
    private var activeViewModel: VidBookViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        signInLauncher = registerForActivityResult(
            FirebaseAuthUIActivityResultContract()
        ) { result ->
            try {
                if (result.resultCode == RESULT_OK) {
                    val user = try {
                        FirebaseAuth.getInstance().currentUser
                    } catch (e: Exception) {
                        Log.e("MainActivity", "Failed to retrieve Firebase user", e)
                        null
                    }
                    if (user != null) {
                        activeViewModel?.onGoogleSignInSuccess(user)
                    } else {
                        activeViewModel?.showSnackbar("গুগল সাইন ইন সফল হলেও ব্যবহারকারীর তথ্য পাওয়া যায়নি")
                    }
                } else {
                    val error = result.idpResponse?.error
                    if (error != null) {
                        Log.w("MainActivity", "FirebaseUI Sign in error: ${error.errorCode} - ${error.localizedMessage}")
                        activeViewModel?.showSnackbar("গুগল সাইন ইন ত্রুটি: ${error.localizedMessage ?: "ব্যর্থ হয়েছে"}")
                    }
                }
            } catch (e: Exception) {
                Log.e("MainActivity", "Sign in result error", e)
                activeViewModel?.showSnackbar("সাইন-ইন সম্পন্ন করতে ত্রুটি হয়েছে")
            }
        }

        setContent {
            val viewModel: VidBookViewModel = viewModel(
                factory = VidBookViewModel.factory(applicationContext)
            )
            activeViewModel = viewModel
            val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()

            VidBookTheme(darkTheme = isDarkMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    VidBookApp(
                        viewModel = viewModel,
                        onGoogleSignIn = { launchGoogleSignIn() }
                    )
                }
            }
        }
    }

    private fun launchGoogleSignIn() {
        try {
            val hasFirebase = try {
                com.google.firebase.FirebaseApp.getApps(applicationContext).isNotEmpty()
            } catch (e: Exception) {
                false
            }
            if (!hasFirebase) {
                Log.w("MainActivity", "FirebaseApp is not configured with google-services.json.")
                activeViewModel?.showSnackbar("ফায়ারবেস এখনও কনফিগার করা হয়নি। অনুগ্রহ করে সাধারণ লগইন ব্যবহার করুন।")
                return
            }

            val providers = listOf(
                AuthUI.IdpConfig.GoogleBuilder().build()
            )
            val intent = AuthUI.getInstance()
                .createSignInIntentBuilder()
                .setAvailableProviders(providers)
                .setTheme(com.firebase.ui.auth.R.style.FirebaseUI)
                .build()
            signInLauncher.launch(intent)
        } catch (e: Exception) {
            Log.e("MainActivity", "Google Sign In failed", e)
            activeViewModel?.showSnackbar("গুগল সাইন-ইন চালু করা সম্ভব হয়নি: ${e.localizedMessage ?: "ত্রুটি"}")
        }
    }
}
