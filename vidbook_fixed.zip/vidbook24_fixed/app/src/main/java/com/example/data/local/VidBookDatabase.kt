package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.copyright.data.ContentMatchEntity
import com.example.copyright.data.CopyrightDao
import com.example.copyright.data.CopyrightModerationActionEntity
import com.example.copyright.data.CopyrightReferenceEntity
import com.example.copyright.data.CopyrightScanLogEntity

@Database(
    entities = [
        PostEntity::class,
        VideoEntity::class,
        StoryEntity::class,
        StoryViewerEntity::class,
        StoryReactionEntity::class,
        StoryReplyEntity::class,
        StoryHighlightEntity::class,
        StoryPrivacyEntity::class,
        VideoClassificationEntity::class,
        UserSettingsEntity::class,
        CommentEntity::class,
        NotificationEntity::class,
        CopyrightReferenceEntity::class,
        ContentMatchEntity::class,
        CopyrightScanLogEntity::class,
        CopyrightModerationActionEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class VidBookDatabase : RoomDatabase() {
    abstract fun postDao(): PostDao
    abstract fun videoDao(): VideoDao
    abstract fun storyDao(): StoryDao
    abstract fun storyInteractionDao(): StoryInteractionDao
    abstract fun videoClassificationDao(): VideoClassificationDao
    abstract fun userSettingsDao(): UserSettingsDao
    abstract fun commentDao(): CommentDao
    abstract fun notificationDao(): NotificationDao
    abstract fun copyrightDao(): CopyrightDao

    companion object {
        @Volatile
        private var INSTANCE: VidBookDatabase? = null

        private fun addColumnIfNotExists(
            db: SupportSQLiteDatabase,
            tableName: String,
            columnName: String,
            columnDefinition: String
        ) {
            var exists = false
            db.query("PRAGMA table_info($tableName)").use { cursor ->
                val nameIndex = cursor.getColumnIndex("name")
                while (cursor.moveToNext()) {
                    if (nameIndex != -1 && cursor.getString(nameIndex).equals(columnName, ignoreCase = true)) {
                        exists = true
                        break
                    }
                }
            }
            if (!exists) {
                db.execSQL("ALTER TABLE $tableName ADD COLUMN $columnName $columnDefinition")
            }
        }

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS copyright_references (
                        id TEXT NOT NULL PRIMARY KEY,
                        ownerId TEXT NOT NULL,
                        title TEXT NOT NULL,
                        source TEXT NOT NULL,
                        sha256 TEXT NOT NULL,
                        audioFingerprint TEXT NOT NULL,
                        videoFingerprint TEXT NOT NULL,
                        frameFingerprints TEXT NOT NULL,
                        durationMs INTEGER NOT NULL,
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL,
                        status TEXT NOT NULL
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS content_matches (
                        id TEXT NOT NULL PRIMARY KEY,
                        candidateVideoId TEXT NOT NULL,
                        referenceContentId TEXT NOT NULL,
                        matchType TEXT NOT NULL,
                        audioMatchRatio REAL NOT NULL,
                        videoMatchRatio REAL NOT NULL,
                        matchedDurationMs INTEGER NOT NULL,
                        confidence REAL NOT NULL,
                        matchedSegments TEXT NOT NULL,
                        createdAt INTEGER NOT NULL
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS copyright_scan_logs (
                        id TEXT NOT NULL PRIMARY KEY,
                        videoId TEXT NOT NULL,
                        scanVersion TEXT NOT NULL,
                        sha256 TEXT NOT NULL,
                        audioFingerprintVersion TEXT NOT NULL,
                        videoFingerprintVersion TEXT NOT NULL,
                        result TEXT NOT NULL,
                        matchedReferenceId TEXT,
                        evidence TEXT NOT NULL,
                        createdAt INTEGER NOT NULL
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS copyright_moderation_actions (
                        id TEXT NOT NULL PRIMARY KEY,
                        matchId TEXT NOT NULL,
                        action TEXT NOT NULL,
                        adminNotes TEXT NOT NULL,
                        timestamp INTEGER NOT NULL
                    )
                """.trimIndent())

                db.execSQL("CREATE INDEX IF NOT EXISTS index_copyright_references_sha256 ON copyright_references(sha256)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_copyright_references_status ON copyright_references(status)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_copyright_references_ownerId ON copyright_references(ownerId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_content_matches_candidateVideoId ON content_matches(candidateVideoId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_content_matches_referenceContentId ON content_matches(referenceContentId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_content_matches_createdAt ON content_matches(createdAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_copyright_scan_logs_videoId ON copyright_scan_logs(videoId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_copyright_scan_logs_sha256 ON copyright_scan_logs(sha256)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_copyright_scan_logs_createdAt ON copyright_scan_logs(createdAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_copyright_moderation_actions_matchId ON copyright_moderation_actions(matchId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_copyright_moderation_actions_timestamp ON copyright_moderation_actions(timestamp)")
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Add columns to videos table deterministically
                addColumnIfNotExists(db, "videos", "videoType", "TEXT NOT NULL DEFAULT 'LONG'")
                addColumnIfNotExists(db, "videos", "durationMs", "INTEGER NOT NULL DEFAULT 0")
                addColumnIfNotExists(db, "videos", "classificationMode", "TEXT NOT NULL DEFAULT 'AUTO'")
                addColumnIfNotExists(db, "videos", "classificationReason", "TEXT NOT NULL DEFAULT 'DURATION'")
                addColumnIfNotExists(db, "videos", "classificationVersion", "TEXT NOT NULL DEFAULT 'v1'")
                addColumnIfNotExists(db, "videos", "copyrightStatus", "TEXT NOT NULL DEFAULT 'CLEAR'")
                addColumnIfNotExists(db, "videos", "contentSha256", "TEXT NOT NULL DEFAULT ''")

                // Add columns to stories table deterministically
                addColumnIfNotExists(db, "stories", "thumbnailUrl", "TEXT NOT NULL DEFAULT ''")
                addColumnIfNotExists(db, "stories", "storyType", "TEXT NOT NULL DEFAULT 'IMAGE'")
                addColumnIfNotExists(db, "stories", "createdAt", "INTEGER NOT NULL DEFAULT 0")
                addColumnIfNotExists(db, "stories", "viewCount", "INTEGER NOT NULL DEFAULT 0")
                addColumnIfNotExists(db, "stories", "isViewed", "INTEGER NOT NULL DEFAULT 0")
                addColumnIfNotExists(db, "stories", "visibility", "TEXT NOT NULL DEFAULT 'PUBLIC'")
                addColumnIfNotExists(db, "stories", "status", "TEXT NOT NULL DEFAULT 'ACTIVE'")

                // Create new tables
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS story_viewers (
                        storyId TEXT NOT NULL,
                        viewerId TEXT NOT NULL,
                        viewerName TEXT NOT NULL,
                        viewerAvatar TEXT NOT NULL,
                        viewedAt INTEGER NOT NULL,
                        PRIMARY KEY(storyId, viewerId)
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS story_reactions (
                        storyId TEXT NOT NULL,
                        userId TEXT NOT NULL,
                        userName TEXT NOT NULL,
                        userAvatar TEXT NOT NULL,
                        reactionEmoji TEXT NOT NULL,
                        timestamp INTEGER NOT NULL,
                        PRIMARY KEY(storyId, userId)
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS story_replies (
                        id TEXT NOT NULL PRIMARY KEY,
                        storyId TEXT NOT NULL,
                        userId TEXT NOT NULL,
                        userName TEXT NOT NULL,
                        userAvatar TEXT NOT NULL,
                        replyText TEXT NOT NULL,
                        timestamp INTEGER NOT NULL
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS story_highlights (
                        id TEXT NOT NULL PRIMARY KEY,
                        userId TEXT NOT NULL,
                        title TEXT NOT NULL,
                        coverUrl TEXT NOT NULL,
                        storyIdsJson TEXT NOT NULL,
                        createdAt INTEGER NOT NULL
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS story_privacy (
                        userId TEXT NOT NULL PRIMARY KEY,
                        defaultVisibility TEXT NOT NULL DEFAULT 'PUBLIC',
                        isArchiveEnabled INTEGER NOT NULL DEFAULT 1,
                        allowReplies INTEGER NOT NULL DEFAULT 1,
                        allowReactions INTEGER NOT NULL DEFAULT 1,
                        allowSharing INTEGER NOT NULL DEFAULT 1,
                        closeFriendsIdsJson TEXT NOT NULL DEFAULT '[]',
                        hideStoryFromIdsJson TEXT NOT NULL DEFAULT '[]'
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS video_classifications (
                        videoId TEXT NOT NULL PRIMARY KEY,
                        videoType TEXT NOT NULL,
                        durationMs INTEGER NOT NULL,
                        classificationMode TEXT NOT NULL,
                        classificationReason TEXT NOT NULL,
                        classificationVersion TEXT NOT NULL DEFAULT 'v1',
                        timestamp INTEGER NOT NULL
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS user_settings (
                        userId TEXT NOT NULL PRIMARY KEY,
                        autoplay INTEGER NOT NULL DEFAULT 1,
                        wifiOnlyUpload INTEGER NOT NULL DEFAULT 0,
                        uploadOverMobileData INTEGER NOT NULL DEFAULT 1,
                        defaultVideoQuality TEXT NOT NULL DEFAULT 'AUTO',
                        defaultUploadType TEXT NOT NULL DEFAULT 'AUTO',
                        autoDetectShortLong INTEGER NOT NULL DEFAULT 1,
                        isStoryArchiveEnabled INTEGER NOT NULL DEFAULT 1,
                        allowStoryReplies INTEGER NOT NULL DEFAULT 1,
                        profileVisibility TEXT NOT NULL DEFAULT 'EVERYONE',
                        whoCanFollowMe TEXT NOT NULL DEFAULT 'EVERYONE',
                        whoCanMessageMe TEXT NOT NULL DEFAULT 'EVERYONE',
                        whoCanComment TEXT NOT NULL DEFAULT 'EVERYONE',
                        activityStatus INTEGER NOT NULL DEFAULT 1,
                        highContrast INTEGER NOT NULL DEFAULT 0,
                        reduceMotion INTEGER NOT NULL DEFAULT 0,
                        textSizeScale REAL NOT NULL DEFAULT 1.0,
                        downloadQuality TEXT NOT NULL DEFAULT 'HD',
                        autoDownload INTEGER NOT NULL DEFAULT 0,
                        cacheSizeBytes INTEGER NOT NULL DEFAULT 0,
                        searchHistoryJson TEXT NOT NULL DEFAULT '[]',
                        watchHistoryJson TEXT NOT NULL DEFAULT '[]',
                        notificationsJson TEXT NOT NULL DEFAULT '{}'
                    )
                """.trimIndent())

                // Create indices deterministically
                db.execSQL("CREATE INDEX IF NOT EXISTS index_stories_userId ON stories(userId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_stories_status ON stories(status)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_stories_expiresAt ON stories(expiresAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_videos_isShort ON videos(isShort)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_videos_channelId ON videos(channelId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_videos_category ON videos(category)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_videos_timestamp ON videos(timestamp)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_story_viewers_storyId ON story_viewers(storyId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_story_viewers_viewerId ON story_viewers(viewerId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_story_reactions_storyId ON story_reactions(storyId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_story_reactions_userId ON story_reactions(userId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_story_replies_storyId ON story_replies(storyId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_story_replies_userId ON story_replies(userId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_story_highlights_userId ON story_highlights(userId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_video_classifications_videoId ON video_classifications(videoId)")
            }
        }

        val MIGRATION_1_3 = object : Migration(1, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                MIGRATION_1_2.migrate(db)
                MIGRATION_2_3.migrate(db)
            }
        }

        fun getDatabase(context: Context): VidBookDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VidBookDatabase::class.java,
                    "vidbook_database"
                )
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_1_3)
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
