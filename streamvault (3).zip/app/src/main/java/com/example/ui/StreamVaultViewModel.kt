package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.StreamVaultApp
import com.example.data.local.ApiKeyEntity
import com.example.data.local.VideoEntity
import com.example.data.repository.VideoRepository
import com.example.server.ExternalClientSimulator
import com.example.server.NetworkUtils
import com.example.server.SimulationResult
import com.example.server.StreamVaultServer
import com.example.server.UploadSession
import com.example.server.UploadStatus
import com.example.server.UploadTracker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class StreamVaultViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as StreamVaultApp
    private val repository: VideoRepository = app.repository
    private val server: StreamVaultServer = app.server

    val isServerRunning: StateFlow<Boolean> = server.isRunning
    val serverError: StateFlow<String?> = server.serverError

    private val _serverIp = MutableStateFlow("127.0.0.1")
    val serverIp: StateFlow<String> = _serverIp.asStateFlow()

    val port: Int = 8080

    val allVideos: StateFlow<List<VideoEntity>> = repository.allVideos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val videoCount: StateFlow<Int> = repository.videoCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalStorageBytes: StateFlow<Long?> = repository.totalStorageBytes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val apiKeys: StateFlow<List<ApiKeyEntity>> = repository.allApiKeys
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeApiKey: StateFlow<String> = repository.allApiKeys
        .combine(MutableStateFlow("")) { keys, _ ->
            keys.firstOrNull { it.isActive }?.key ?: ""
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    // Real-time active uploads
    val activeUploadSessions: StateFlow<List<UploadSession>> = UploadTracker.sessions
        .combine(MutableStateFlow(0)) { map, _ ->
            map.values.sortedByDescending { it.startedAt }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentlyUploadingCount: StateFlow<Int> = UploadTracker.sessions
        .combine(MutableStateFlow(0)) { map, _ ->
            map.values.count { it.status == UploadStatus.UPLOADING }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val serverLogs: StateFlow<List<String>> = UploadTracker.recentLogs

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _requireAuth = MutableStateFlow(true)
    val requireAuth: StateFlow<Boolean> = _requireAuth.asStateFlow()

    val filteredVideos: StateFlow<List<VideoEntity>> = combine(allVideos, _searchQuery) { list, query ->
        if (query.isBlank()) {
            list
        } else {
            list.filter {
                it.title.contains(query, ignoreCase = true) ||
                it.description.contains(query, ignoreCase = true) ||
                it.uploaderApp.contains(query, ignoreCase = true)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Simulator states
    val isSimulating: StateFlow<Boolean> = ExternalClientSimulator.isSimulating
    val clientSimulatorProgress: StateFlow<Float> = ExternalClientSimulator.clientProgress
    val clientSimulatorLogs: StateFlow<List<String>> = ExternalClientSimulator.clientLog

    init {
        refreshIpAddress()
    }

    fun refreshIpAddress() {
        _serverIp.value = NetworkUtils.getLocalIpAddress(getApplication())
    }

    fun toggleServer() {
        if (isServerRunning.value) {
            server.stop()
        } else {
            server.start()
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun deleteVideo(video: VideoEntity) {
        viewModelScope.launch {
            repository.deleteVideo(video)
            UploadTracker.log("Deleted video: '${video.title}' (ID: ${video.id})")
        }
    }

    fun createNewApiKey(name: String) {
        viewModelScope.launch {
            repository.createApiKey(name)
        }
    }

    fun deleteApiKey(apiKey: ApiKeyEntity) {
        viewModelScope.launch {
            repository.deleteApiKey(apiKey)
        }
    }

    fun toggleRequireAuth(enabled: Boolean) {
        _requireAuth.value = enabled
        server.requireApiKey = enabled
        UploadTracker.log("API Key requirement set to: $enabled")
    }

    fun simulateUpload(
        title: String,
        description: String,
        sizeMb: Float,
        onResult: (SimulationResult) -> Unit
    ) {
        val key = activeApiKey.value
        val host = "http://127.0.0.1:$port"
        viewModelScope.launch {
            val result = ExternalClientSimulator.simulateUploadFromExternalApp(
                context = getApplication(),
                serverUrl = host,
                apiKey = key,
                videoTitle = title,
                videoDesc = description,
                sizeMb = sizeMb
            )
            onResult(result)
        }
    }

    fun clearUploadTrackerHistory() {
        UploadTracker.clearCompleted()
    }

    fun getStreamUrl(videoId: String): String {
        return "http://${serverIp.value}:$port/api/videos/$videoId/stream"
    }

    fun getLocalhostStreamUrl(videoId: String): String {
        return "http://127.0.0.1:$port/api/videos/$videoId/stream"
    }
}
