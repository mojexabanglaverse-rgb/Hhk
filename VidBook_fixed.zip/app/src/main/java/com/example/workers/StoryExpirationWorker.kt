package com.example.workers

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.data.local.VidBookDatabase
import java.util.concurrent.TimeUnit

class StoryExpirationWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val tag = "StoryExpirationWorker"
        return try {
            val db = VidBookDatabase.getDatabase(applicationContext)
            val storyDao = db.storyDao()
            val interactionDao = db.storyInteractionDao()
            val userSettingsDao = db.userSettingsDao()

            val currentTime = System.currentTimeMillis()
            val expiredStories = storyDao.getExpiredStories(currentTime)

            Log.d(tag, "Checking expired stories at $currentTime: found ${expiredStories.size} expired stories")

            for (story in expiredStories) {
                // Check if user has story archive enabled
                val storyPrivacy = interactionDao.getStoryPrivacy(story.userId)
                val userSettings = userSettingsDao.getUserSettings(story.userId)

                val isArchiveEnabled = storyPrivacy?.isArchiveEnabled
                    ?: userSettings?.isStoryArchiveEnabled
                    ?: true

                if (isArchiveEnabled) {
                    // Move to archived state: marked EXPIRED so active feed excludes it, but available in archive
                    storyDao.updateStoryStatus(story.id, "EXPIRED")
                    Log.d(tag, "Story ${story.id} marked EXPIRED and kept in archive")
                } else {
                    // Retention policy: archive disabled -> permanently remove from database
                    storyDao.deleteStory(story.id)
                    Log.d(tag, "Story ${story.id} permanently deleted as archive is disabled")
                }
            }

            Result.success()
        } catch (e: Exception) {
            Log.e(tag, "Error running StoryExpirationWorker", e)
            Result.retry()
        }
    }

    companion object {
        private const val WORK_NAME = "vidbook_story_expiration_worker"

        fun schedulePeriodic(context: Context) {
            try {
                val workRequest = PeriodicWorkRequestBuilder<StoryExpirationWorker>(
                    repeatInterval = 15,
                    repeatIntervalTimeUnit = TimeUnit.MINUTES
                ).build()

                WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                    WORK_NAME,
                    ExistingPeriodicWorkPolicy.KEEP,
                    workRequest
                )
            } catch (e: Exception) {
                Log.w("StoryExpirationWorker", "Failed to schedule periodic story cleanup", e)
            }
        }
    }
}
