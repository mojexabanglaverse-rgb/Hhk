package com.example.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FormatColorFill
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil3.compose.AsyncImage
import com.example.data.model.StoryType
import com.example.data.model.StoryVisibility
import com.example.ui.theme.VidBookBlue
import com.example.ui.theme.VidBookRed
import com.example.ui.util.appString

// Predefined rich gradient themes for Text Stories
data class StoryGradientTheme(
    val id: String,
    val name: String,
    val colors: List<Color>,
    val textColor: Color = Color.White
)

val storyGradientPresets = listOf(
    StoryGradientTheme("sunset", "সানসেট", listOf(Color(0xFFFF512F), Color(0xFFDD2476))),
    StoryGradientTheme("neon_purple", "পার্পল গ্লো", listOf(Color(0xFF8A2387), Color(0xFFE94057), Color(0xFFF27121))),
    StoryGradientTheme("royal_blue", "রয়েল ব্লু", listOf(Color(0xFF1488CC), Color(0xFF2B32B2))),
    StoryGradientTheme("emerald", "পান্না সবুজ", listOf(Color(0xFF00b09b), Color(0xFF96c93d))),
    StoryGradientTheme("dark_obsidian", "ডার্ক মোড", listOf(Color(0xFF1F1C2C), Color(0xFF4A4562))),
    StoryGradientTheme("cherry_flame", "চেরি ফ্লেম", listOf(Color(0xFFEB3349), Color(0xFFF45C43))),
    StoryGradientTheme("cyber_neon", "সাইবার নিয়ন", listOf(Color(0xFF00F260), Color(0xFF0575E6))),
    StoryGradientTheme("golden_amber", "গোল্ডেন", listOf(Color(0xFFF7971E), Color(0xFFFFD200)), textColor = Color.Black)
)

val presetStoryPhotos = listOf(
    "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&q=80", // Beach
    "https://images.unsplash.com/photo-1519681393784-d120267933ba?w=800&q=80", // Starry Night
    "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&q=80", // Nature Lake
    "https://images.unsplash.com/photo-1477959858617-67f30bc75b82?w=800&q=80", // City Skyline
    "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=800&q=80", // Aesthetic Portrait
    "https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=800&q=80"  // Travel Landscape
)

val presetStoryVideos = listOf(
    "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4",
    "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4"
)

@Composable
fun CreateStoryDialog(
    onDismiss: () -> Unit,
    onPublishStory: (storyType: StoryType, mediaUrl: String, caption: String, visibility: StoryVisibility, thumbnailUrl: String) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Text, 1: Photo, 2: Video
    var selectedVisibility by remember { mutableStateOf(StoryVisibility.PUBLIC) }

    // Text Story State
    var textStoryContent by remember { mutableStateOf("") }
    var selectedGradientIndex by remember { mutableIntStateOf(0) }
    var textAlignment by remember { mutableStateOf(TextAlign.Center) }
    var textFontSize by remember { mutableIntStateOf(22) }

    // Photo Story State
    var photoUrl by remember { mutableStateOf(presetStoryPhotos.first()) }
    var photoCaption by remember { mutableStateOf("") }

    // Video Story State
    var videoUrl by remember { mutableStateOf(presetStoryVideos.first()) }
    var videoCaption by remember { mutableStateOf("") }

    // System Image Picker
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let { photoUrl = it.toString() }
    }

    // System Video Picker
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let { videoUrl = it.toString() }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .testTag("create_story_dialog"),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Top App Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_story_creator_btn")) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }

                    Text(
                        text = appString("স্টোরি তৈরি করুন", "Create Story"),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )

                    // Privacy Pill Selector
                    StoryPrivacySelector(
                        selected = selectedVisibility,
                        onSelect = { selectedVisibility = it }
                    )
                }

                // Story Type Tabs (Text, Photo, Video)
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = VidBookBlue
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text(appString("টেক্সট", "Text"), fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.TextFields, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        modifier = Modifier.testTag("tab_text_story")
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text(appString("ছবি", "Photo"), fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        modifier = Modifier.testTag("tab_photo_story")
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text(appString("ভিডিও", "Video"), fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        modifier = Modifier.testTag("tab_video_story")
                    )
                }

                // Body content based on tab
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    when (selectedTab) {
                        0 -> {
                            // TEXT STORY PREVIEW & EDITOR
                            val currentTheme = storyGradientPresets[selectedGradientIndex]
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(340.dp)
                                    .clip(RoundedCornerShape(16.dp)),
                                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Brush.linearGradient(currentTheme.colors))
                                        .padding(24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (textStoryContent.isNotBlank()) textStoryContent else appString("এখানে কিছু লিখুন...", "Type something here..."),
                                        color = if (textStoryContent.isNotBlank()) currentTheme.textColor else currentTheme.textColor.copy(alpha = 0.6f),
                                        fontSize = textFontSize.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = textAlignment,
                                        lineHeight = (textFontSize + 8).sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Text input field
                            OutlinedTextField(
                                value = textStoryContent,
                                onValueChange = { textStoryContent = it },
                                label = { Text(appString("স্টোরি টেক্সট লিখুন", "Write Story Text")) },
                                placeholder = { Text(appString("আজকে কি মনে হচ্ছে?", "What's on your mind today?")) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("story_text_input"),
                                maxLines = 4,
                                shape = RoundedCornerShape(12.dp)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Gradient theme palette selector
                            Text(
                                text = appString("ব্যাকগ্রাউন্ড কালার থিম", "Background Color Theme"),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                contentPadding = PaddingValues(horizontal = 4.dp)
                            ) {
                                itemsIndexed(storyGradientPresets) { index, theme ->
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .clip(CircleShape)
                                            .background(Brush.linearGradient(theme.colors))
                                            .border(
                                                width = if (selectedGradientIndex == index) 3.dp else 1.dp,
                                                color = if (selectedGradientIndex == index) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.5f),
                                                shape = CircleShape
                                            )
                                            .clickable { selectedGradientIndex = index },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (selectedGradientIndex == index) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = null,
                                                tint = theme.textColor,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Font size adjustment chips
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = appString("ফন্ট সাইজ:", "Font Size:"),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                listOf(18 to "ছোট", 22 to "মাঝারি", 28 to "বড়").forEach { (size, label) ->
                                    FilterChip(
                                        selected = textFontSize == size,
                                        onClick = { textFontSize = size },
                                        label = { Text(label, fontSize = 12.sp) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = VidBookBlue,
                                            selectedLabelColor = Color.White
                                        )
                                    )
                                }
                            }
                        }

                        1 -> {
                            // PHOTO STORY PREVIEW & EDITOR
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(340.dp)
                                    .clip(RoundedCornerShape(16.dp)),
                                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                            ) {
                                Box(modifier = Modifier.fillMaxSize()) {
                                    AsyncImage(
                                        model = photoUrl,
                                        contentDescription = null,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )

                                    if (photoCaption.isNotBlank()) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .align(Alignment.BottomCenter)
                                                .background(
                                                    Brush.verticalGradient(
                                                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))
                                                    )
                                                )
                                                .padding(16.dp)
                                        ) {
                                            Text(
                                                text = photoCaption,
                                                color = Color.White,
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Pick from gallery button & URL input
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { imagePickerLauncher.launch("image/*") },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = VidBookBlue)
                                ) {
                                    Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(appString("গ্যালারি থেকে ছবি নিন", "Pick From Gallery"), fontSize = 12.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = photoUrl,
                                onValueChange = { photoUrl = it },
                                label = { Text(appString("ছবির ওয়েব URL", "Photo Web URL")) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp)
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = photoCaption,
                                onValueChange = { photoCaption = it },
                                label = { Text(appString("ক্যাপশন বা বার্তা লিখুন (ঐচ্ছিক)", "Caption or Message (Optional)")) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = appString("রেডিমেড সুন্দর ছবি সিলেক্ট করুন:", "Select Ready Preset Photo:"),
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(presetStoryPhotos) { url ->
                                    AsyncImage(
                                        model = url,
                                        contentDescription = null,
                                        modifier = Modifier
                                            .size(60.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .border(
                                                width = if (photoUrl == url) 2.5.dp else 1.dp,
                                                color = if (photoUrl == url) VidBookBlue else Color.Transparent,
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .clickable { photoUrl = url },
                                        contentScale = ContentScale.Crop
                                    )
                                }
                            }
                        }

                        2 -> {
                            // VIDEO STORY PREVIEW & EDITOR
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(300.dp)
                                    .clip(RoundedCornerShape(16.dp)),
                                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Black),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.padding(16.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Videocam,
                                            contentDescription = null,
                                            tint = VidBookRed,
                                            modifier = Modifier.size(54.dp)
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = appString("ভিডিও স্টোরি প্রিভিউ", "Video Story Preview"),
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = videoUrl.takeLast(35),
                                            color = Color.White.copy(alpha = 0.7f),
                                            fontSize = 12.sp,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(modifier = Modifier.fillMaxWidth()) {
                                Button(
                                    onClick = { videoPickerLauncher.launch("video/*") },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = VidBookRed)
                                ) {
                                    Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(appString("গ্যালারি থেকে ভিডিও নির্বাচন করুন", "Pick Video from Gallery"), fontSize = 13.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = videoUrl,
                                onValueChange = { videoUrl = it },
                                label = { Text(appString("ভিডিও লিংক (URL)", "Video URL")) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp)
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = videoCaption,
                                onValueChange = { videoCaption = it },
                                label = { Text(appString("ভিডিও ক্যাপশন লিখুন", "Video Caption")) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // 24-Hour Expiration Info Box
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "⏱️", fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = appString(
                                    "এই স্টোরিটি প্রকাশের ঠিক ২৪ ঘণ্টা পর স্বয়ংক্রিয়ভাবে এক্সপায়ার হয়ে আর্কাইভে সংরক্ষিত হবে।",
                                    "This Story will automatically expire in exactly 24 hours and be saved in your Archive."
                                ),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Bottom Action Bar: Publish Button
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    tonalElevation = 4.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text(appString("বাতিল", "Cancel"))
                        }

                        Button(
                            onClick = {
                                when (selectedTab) {
                                    0 -> {
                                        // Text Story: encode gradient theme index or colors in mediaUrl
                                        val media = "gradient://${storyGradientPresets[selectedGradientIndex].id}"
                                        onPublishStory(
                                            StoryType.TEXT,
                                            media,
                                            textStoryContent,
                                            selectedVisibility,
                                            ""
                                        )
                                    }
                                    1 -> {
                                        onPublishStory(
                                            StoryType.IMAGE,
                                            photoUrl,
                                            photoCaption,
                                            selectedVisibility,
                                            photoUrl
                                        )
                                    }
                                    2 -> {
                                        onPublishStory(
                                            StoryType.VIDEO,
                                            videoUrl,
                                            videoCaption,
                                            selectedVisibility,
                                            "https://images.unsplash.com/photo-1536240478700-b869070f9279?w=600&q=80"
                                        )
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = VidBookBlue),
                            modifier = Modifier.testTag("publish_story_btn")
                        ) {
                            Text(
                                text = appString("স্টোরিতে শেয়ার করুন", "Share to Story"),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StoryPrivacySelector(
    selected: StoryVisibility,
    onSelect: (StoryVisibility) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        Surface(
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .clickable { expanded = true }
                .testTag("story_privacy_selector"),
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = when (selected) {
                        StoryVisibility.PUBLIC -> Icons.Default.Public
                        StoryVisibility.CLOSE_FRIENDS -> Icons.Default.Star
                        StoryVisibility.ONLY_ME -> Icons.Default.Lock
                        else -> Icons.Default.Public
                    },
                    contentDescription = null,
                    modifier = Modifier.size(14.dp),
                    tint = if (selected == StoryVisibility.CLOSE_FRIENDS) Color(0xFF4CAF50) else MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = selected.titleBn,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            StoryVisibility.values().forEach { vis ->
                DropdownMenuItem(
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = when (vis) {
                                    StoryVisibility.PUBLIC -> Icons.Default.Public
                                    StoryVisibility.CLOSE_FRIENDS -> Icons.Default.Star
                                    StoryVisibility.ONLY_ME -> Icons.Default.Lock
                                    else -> Icons.Default.Public
                                },
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = if (vis == StoryVisibility.CLOSE_FRIENDS) Color(0xFF4CAF50) else MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(vis.titleBn)
                        }
                    },
                    onClick = {
                        onSelect(vis)
                        expanded = false
                    }
                )
            }
        }
    }
}
