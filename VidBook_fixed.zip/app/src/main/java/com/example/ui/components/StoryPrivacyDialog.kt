package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil3.compose.AsyncImage
import com.example.data.model.StoryPrivacySettings
import com.example.data.model.StoryVisibility
import com.example.ui.theme.VidBookBlue
import com.example.ui.util.appString

// Mock sample friends for selection
data class SampleFriendItem(
    val id: String,
    val name: String,
    val avatarUrl: String
)

val sampleFriendsList = listOf(
    SampleFriendItem("f_1", "সাদিয়া রহমান", "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80"),
    SampleFriendItem("f_2", "রাকিব হাসান", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80"),
    SampleFriendItem("f_3", "তানভীর আহমেদ", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&q=80"),
    SampleFriendItem("f_4", "মেহজাবীন চৌধুরী", "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&q=80"),
    SampleFriendItem("f_5", "তাহসান খান", "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&q=80")
)

@Composable
fun StoryPrivacyDialog(
    initialSettings: StoryPrivacySettings,
    onDismiss: () -> Unit,
    onSaveSettings: (StoryPrivacySettings) -> Unit
) {
    var selectedVisibility by remember { mutableStateOf(initialSettings.defaultVisibility) }
    var isArchiveEnabled by remember { mutableStateOf(initialSettings.isArchiveEnabled) }
    var allowReplies by remember { mutableStateOf(initialSettings.allowReplies) }
    var allowReactions by remember { mutableStateOf(initialSettings.allowReactions) }
    var closeFriends by remember { mutableStateOf(initialSettings.closeFriendsIds.toSet()) }
    var hideFrom by remember { mutableStateOf(initialSettings.hideStoryFromIds.toSet()) }

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Privacy, 1: Close Friends, 2: Hide From

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .testTag("story_privacy_dialog"),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Top App Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }

                    Text(
                        text = appString("স্টোরি প্রাইভেসি সেটিংস", "Story Privacy Settings"),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )

                    Button(
                        onClick = {
                            val updated = initialSettings.copy(
                                defaultVisibility = selectedVisibility,
                                isArchiveEnabled = isArchiveEnabled,
                                allowReplies = allowReplies,
                                allowReactions = allowReactions,
                                closeFriendsIds = closeFriends.toList(),
                                hideStoryFromIds = hideFrom.toList()
                            )
                            onSaveSettings(updated)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VidBookBlue),
                        modifier = Modifier.testTag("save_privacy_settings_btn")
                    ) {
                        Text(appString("সংরক্ষণ", "Save"), fontWeight = FontWeight.Bold)
                    }
                }

                // Tabs: Privacy, Close Friends, Hide Story
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = VidBookBlue
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text(appString("প্রাইভেসি", "Privacy"), fontSize = 13.sp) },
                        icon = { Icon(Icons.Default.Public, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text(appString("ক্লোজ ফ্রেন্ডস", "Close Friends"), fontSize = 13.sp) },
                        icon = { Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFF4CAF50), modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text(appString("লুকিয়ে রাখুন", "Hide From"), fontSize = 13.sp) },
                        icon = { Icon(Icons.Default.VisibilityOff, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                }

                when (selectedTab) {
                    0 -> {
                        // Main Privacy Options
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp)
                        ) {
                            item {
                                Text(
                                    text = appString("আপনার স্টোরি কারা দেখতে পারবে?", "Who can see your Stories?"),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                            }

                            items(StoryVisibility.values()) { vis ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clickable { selectedVisibility = vis },
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (selectedVisibility == vis)
                                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                                        else MaterialTheme.colorScheme.surface
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = when (vis) {
                                                StoryVisibility.PUBLIC -> Icons.Default.Public
                                                StoryVisibility.FRIENDS -> Icons.Default.Group
                                                StoryVisibility.CLOSE_FRIENDS -> Icons.Default.Star
                                                StoryVisibility.ONLY_ME -> Icons.Default.Lock
                                                else -> Icons.Default.Public
                                            },
                                            contentDescription = null,
                                            tint = if (vis == StoryVisibility.CLOSE_FRIENDS) Color(0xFF4CAF50) else MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = vis.titleBn,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp
                                            )
                                            Text(
                                                text = when (vis) {
                                                    StoryVisibility.PUBLIC -> "যে কেউ আপনার স্টোরি দেখতে পারে"
                                                    StoryVisibility.FRIENDS -> "শুধুমাত্র আপনার ফেসবুক/অ্যাপ বন্ধুরা দেখতে পারে"
                                                    StoryVisibility.CLOSE_FRIENDS -> "আপনার পছন্দের ক্লোজ ফ্রেন্ড লিস্টের সদস্যরা (সবুজ স্টার)"
                                                    StoryVisibility.ONLY_ME -> "শুধুমাত্র আপনি দেখতে পারবেন (প্রাইভেট)"
                                                    else -> vis.titleEn
                                                },
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        RadioButton(
                                            selected = selectedVisibility == vis,
                                            onClick = { selectedVisibility = vis }
                                        )
                                    }
                                }
                            }

                            item {
                                Spacer(modifier = Modifier.height(16.dp))
                                HorizontalDivider()
                                Spacer(modifier = Modifier.height(16.dp))

                                Text(
                                    text = appString("স্টোরি ফিচার সেটিংস", "Story Feature Settings"),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(12.dp))

                                // Archive switch
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Archive, contentDescription = null, tint = VidBookBlue)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(appString("স্টোরি স্বয়ংক্রিয়ভাবে আর্কাইভে সেভ করুন", "Auto-Save Stories to Archive"), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                        Text(appString("২৪ ঘণ্টা পর স্টোরি আপনার ব্যক্তিগত আর্কাইভে জমা থাকবে", "Stories will be saved in your private archive after 24h"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Switch(
                                        checked = isArchiveEnabled,
                                        onCheckedChange = { isArchiveEnabled = it }
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Allow replies switch
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(appString("দর্শকদের মেসেজ রিপ্লাই অনুমোদন করুন", "Allow Viewers to Reply"), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                        Text(appString("দর্শকরা স্টোরিতে টেক্সট রিপ্লাই পাঠাতে পারবে", "Viewers can send text replies to your story"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Switch(
                                        checked = allowReplies,
                                        onCheckedChange = { allowReplies = it }
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Allow reactions switch
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(appString("ইমোজি রিঅ্যাকশন অনুমোদন করুন", "Allow Emoji Reactions"), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                        Text(appString("দর্শকরা লাভ, হা হা ইত্যাদি রিঅ্যাকশন দিতে পারবে", "Viewers can send Love, Haha, etc reactions"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Switch(
                                        checked = allowReactions,
                                        onCheckedChange = { allowReactions = it }
                                    )
                                }
                            }
                        }
                    }

                    1 -> {
                        // Close Friends Selection
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp)
                        ) {
                            item {
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    color = Color(0xFF4CAF50).copy(alpha = 0.12f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFF4CAF50))
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = appString(
                                                "ক্লোজ ফ্রেন্ডরা আপনার বিশেষ স্টোরি দেখতে পাবে। তাদের স্টোরি বর্ডারে সবুজ স্টার রিং প্রদর্শিত হবে।",
                                                "Close Friends can see your exclusive stories with a green star ring."
                                            ),
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = appString("বন্ধুদের তালিকায় যোগ করুন (${closeFriends.size} জন নির্বাচিত)", "Add to Close Friends (${closeFriends.size} selected)"),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                            }

                            items(sampleFriendsList) { friend ->
                                val isSelected = closeFriends.contains(friend.id)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            closeFriends = if (isSelected) closeFriends - friend.id else closeFriends + friend.id
                                        }
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AsyncImage(
                                        model = friend.avatarUrl,
                                        contentDescription = null,
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape),
                                        contentScale = androidx.compose.ui.layout.ContentScale.Crop
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = friend.name,
                                        fontWeight = FontWeight.Medium,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Checkbox(
                                        checked = isSelected,
                                        onCheckedChange = { checked ->
                                            closeFriends = if (checked) closeFriends + friend.id else closeFriends - friend.id
                                        },
                                        colors = CheckboxDefaults.colors(checkedColor = Color(0xFF4CAF50))
                                    )
                                }
                            }
                        }
                    }

                    2 -> {
                        // Hide Story From Selection
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp)
                        ) {
                            item {
                                Text(
                                    text = appString(
                                        "যাদের থেকে স্টোরি লুকিয়ে রাখতে চান তাদের নির্বাচন করুন:",
                                        "Select people you want to hide your story from:"
                                    ),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                            }

                            items(sampleFriendsList) { friend ->
                                val isHidden = hideFrom.contains(friend.id)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            hideFrom = if (isHidden) hideFrom - friend.id else hideFrom + friend.id
                                        }
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AsyncImage(
                                        model = friend.avatarUrl,
                                        contentDescription = null,
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape),
                                        contentScale = androidx.compose.ui.layout.ContentScale.Crop
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = friend.name,
                                        fontWeight = FontWeight.Medium,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Checkbox(
                                        checked = isHidden,
                                        onCheckedChange = { checked ->
                                            hideFrom = if (checked) hideFrom + friend.id else hideFrom - friend.id
                                        },
                                        colors = CheckboxDefaults.colors(checkedColor = VidBookBlue)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
