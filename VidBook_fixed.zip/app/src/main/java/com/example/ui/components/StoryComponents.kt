@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.media3.common.util.UnstableApi::class
)

package com.example.ui.components

import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Report
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil3.compose.AsyncImage
import com.example.data.model.Story
import com.example.data.model.StoryReaction
import com.example.data.model.StoryReply
import com.example.data.model.StoryViewer
import com.example.data.model.StoryVisibility
import com.example.ui.theme.StoryGradientCenter
import com.example.ui.theme.StoryGradientEnd
import com.example.ui.theme.StoryGradientStart
import com.example.ui.theme.VidBookBlue
import com.example.ui.theme.VidBookRed
import com.example.ui.util.appString
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf

// User Story Group representation for Facebook-style tray
data class UserStoryGroup(
    val userId: String,
    val userName: String,
    val userAvatar: String,
    val stories: List<Story>,
    val hasUnseen: Boolean,
    val isCloseFriends: Boolean
)

@Composable
fun StoryRow(
    stories: List<Story>,
    userAvatarUrl: String?,
    onAddStoryClick: () -> Unit,
    onStoryClick: (Story) -> Unit,
    modifier: Modifier = Modifier,
    currentUserId: String? = null,
    onStoryGroupClick: ((List<Story>, Int) -> Unit)? = null
) {
    // Group active stories by user
    val userGroups = remember(stories) {
        stories.groupBy { it.userId }.map { (uId, uStories) ->
            val first = uStories.first()
            UserStoryGroup(
                userId = uId,
                userName = first.userName,
                userAvatar = first.userAvatar,
                stories = uStories,
                hasUnseen = uStories.any { !it.isSeen },
                isCloseFriends = uStories.any { it.visibility == StoryVisibility.CLOSE_FRIENDS.name }
            )
        }
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp
    ) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // First Item: "+ Your Story"
            item {
                AddStoryCard(
                    userAvatarUrl = userAvatarUrl,
                    onClick = onAddStoryClick
                )
            }

            // Other User Story Groups
            items(userGroups) { group ->
                StoryGroupBubble(
                    group = group,
                    onClick = {
                        if (onStoryGroupClick != null) {
                            val firstUnseenIdx = group.stories.indexOfFirst { !it.isSeen }.let { if (it >= 0) it else 0 }
                            onStoryGroupClick(group.stories, firstUnseenIdx)
                        } else {
                            val targetStory = group.stories.firstOrNull { !it.isSeen } ?: group.stories.first()
                            onStoryClick(targetStory)
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun AddStoryCard(
    userAvatarUrl: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .width(105.dp)
            .height(165.dp)
            .clickable(onClick = onClick)
            .testTag("add_story_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            AsyncImage(
                model = userAvatarUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80",
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(115.dp)
                    .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp)),
                contentScale = ContentScale.Crop
            )

            // Circular Add button overlapping top and bottom
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 26.dp)
                    .clip(CircleShape)
                    .background(VidBookBlue)
                    .border(2.5.dp, MaterialTheme.colorScheme.surface, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = appString("স্টোরি দিন", "Add Story"),
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }

            Text(
                text = appString("স্টোরি দিন", "Add Story"),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 6.dp)
            )
        }
    }
}

@Composable
fun StoryGroupBubble(
    group: UserStoryGroup,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val firstStory = group.stories.first()
    val isCloseFriends = group.isCloseFriends

    val ringBrush = remember(group.hasUnseen, isCloseFriends) {
        when {
            isCloseFriends -> Brush.linearGradient(listOf(Color(0xFF4CAF50), Color(0xFF81C784)))
            group.hasUnseen -> Brush.linearGradient(listOf(StoryGradientStart, StoryGradientCenter, StoryGradientEnd))
            else -> Brush.linearGradient(listOf(Color.LightGray, Color.Gray))
        }
    }

    Card(
        modifier = modifier
            .width(105.dp)
            .height(165.dp)
            .clickable(onClick = onClick)
            .testTag("story_group_${group.userId}"),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Story preview background
            if (firstStory.storyType == "TEXT") {
                // Text story gradient background preview
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF8A2387), Color(0xFFE94057), Color(0xFFF27121))
                            )
                        )
                        .padding(10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = firstStory.caption.ifBlank { "Text Story" },
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            } else {
                AsyncImage(
                    model = firstStory.mediaUrl,
                    contentDescription = firstStory.caption,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }

            // Dark gradient overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.35f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.8f)
                            )
                        )
                    )
            )

            // Top User Avatar with Gradient Ring
            Box(
                modifier = Modifier
                    .padding(8.dp)
                    .size(38.dp)
                    .align(Alignment.TopStart)
                    .clip(CircleShape)
                    .border(2.5.dp, ringBrush, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = group.userAvatar,
                    contentDescription = group.userName,
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
            }

            // Multiple Stories Count Badge
            if (group.stories.size > 1) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.Black.copy(alpha = 0.65f),
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                ) {
                    Text(
                        text = "${group.stories.size}",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                    )
                }
            }

            // User Name at bottom
            Text(
                text = group.userName,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
            )
        }
    }
}

// -------------------------------------------------------------
// FULL-FEATURED 24-HOUR STORY VIEWER (FACEBOOK STYLE)
// -------------------------------------------------------------

@Composable
fun StoryViewerModal(
    story: Story,
    onClose: () -> Unit,
    onReply: (String) -> Unit
) {
    // Backward compatible overload
    StoryViewerModal(
        story = story,
        storyGroup = listOf(story),
        currentIndex = 0,
        currentUserId = null,
        onNext = onClose,
        onPrevious = {},
        onClose = onClose,
        onReply = onReply,
        onReaction = {},
        onDeleteStory = {},
        onOpenPrivacy = {}
    )
}

@OptIn(UnstableApi::class)
@Composable
fun StoryViewerModal(
    story: Story,
    storyGroup: List<Story> = listOf(story),
    currentIndex: Int = 0,
    currentUserId: String? = null,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onClose: () -> Unit,
    onReply: (String) -> Unit,
    onReaction: (String) -> Unit,
    onDeleteStory: (String) -> Unit = {},
    onOpenPrivacy: () -> Unit = {},
    viewersFlow: Flow<List<StoryViewer>> = flowOf(emptyList()),
    reactionsFlow: Flow<List<StoryReaction>> = flowOf(emptyList()),
    repliesFlow: Flow<List<StoryReply>> = flowOf(emptyList())
) {
    val context = LocalContext.current
    val isOwner = currentUserId != null && currentUserId == story.userId

    var replyText by remember { mutableStateOf("") }
    var isPaused by remember { mutableStateOf(false) }
    var isMuted by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var showViewersSheet by remember { mutableStateOf(false) }
    var floatingReactionEmoji by remember { mutableStateOf<String?>(null) }

    // Multi-story progress state: each story has a segment
    val progress = remember { Animatable(0f) }

    // ExoPlayer for video stories
    var exoPlayer by remember { mutableStateOf<ExoPlayer?>(null) }

    val isVideoStory = story.storyType == "VIDEO" || story.isVideo

    // Initialize/cleanup video player when story changes
    DisposableEffect(story.id, isVideoStory) {
        if (isVideoStory && story.mediaUrl.isNotBlank() && !story.mediaUrl.startsWith("gradient://")) {
            val player = ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(Uri.parse(story.mediaUrl)))
                prepare()
                playWhenReady = true
                volume = if (isMuted) 0f else 1f
                addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(state: Int) {
                        if (state == Player.STATE_ENDED) {
                            onNext()
                        }
                    }
                })
            }
            exoPlayer = player
        }

        onDispose {
            exoPlayer?.release()
            exoPlayer = null
        }
    }

    // Story progress animation timer
    LaunchedEffect(story.id, isPaused) {
        if (!isPaused) {
            val duration = if (isVideoStory) 12000 else 6000
            val target = 1f
            val remaining = (1f - progress.value) * duration

            progress.animateTo(
                targetValue = target,
                animationSpec = tween(durationMillis = remaining.toInt(), easing = LinearEasing)
            )

            if (progress.value >= 0.99f) {
                onNext()
            }
        }
    }

    // Reset progress when index/story changes
    LaunchedEffect(story.id) {
        progress.snapTo(0f)
    }

    // Mute control
    LaunchedEffect(isMuted) {
        exoPlayer?.volume = if (isMuted) 0f else 1f
    }

    // Floating reaction dismiss
    LaunchedEffect(floatingReactionEmoji) {
        if (floatingReactionEmoji != null) {
            delay(1200)
            floatingReactionEmoji = null
        }
    }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .testTag("story_viewer_modal")
                // Swipe down to close gesture
                .pointerInput(Unit) {
                    detectVerticalDragGestures { _, dragAmount ->
                        if (dragAmount > 50f) {
                            onClose()
                        }
                    }
                }
        ) {
            // Story Media Canvas
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    // Tap gestures: Left 30% -> Previous, Right 70% -> Next, Press & Hold -> Pause
                    .pointerInput(story.id) {
                        detectTapGestures(
                            onPress = {
                                isPaused = true
                                exoPlayer?.pause()
                                tryAwaitRelease()
                                isPaused = false
                                exoPlayer?.play()
                            },
                            onTap = { offset ->
                                if (offset.x < size.width * 0.3f) {
                                    onPrevious()
                                } else {
                                    onNext()
                                }
                            }
                        )
                    }
            ) {
                when {
                    story.storyType == "TEXT" || story.mediaUrl.startsWith("gradient://") -> {
                        // Rich Text Story Canvas
                        val gradientColors = remember(story.mediaUrl) {
                            when {
                                story.mediaUrl.contains("sunset") -> listOf(Color(0xFFFF512F), Color(0xFFDD2476))
                                story.mediaUrl.contains("royal_blue") -> listOf(Color(0xFF1488CC), Color(0xFF2B32B2))
                                story.mediaUrl.contains("emerald") -> listOf(Color(0xFF00b09b), Color(0xFF96c93d))
                                story.mediaUrl.contains("dark_obsidian") -> listOf(Color(0xFF1F1C2C), Color(0xFF4A4562))
                                story.mediaUrl.contains("cherry_flame") -> listOf(Color(0xFFEB3349), Color(0xFFF45C43))
                                else -> listOf(Color(0xFF8A2387), Color(0xFFE94057), Color(0xFFF27121))
                            }
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Brush.linearGradient(gradientColors))
                                .padding(36.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = story.caption,
                                color = Color.White,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                lineHeight = 36.sp
                            )
                        }
                    }

                    isVideoStory && exoPlayer != null -> {
                        // Video Story Player
                        AndroidView(
                            factory = { ctx ->
                                PlayerView(ctx).apply {
                                    player = exoPlayer
                                    useController = false
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    else -> {
                        // Photo Story
                        AsyncImage(
                            model = story.mediaUrl,
                            contentDescription = story.caption,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            }

            // Top Gradient & Bottom Gradient Overlays
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .align(Alignment.TopCenter)
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Black.copy(alpha = 0.8f), Color.Transparent)
                        )
                    )
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .align(Alignment.BottomCenter)
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                        )
                    )
            )

            // Top Header: Segmented Progress Bars & User Info
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(top = 36.dp, start = 14.dp, end = 14.dp)
            ) {
                // Segmented Progress Bars (one for each story of this user)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val totalStories = storyGroup.size.coerceAtLeast(1)
                    val activeIdx = currentIndex.coerceIn(0, totalStories - 1)

                    storyGroup.forEachIndexed { index, _ ->
                        val segmentProgress = when {
                            index < activeIdx -> 1f
                            index == activeIdx -> progress.value
                            else -> 0f
                        }

                        LinearProgressIndicator(
                            progress = { segmentProgress },
                            modifier = Modifier
                                .weight(1f)
                                .height(3.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = Color.White,
                            trackColor = Color.White.copy(alpha = 0.3f),
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // User Info, Timestamp, Mute, Menu, Close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncImage(
                        model = story.userAvatar,
                        contentDescription = null,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, Color.White, CircleShape),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = story.userName,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            if (story.visibility == StoryVisibility.CLOSE_FRIENDS.name) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = "Close Friends",
                                    tint = Color(0xFF4CAF50),
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                        Text(
                            text = "${story.timeAgo} • ${appString("২৪ ঘণ্টার স্টোরি", "24h Story")}",
                            color = Color.White.copy(alpha = 0.75f),
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    // Audio Mute Toggle for Video
                    if (isVideoStory) {
                        IconButton(onClick = { isMuted = !isMuted }) {
                            Icon(
                                imageVector = if (isMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                                contentDescription = "Mute",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    // Overflow Menu
                    Box {
                        IconButton(onClick = { showMenu = true }) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "More",
                                tint = Color.White
                            )
                        }
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false }
                        ) {
                            if (isOwner) {
                                DropdownMenuItem(
                                    text = { Text(appString("স্টোরি ডিলিট করুন", "Delete Story"), color = VidBookRed) },
                                    leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = VidBookRed) },
                                    onClick = {
                                        showMenu = false
                                        onDeleteStory(story.id)
                                    }
                                )
                            } else {
                                DropdownMenuItem(
                                    text = { Text(appString("স্টোরি মিউট করুন", "Mute Stories")) },
                                    leadingIcon = { Icon(Icons.Default.NotificationsOff, contentDescription = null) },
                                    onClick = {
                                        showMenu = false
                                        onClose()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(appString("রিপোর্ট করুন", "Report Story")) },
                                    leadingIcon = { Icon(Icons.Default.Report, contentDescription = null) },
                                    onClick = {
                                        showMenu = false
                                        onClose()
                                    }
                                )
                            }
                        }
                    }

                    // Close Button
                    IconButton(onClick = onClose) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = appString("বন্ধ করুন", "Close"),
                            tint = Color.White
                        )
                    }
                }

                // Optional Caption for image/video stories
                if (story.caption.isNotBlank() && story.storyType != "TEXT" && !story.mediaUrl.startsWith("gradient://")) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = story.caption,
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .background(
                                Color.Black.copy(alpha = 0.5f),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            // Floating Animated Emoji Reaction Feedback
            AnimatedVisibility(
                visible = floatingReactionEmoji != null,
                enter = fadeIn() + scaleIn(),
                exit = fadeOut() + scaleOut(),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Text(
                    text = floatingReactionEmoji ?: "",
                    fontSize = 72.sp
                )
            }

            // Bottom Bar: Differentiated for Story Owner vs Viewers
            if (isOwner) {
                // STORY OWNER BOTTOM BAR: Viewers Count & Insights
                val viewersList by viewersFlow.collectAsState(initial = emptyList())
                val reactionsList by reactionsFlow.collectAsState(initial = emptyList())

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .padding(horizontal = 16.dp, vertical = 20.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .clickable { showViewersSheet = true }
                        .testTag("story_viewers_bar"),
                    color = Color.Black.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Visibility,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${viewersList.size} ${appString("জন দেখেছেন", "views")}",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )

                        Spacer(modifier = Modifier.width(16.dp))

                        // Show quick reactions count if any
                        if (reactionsList.isNotEmpty()) {
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                reactionsList.take(3).forEach { r ->
                                    Text(r.reactionEmoji, fontSize = 16.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.weight(1f))

                        Text(
                            text = appString("দর্শক তালিকা দেখুন ▲", "View Viewers ▲"),
                            color = VidBookBlue,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            } else {
                // VIEWER BOTTOM BAR: Quick Emoji Reactions & Reply Input
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .padding(horizontal = 16.dp, vertical = 20.dp)
                ) {
                    // Quick Emoji Reactions Tray
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf("❤️", "😂", "😮", "😢", "👏", "🔥").forEach { emoji ->
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.2f))
                                    .clickable {
                                        floatingReactionEmoji = emoji
                                        onReaction(emoji)
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = emoji, fontSize = 22.sp)
                            }
                        }
                    }

                    // Reply Text Field
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = replyText,
                            onValueChange = { replyText = it },
                            placeholder = { Text(appString("রিপ্লাই দিন…", "Reply…"), color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp),
                            shape = RoundedCornerShape(26.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color.White,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.4f),
                                cursorColor = VidBookRed
                            ),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                if (replyText.isNotBlank()) {
                                    onReply(replyText)
                                    replyText = ""
                                }
                            },
                            modifier = Modifier
                                .size(46.dp)
                                .background(VidBookBlue, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = appString("পাঠান", "Send"),
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    // Story Viewers Insights Bottom Sheet for Owner
    if (showViewersSheet && isOwner) {
        val viewersList by viewersFlow.collectAsState(initial = emptyList())
        val reactionsList by reactionsFlow.collectAsState(initial = emptyList())
        val repliesList by repliesFlow.collectAsState(initial = emptyList())

        StoryViewersBottomSheet(
            viewers = viewersList,
            reactions = reactionsList,
            replies = repliesList,
            onDismiss = { showViewersSheet = false }
        )
    }
}

// -------------------------------------------------------------
// STORY VIEWERS BOTTOM SHEET (FOR OWNER)
// -------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoryViewersBottomSheet(
    viewers: List<StoryViewer>,
    reactions: List<StoryReaction>,
    replies: List<StoryReply>,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState()
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Viewers, 1: Reactions, 2: Replies

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp)
        ) {
            Text(
                text = appString("স্টোরির ইনসাইটস ও দর্শক", "Story Insights & Viewers"),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )

            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("${appString("দর্শক", "Viewers")} (${viewers.size})") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("${appString("রিঅ্যাকশন", "Reactions")} (${reactions.size})") }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("${appString("রিপ্লাই", "Replies")} (${replies.size})") }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            when (selectedTab) {
                0 -> {
                    if (viewers.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = appString("এখনও কেউ স্টোরি দেখেনি", "No viewers yet"),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        LazyColumn(modifier = Modifier.height(280.dp)) {
                            items(viewers) { viewer ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AsyncImage(
                                        model = viewer.viewerAvatar,
                                        contentDescription = null,
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape),
                                        contentScale = ContentScale.Crop
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = viewer.viewerName,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = appString("দেখেছেন", "Seen"),
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }

                1 -> {
                    if (reactions.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = appString("কোনো রিঅ্যাকশন আসেনি", "No reactions yet"),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        LazyColumn(modifier = Modifier.height(280.dp)) {
                            items(reactions) { reaction ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AsyncImage(
                                        model = reaction.userAvatar,
                                        contentDescription = null,
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape),
                                        contentScale = ContentScale.Crop
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = reaction.userName,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = reaction.reactionEmoji,
                                        fontSize = 22.sp
                                    )
                                }
                            }
                        }
                    }
                }

                2 -> {
                    if (replies.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = appString("কোনো মেসেজ রিপ্লাই আসেনি", "No replies yet"),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        LazyColumn(modifier = Modifier.height(280.dp)) {
                            items(replies) { reply ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AsyncImage(
                                        model = reply.userAvatar,
                                        contentDescription = null,
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape),
                                        contentScale = ContentScale.Crop
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(reply.userName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(reply.replyText, fontSize = 14.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
