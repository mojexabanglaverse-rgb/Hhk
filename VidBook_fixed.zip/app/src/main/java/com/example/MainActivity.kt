package com.example

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.VidBookApp
import com.example.ui.VidBookViewModel
import com.example.ui.theme.VidBookTheme
import com.firebase.ui.auth.AuthUI
import com.firebase.ui.auth.FirebaseAuthUIActivityResultContract
import com.google.firebase.auth.FirebaseAuth

class MainActivity : ComponentActivity() {

    private lateinit var signInLauncher: ActivityResultLauncher<Intent>
    private var activeViewModel: VidBookViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        signInLauncher = registerForActivityResult(
            FirebaseAuthUIActivityResultContract()
        ) { result ->
            try {
                if (result.resultCode == RESULT_OK) {
                    val user = FirebaseAuth.getInstance().currentUser
                    if (user != null) {
                        activeViewModel?.onGoogleSignInSuccess(user)
                    }
                }
            } catch (e: Exception) {
                Log.e("MainActivity", "Sign in result error", e)
            }
        }

        setContent {
            val viewModel: VidBookViewModel = viewModel(
                factory = VidBookViewModel.factory(applicationContext)
            )
            activeViewModel = viewModel
            val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()

            VidBookTheme(darkTheme = isDarkMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    VidBookApp(
                        viewModel = viewModel,
                        onGoogleSignIn = { launchGoogleSignIn() }
                    )
                }
            }
        }
    }

    private fun launchGoogleSignIn() {
        try {
            val providers = listOf(
                AuthUI.IdpConfig.GoogleBuilder().build()
            )
            val intent = AuthUI.getInstance()
                .createSignInIntentBuilder()
                .setAvailableProviders(providers)
                .setTheme(com.firebase.ui.auth.R.style.FirebaseUI)
                .build()
            signInLauncher.launch(intent)
        } catch (e: Exception) {
            Log.e("MainActivity", "Google Sign In failed", e)
        }
    }
}
