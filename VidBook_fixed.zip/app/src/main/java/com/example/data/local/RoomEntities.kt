package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "posts",
    indices = [Index("authorId"), Index("timestamp")]
)
data class PostEntity(
    @PrimaryKey val id: String,
    val authorId: String,
    val authorName: String,
    val authorAvatar: String,
    val isAuthorVerified: Boolean,
    val timeAgo: String,
    val content: String,
    val imageUrl: String?,
    val videoUrl: String?,
    val likesCount: Int,
    val commentsCount: Int,
    val sharesCount: Int,
    val isLiked: Boolean,
    val isSaved: Boolean,
    val timestamp: Long
)

@Entity(
    tableName = "videos",
    indices = [
        Index("channelId"),
        Index("isShort"),
        Index("category"),
        Index("timestamp")
    ]
)
data class VideoEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val videoUrl: String,
    val thumbnailUrl: String,
    val channelId: String,
    val channelName: String,
    val channelAvatar: String,
    val isChannelVerified: Boolean,
    val viewsCount: Long,
    val timeAgo: String,
    val duration: String,
    val category: String,
    val likesCount: Int,
    val isLiked: Boolean,
    val isSubscribed: Boolean,
    val isShort: Boolean,
    val copyrightStatus: String = "CLEAR",
    val contentSha256: String = "",
    val timestamp: Long,
    val videoType: String = if (isShort) "SHORT" else "LONG",
    val durationMs: Long = 0L,
    val classificationMode: String = "AUTO",
    val classificationReason: String = "DURATION",
    val classificationVersion: String = "v1"
)

@Entity(
    tableName = "stories",
    indices = [
        Index("userId"),
        Index("status"),
        Index("expiresAt")
    ]
)
data class StoryEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val userName: String = "",
    val userAvatar: String = "",
    val mediaUrl: String,
    val thumbnailUrl: String = "",
    val storyType: String = "IMAGE", // IMAGE, VIDEO, TEXT
    val caption: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = createdAt + 24 * 60 * 60 * 1000L,
    val viewCount: Int = 0,
    val isViewed: Boolean = false,
    val visibility: String = "PUBLIC", // PUBLIC, FOLLOWERS, FRIENDS, CUSTOM, ONLY_ME, CLOSE_FRIENDS
    val status: String = "ACTIVE", // ACTIVE, EXPIRED, DELETED, ARCHIVED
    val isVideo: Boolean = false,
    val timeAgo: String = "এখনই",
    val isSeen: Boolean = false,
    val timestamp: Long = createdAt
)

@Entity(
    tableName = "story_viewers",
    primaryKeys = ["storyId", "viewerId"],
    indices = [Index("storyId"), Index("viewerId")]
)
data class StoryViewerEntity(
    val storyId: String,
    val viewerId: String,
    val viewerName: String,
    val viewerAvatar: String,
    val viewedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "story_reactions",
    primaryKeys = ["storyId", "userId"],
    indices = [Index("storyId"), Index("userId")]
)
data class StoryReactionEntity(
    val storyId: String,
    val userId: String,
    val userName: String,
    val userAvatar: String,
    val reactionEmoji: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "story_replies",
    indices = [Index("storyId"), Index("userId")]
)
data class StoryReplyEntity(
    @PrimaryKey val id: String,
    val storyId: String,
    val userId: String,
    val userName: String,
    val userAvatar: String,
    val replyText: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "story_highlights",
    indices = [Index("userId")]
)
data class StoryHighlightEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val title: String,
    val coverUrl: String,
    val storyIdsJson: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "story_privacy",
    primaryKeys = ["userId"]
)
data class StoryPrivacyEntity(
    val userId: String,
    val defaultVisibility: String = "PUBLIC",
    val isArchiveEnabled: Boolean = true,
    val allowReplies: Boolean = true,
    val allowReactions: Boolean = true,
    val allowSharing: Boolean = true,
    val closeFriendsIdsJson: String = "[]",
    val hideStoryFromIdsJson: String = "[]"
)

@Entity(
    tableName = "video_classifications",
    indices = [Index("videoId")]
)
data class VideoClassificationEntity(
    @PrimaryKey val videoId: String,
    val videoType: String,
    val durationMs: Long,
    val classificationMode: String,
    val classificationReason: String,
    val classificationVersion: String = "v1",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_settings")
data class UserSettingsEntity(
    @PrimaryKey val userId: String,
    val autoplay: Boolean = true,
    val wifiOnlyUpload: Boolean = false,
    val uploadOverMobileData: Boolean = true,
    val defaultVideoQuality: String = "AUTO",
    val defaultUploadType: String = "AUTO",
    val autoDetectShortLong: Boolean = true,
    val isStoryArchiveEnabled: Boolean = true,
    val allowStoryReplies: Boolean = true,
    val profileVisibility: String = "EVERYONE",
    val whoCanFollowMe: String = "EVERYONE",
    val whoCanMessageMe: String = "EVERYONE",
    val whoCanComment: String = "EVERYONE",
    val activityStatus: Boolean = true,
    val highContrast: Boolean = false,
    val reduceMotion: Boolean = false,
    val textSizeScale: Float = 1.0f,
    val downloadQuality: String = "HD",
    val autoDownload: Boolean = false,
    val cacheSizeBytes: Long = 0L,
    val searchHistoryJson: String = "[]",
    val watchHistoryJson: String = "[]",
    val notificationsJson: String = "{}"
)

@Entity(
    tableName = "comments",
    indices = [Index("targetId")]
)
data class CommentEntity(
    @PrimaryKey val id: String,
    val targetId: String,
    val authorName: String,
    val authorAvatar: String,
    val text: String,
    val timeAgo: String,
    val likesCount: Int,
    val isLiked: Boolean,
    val timestamp: Long
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val typeString: String,
    val title: String,
    val message: String,
    val avatarUrl: String,
    val timeAgo: String,
    val isRead: Boolean,
    val targetId: String?,
    val timestamp: Long
)
