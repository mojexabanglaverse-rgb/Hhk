package com.example.data.repository

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Log
import com.google.firebase.auth.FirebaseUser
import com.example.data.local.CommentEntity
import com.example.data.local.NotificationEntity
import com.example.data.local.PostEntity
import com.example.data.local.StoryEntity
import com.example.data.local.StoryHighlightEntity
import com.example.data.local.StoryPrivacyEntity
import com.example.data.local.StoryReactionEntity
import com.example.data.local.StoryReplyEntity
import com.example.data.local.StoryViewerEntity
import com.example.data.local.UserSettingsEntity
import com.example.data.local.VideoClassificationEntity
import com.example.data.local.VidBookDatabase
import com.example.data.local.VideoEntity
import com.example.data.model.Comment
import com.example.data.model.NotificationItem
import com.example.data.model.NotificationType
import com.example.data.model.Post
import com.example.data.model.Story
import com.example.data.model.UserProfile
import com.example.data.model.Video
import com.example.data.remote.CloudinaryService
import com.example.data.remote.FirebaseAuthManager
import com.example.data.remote.FirebaseFirestoreManager
import com.example.data.remote.StreamVaultClient
import com.example.copyright.data.CopyrightDao
import com.example.copyright.data.CopyrightModerationActionEntity
import com.example.copyright.data.CopyrightReferenceEntity
import com.example.copyright.engine.CopyrightScanEngine
import com.example.copyright.fingerprint.AudioFingerprintExtractor
import com.example.copyright.fingerprint.PerceptualVideoHasher
import com.example.copyright.fingerprint.Sha256Hasher
import com.example.copyright.model.CopyrightScanEvidence
import com.example.copyright.model.CopyrightNotice
import com.example.copyright.model.CopyrightNoticeStatus
import com.example.copyright.model.UserCopyrightStatus
import com.example.data.model.CreatorLevel
import com.example.data.model.CreatorMonetizationState
import com.example.data.model.AppLanguage
import com.example.data.model.BlockedUser
import com.example.data.model.FollowPermission
import com.example.data.model.NotificationPreferences
import com.example.data.model.PostVisibility
import com.example.data.model.PrivacySettings
import com.example.data.model.ProfileVisibility
import java.io.File
import com.example.data.model.WithdrawalMethod
import com.example.data.model.WithdrawalRecord
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.delay
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class VidBookRepository(private val context: Context) {

    private val db = VidBookDatabase.getDatabase(context)
    private val postDao = db.postDao()
    private val videoDao = db.videoDao()
    private val storyDao = db.storyDao()
    private val storyInteractionDao = db.storyInteractionDao()
    private val videoClassificationDao = db.videoClassificationDao()
    private val userSettingsDao = db.userSettingsDao()
    private val commentDao = db.commentDao()
    private val notificationDao = db.notificationDao()
    val copyrightDao: CopyrightDao = db.copyrightDao()
    val copyrightEngine = CopyrightScanEngine(context, copyrightDao, videoDao)

    init {
        com.example.workers.StoryExpirationWorker.schedulePeriodic(context)
    }

    val authManager = FirebaseAuthManager(context)

    private val prefs = context.getSharedPreferences("vidbook_copyright_prefs", Context.MODE_PRIVATE)

    private val _userCopyrightStatus = MutableStateFlow(
        UserCopyrightStatus(
            strikeCount = prefs.getInt("strike_count", 0),
            isUploadBlocked = prefs.getBoolean("is_upload_blocked", false) && prefs.getLong("upload_blocked_until", 0L) > System.currentTimeMillis(),
            uploadBlockedUntil = prefs.getLong("upload_blocked_until", 0L),
            isMonetizationDisabled = prefs.getBoolean("is_monetization_disabled", false)
        )
    )
    val userCopyrightStatus: Flow<UserCopyrightStatus> = _userCopyrightStatus

    private val _copyrightNotices = MutableStateFlow<List<CopyrightNotice>>(emptyList())
    val copyrightNotices: Flow<List<CopyrightNotice>> = _copyrightNotices

    // Monetization System State (Level 0 to Level 3, Watch Time, Earnings & Withdrawals)
    private val _monetizationState = MutableStateFlow(
        CreatorMonetizationState(
            level = CreatorLevel.LEVEL_0,
            followersCount = 0,
            requiredFollowers = 600,
            watchTimeHours = 0.0,
            requiredWatchTimeHours = 3300.0,
            strikeCount = prefs.getInt("strike_count", 0),
            maxStrikes = 3,
            accountAgeDays = 1,
            requiredAccountDays = 30,
            isSuspended = prefs.getInt("strike_count", 0) >= 3 || prefs.getBoolean("is_monetization_disabled", false),
            totalEarnings = 0.0,
            dailyEarnings = 0.0
        )
    )
    val monetizationState: Flow<CreatorMonetizationState> = _monetizationState

    // In-memory prepend buffer to ensure newly created posts & videos appear immediately at index 0
    private val _createdPosts = MutableStateFlow<List<Post>>(emptyList())
    private val _uploadedVideos = MutableStateFlow<List<Video>>(emptyList())

    init {
        StreamVaultClient.init(context)
        loadSavedNotices()
        loadMonetizationFromPrefs()
        CoroutineScope(Dispatchers.IO).launch {
            syncFirestoreDataAndCleanSampleData()
        }
    }

    private fun loadSavedNotices() {
        val count = prefs.getInt("notice_count", 0)
        val loaded = mutableListOf<CopyrightNotice>()
        for (i in 0 until count) {
            val id = prefs.getString("notice_${i}_id", null) ?: continue
            val videoTitle = prefs.getString("notice_${i}_title", "ভিডিও") ?: "ভিডিও"
            val thumb = prefs.getString("notice_${i}_thumb", null)
            val owner = prefs.getString("notice_${i}_owner", "স্বত্বাধিকারী") ?: "স্বত্বাধিকারী"
            val matchType = prefs.getString("notice_${i}_match_type", "কপিরাইট ম্যাচ") ?: "কপিরাইট ম্যাচ"
            val strikeNum = prefs.getInt("notice_${i}_strike", 1)
            val statusStr = prefs.getString("notice_${i}_status", "ACTIVE") ?: "ACTIVE"
            val date = prefs.getString("notice_${i}_date", "আজ") ?: "আজ"
            val timestamp = prefs.getLong("notice_${i}_timestamp", System.currentTimeMillis())
            val penalty = prefs.getString("notice_${i}_penalty", "") ?: ""
            val disputeReason = prefs.getString("notice_${i}_dispute", null)

            val status = try {
                CopyrightNoticeStatus.valueOf(statusStr)
            } catch (e: Exception) {
                CopyrightNoticeStatus.ACTIVE
            }

            loaded.add(
                CopyrightNotice(
                    id = id,
                    userId = authManager.currentUserState.value?.id ?: "user_default",
                    videoTitle = videoTitle,
                    thumbnailUrl = thumb,
                    copyrightOwner = owner,
                    matchType = matchType,
                    strikeNumber = strikeNum,
                    status = status,
                    date = date,
                    timestamp = timestamp,
                    penaltyDescription = penalty,
                    disputeReason = disputeReason
                )
            )
        }
        _copyrightNotices.value = loaded
    }

    private fun saveNoticesToPrefs(list: List<CopyrightNotice>) {
        val editor = prefs.edit()
        editor.putInt("notice_count", list.size)
        list.forEachIndexed { i, notice ->
            editor.putString("notice_${i}_id", notice.id)
            editor.putString("notice_${i}_title", notice.videoTitle)
            editor.putString("notice_${i}_thumb", notice.thumbnailUrl)
            editor.putString("notice_${i}_owner", notice.copyrightOwner)
            editor.putString("notice_${i}_match_type", notice.matchType)
            editor.putInt("notice_${i}_strike", notice.strikeNumber)
            editor.putString("notice_${i}_status", notice.status.name)
            editor.putString("notice_${i}_date", notice.date)
            editor.putLong("notice_${i}_timestamp", notice.timestamp)
            editor.putString("notice_${i}_penalty", notice.penaltyDescription)
            editor.putString("notice_${i}_dispute", notice.disputeReason)
        }
        editor.apply()
    }

    private fun calculateLevel(followers: Int, watchTime: Double, strikes: Int, accountAgeDays: Int, isSuspended: Boolean): CreatorLevel {
        if (isSuspended || strikes >= 3) return CreatorLevel.LEVEL_0
        return when {
            followers >= 600 && watchTime >= 3300.0 && strikes == 0 && accountAgeDays >= 30 -> CreatorLevel.LEVEL_3
            followers >= 300 && watchTime >= 1500.0 -> CreatorLevel.LEVEL_2
            followers >= 100 && watchTime >= 500.0 -> CreatorLevel.LEVEL_1
            else -> CreatorLevel.LEVEL_0
        }
    }

    private fun loadMonetizationFromPrefs() {
        val savedEarnings = prefs.getFloat("monetization_total_earnings", 0f)
        val savedFollowers = prefs.getInt("monetization_followers", 0)
        if ((savedEarnings > 340f && savedEarnings < 345f) || savedFollowers in listOf(450, 1420, 950, 280)) {
            prefs.edit()
                .putInt("monetization_followers", 0)
                .putFloat("monetization_watch_time", 0f)
                .putFloat("monetization_total_earnings", 0f)
                .putFloat("monetization_daily_earnings", 0f)
                .putInt("monetization_account_age", 1)
                .apply()
        }

        val followers = prefs.getInt("monetization_followers", 0)
        val watchTime = prefs.getFloat("monetization_watch_time", 0f).toDouble()
        val strikes = prefs.getInt("strike_count", 0)
        val accountAge = prefs.getInt("monetization_account_age", 1)
        val isSuspended = strikes >= 3 || prefs.getBoolean("is_monetization_disabled", false)
        val totalEarnings = prefs.getFloat("monetization_total_earnings", 0f).toDouble()
        val dailyEarnings = prefs.getFloat("monetization_daily_earnings", 0f).toDouble()
        val lastWdMonth = prefs.getString("monetization_last_wd_month", null)

        val historyCount = prefs.getInt("wd_history_count", 0)
        val history = mutableListOf<WithdrawalRecord>()
        for (i in 0 until historyCount) {
            val id = prefs.getString("wd_${i}_id", null) ?: continue
            val methodId = prefs.getString("wd_${i}_method_id", "btc") ?: "btc"
            val methodName = prefs.getString("wd_${i}_method_name", "Bitcoin (BTC)") ?: "Bitcoin (BTC)"
            val amount = prefs.getFloat("wd_${i}_amount", 0f).toDouble()
            val destination = prefs.getString("wd_${i}_dest", "") ?: ""
            val status = prefs.getString("wd_${i}_status", "Processing (৩-৭ কার্যদিবস)") ?: "Processing (৩-৭ কার্যদিবস)"
            val timestamp = prefs.getLong("wd_${i}_timestamp", System.currentTimeMillis())
            val dateFormatted = prefs.getString("wd_${i}_date", "আজ") ?: "আজ"
            history.add(
                WithdrawalRecord(
                    id = id,
                    methodId = methodId,
                    methodName = methodName,
                    amount = amount,
                    destination = destination,
                    status = status,
                    timestamp = timestamp,
                    dateFormatted = dateFormatted
                )
            )
        }

        val level = calculateLevel(followers, watchTime, strikes, accountAge, isSuspended)
        _monetizationState.value = CreatorMonetizationState(
            level = level,
            followersCount = followers,
            requiredFollowers = 600,
            watchTimeHours = watchTime,
            requiredWatchTimeHours = 3300.0,
            strikeCount = strikes,
            maxStrikes = 3,
            accountAgeDays = accountAge,
            requiredAccountDays = 30,
            isSuspended = isSuspended,
            totalEarnings = totalEarnings,
            dailyEarnings = dailyEarnings,
            withdrawalHistory = history,
            lastWithdrawalMonthYear = lastWdMonth
        )
    }

    private fun saveMonetizationToPrefs(state: CreatorMonetizationState) {
        val editor = prefs.edit()
        editor.putInt("monetization_followers", state.followersCount)
        editor.putFloat("monetization_watch_time", state.watchTimeHours.toFloat())
        editor.putInt("monetization_account_age", state.accountAgeDays)
        editor.putFloat("monetization_total_earnings", state.totalEarnings.toFloat())
        editor.putFloat("monetization_daily_earnings", state.dailyEarnings.toFloat())
        editor.putString("monetization_last_wd_month", state.lastWithdrawalMonthYear)

        editor.putInt("wd_history_count", state.withdrawalHistory.size)
        state.withdrawalHistory.forEachIndexed { i, record ->
            editor.putString("wd_${i}_id", record.id)
            editor.putString("wd_${i}_method_id", record.methodId)
            editor.putString("wd_${i}_method_name", record.methodName)
            editor.putFloat("wd_${i}_amount", record.amount.toFloat())
            editor.putString("wd_${i}_dest", record.destination)
            editor.putString("wd_${i}_status", record.status)
            editor.putLong("wd_${i}_timestamp", record.timestamp)
            editor.putString("wd_${i}_date", record.dateFormatted)
        }
        editor.apply()
    }

    fun isUserUploadBlocked(): Pair<Boolean, String?> {
        val status = _userCopyrightStatus.value
        val now = System.currentTimeMillis()
        if (status.isUploadBlocked && status.uploadBlockedUntil > now) {
            val remainingDays = ((status.uploadBlockedUntil - now) / (24 * 3600 * 1000L)).coerceAtLeast(1)
            return Pair(true, "আপনার অ্যাকাউন্টে ২য় কপিরাইট স্ট্রাইকের কারণে ভিডিও আপলোড সুবিধা আরও $remainingDays দিনের জন্য স্থগিত রয়েছে।")
        }
        return Pair(false, null)
    }

    suspend fun recordCopyrightStrike(
        evidence: CopyrightScanEvidence,
        videoTitle: String,
        videoUri: String? = null,
        thumbnailUrl: String? = null
    ): UserCopyrightStatus {
        val current = _userCopyrightStatus.value
        val newStrikeCount = (current.strikeCount + 1).coerceAtMost(3)
        val currentUserId = authManager.currentUserState.value?.id ?: ""

        val isUploadBlocked = newStrikeCount >= 2
        val uploadBlockedUntil = if (newStrikeCount >= 2) {
            System.currentTimeMillis() + 30L * 24 * 3600 * 1000L
        } else {
            0L
        }
        val isMonetizationDisabled = newStrikeCount >= 3 || current.isMonetizationDisabled

        val newStatus = UserCopyrightStatus(
            strikeCount = newStrikeCount,
            isUploadBlocked = isUploadBlocked,
            uploadBlockedUntil = uploadBlockedUntil,
            isMonetizationDisabled = isMonetizationDisabled,
            lastUpdated = System.currentTimeMillis()
        )

        // Save status locally
        prefs.edit()
            .putInt("strike_count", newStrikeCount)
            .putBoolean("is_upload_blocked", isUploadBlocked)
            .putLong("upload_blocked_until", uploadBlockedUntil)
            .putBoolean("is_monetization_disabled", isMonetizationDisabled)
            .apply()
        _userCopyrightStatus.value = newStatus

        // Format date in Bengali style
        val dateFormat = SimpleDateFormat("dd MMM, yyyy", Locale("bn", "BD"))
        val dateString = try { dateFormat.format(Date()) } catch (e: Exception) { "আজ" }

        val matchTypeDisplay = when {
            evidence.exactSha256Match -> "SHA-256 হুবহু ডুপ্লিকেট"
            evidence.matchType == "PERCEPTUAL_VIDEO" -> "Visual Fingerprint (ভিজ্যুয়াল ফ্রেম মিল)"
            evidence.matchType == "AUDIO_ONLY" -> "Audio Fingerprint (অডিও মিল)"
            else -> "Visual ও Audio Fingerprint মাল্টি-মডাল মিল"
        }

        val penaltyDescription = when (newStrikeCount) {
            1 -> "১ম স্ট্রাইক: সতর্কবার্তা প্রদান করা হয়েছে।"
            2 -> "২য় স্ট্রাইক: ভিডিও ও রিলস আপলোড সুবিধা স্থগিত করা হয়েছে।"
            else -> "আপনার অ্যাকাউন্টে ৩টি কপিরাইট স্ট্রাইক আছে। আপনি আর ইনকাম করতে পারবেন না।"
        }

        val noticeId = "notice_${System.currentTimeMillis()}"
        val copyrightOwner = evidence.matchedReferenceTitle ?: "অরিজিনাল স্বত্বাধিকারী (VidBook Registry)"

        val notice = CopyrightNotice(
            id = noticeId,
            userId = currentUserId,
            videoTitle = videoTitle,
            videoUri = videoUri,
            thumbnailUrl = thumbnailUrl,
            copyrightOwner = copyrightOwner,
            matchType = matchTypeDisplay,
            strikeNumber = newStrikeCount,
            status = CopyrightNoticeStatus.ACTIVE,
            date = dateString,
            timestamp = System.currentTimeMillis(),
            penaltyDescription = penaltyDescription
        )

        val updatedNotices = listOf(notice) + _copyrightNotices.value
        _copyrightNotices.value = updatedNotices
        saveNoticesToPrefs(updatedNotices)

        // Firebase Firestore persistence
        CoroutineScope(Dispatchers.IO).launch {
            FirebaseFirestoreManager.saveUserCopyrightStatus(
                userId = currentUserId,
                strikeCount = newStrikeCount,
                isUploadBlocked = isUploadBlocked,
                uploadBlockedUntil = uploadBlockedUntil,
                isMonetizationDisabled = isMonetizationDisabled
            )

            FirebaseFirestoreManager.saveCopyrightNotice(
                userId = currentUserId,
                noticeId = noticeId,
                videoTitle = videoTitle,
                thumbnailUrl = thumbnailUrl,
                copyrightOwner = copyrightOwner,
                matchType = matchTypeDisplay,
                strikeNumber = newStrikeCount,
                status = "ACTIVE",
                date = dateString,
                timestamp = System.currentTimeMillis(),
                penaltyDescription = penaltyDescription
            )
        }

        // 4. ৩ Strike হলে: Monetization SUSPENDED, Level 0 তে নামবে, লাল রঙে দেখাবে
        if (newStrikeCount >= 3) {
            val currMonetization = _monetizationState.value
            val suspendedMonetization = currMonetization.copy(
                strikeCount = newStrikeCount,
                isSuspended = true,
                level = CreatorLevel.LEVEL_0
            )
            _monetizationState.value = suspendedMonetization
            saveMonetizationToPrefs(suspendedMonetization)
            CoroutineScope(Dispatchers.IO).launch {
                FirebaseFirestoreManager.saveMonetizationState(
                    userId = currentUserId,
                    level = 0,
                    watchTimeMinutes = (suspendedMonetization.watchTimeHours * 60).toLong(),
                    followersCount = suspendedMonetization.followersCount,
                    strikeCount = newStrikeCount,
                    monetizationStatus = "SUSPENDED",
                    totalEarnings = suspendedMonetization.totalEarnings,
                    dailyEarnings = suspendedMonetization.dailyEarnings,
                    isSuspended = true
                )
            }
        }

        return newStatus
    }

    suspend fun requestWithdrawal(
        method: WithdrawalMethod,
        amount: Double,
        destination: String
    ): Pair<Boolean, String> {
        val current = _monetizationState.value
        val currentUserId = authManager.currentUserState.value?.id ?: ""

        if (current.isSuspended || current.level != CreatorLevel.LEVEL_3) {
            return Pair(false, "উত্তোলন সুবিধা শুধুমাত্র সক্রিয় Level 3 ক্রিয়েটরদের জন্য প্রযোজ্য।")
        }
        if (amount < method.minAmount) {
            return Pair(false, "মিনিমাম $${method.minAmount.toInt()} প্রয়োজন।")
        }
        if (amount > current.totalEarnings) {
            return Pair(false, "আপনার অ্যাকাউন্টে পর্যাপ্ত ব্যালেন্স নেই।")
        }

        val monthFormat = SimpleDateFormat("yyyy-MM", Locale.US)
        val currentMonth = monthFormat.format(Date())
        if (current.lastWithdrawalMonthYear == currentMonth) {
            return Pair(false, "প্রতি মাসে একবারই Withdrawal করা যাবে। আগামী মাসে আবার চেষ্টা করুন।")
        }

        val dateFormat = SimpleDateFormat("dd MMM, yyyy", Locale("bn", "BD"))
        val dateStr = try { dateFormat.format(Date()) } catch (e: Exception) { "আজ" }
        val recordId = "wd_${System.currentTimeMillis()}"

        val record = WithdrawalRecord(
            id = recordId,
            methodId = method.id,
            methodName = method.displayName,
            amount = amount,
            destination = destination,
            status = "Processing (৩-৭ কার্যদিবস)",
            timestamp = System.currentTimeMillis(),
            dateFormatted = dateStr
        )

        val updatedBalance = (current.totalEarnings - amount).coerceAtLeast(0.0)
        val updatedHistory = listOf(record) + current.withdrawalHistory
        val newState = current.copy(
            totalEarnings = updatedBalance,
            withdrawalHistory = updatedHistory,
            lastWithdrawalMonthYear = currentMonth
        )
        _monetizationState.value = newState
        saveMonetizationToPrefs(newState)

        CoroutineScope(Dispatchers.IO).launch {
            FirebaseFirestoreManager.recordWithdrawalInFirestore(
                userId = currentUserId,
                withdrawalId = recordId,
                method = method.displayName,
                amount = amount,
                destination = destination,
                status = record.status,
                dateFormatted = dateStr
            )
            FirebaseFirestoreManager.saveMonetizationState(
                userId = currentUserId,
                level = newState.level.levelNumber,
                watchTimeMinutes = (newState.watchTimeHours * 60).toLong(),
                followersCount = newState.followersCount,
                strikeCount = newState.strikeCount,
                monetizationStatus = if (newState.isSuspended) "SUSPENDED" else "ACTIVE",
                totalEarnings = newState.totalEarnings,
                dailyEarnings = newState.dailyEarnings,
                isSuspended = newState.isSuspended
            )
        }

        addSystemNotification(
            title = "উত্তোলন অনুরোধ গৃহীত হয়েছে",
            message = "$${amount} ${method.displayName}-এ উইথড্র করার অনুরোধ সফলভাবে জমা হয়েছে। ৩-৭ কার্যদিবসে সম্পন্ন হবে।"
        )

        return Pair(true, "উত্তোলনের অনুরোধ সফলভাবে পাঠানো হয়েছে ($${amount} via ${method.displayName})!")
    }

    suspend fun updateMonetizationProgress(followersDelta: Int, watchTimeHoursDelta: Double) {
        val current = _monetizationState.value
        val oldLevel = current.level
        val newFollowers = (current.followersCount + followersDelta).coerceAtLeast(0)
        val newWatchTime = (current.watchTimeHours + watchTimeHoursDelta).coerceAtLeast(0.0)
        val newLevel = calculateLevel(newFollowers, newWatchTime, current.strikeCount, current.accountAgeDays, current.isSuspended)

        val newState = current.copy(
            followersCount = newFollowers,
            watchTimeHours = newWatchTime,
            level = newLevel
        )
        _monetizationState.value = newState
        saveMonetizationToPrefs(newState)

        if (newLevel.levelNumber > oldLevel.levelNumber) {
            addSystemNotification(
                title = "🎉 অভিনন্দন!",
                message = "🎉 অভিনন্দন! আপনি Level ${newLevel.levelNumber} এ উন্নীত হয়েছেন!"
            )
        }
    }

    suspend fun addSystemNotification(title: String, message: String, targetId: String? = null) {
        val notif = NotificationEntity(
            id = "notif_${System.currentTimeMillis()}",
            typeString = "SYSTEM",
            title = title,
            message = message,
            avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&q=80",
            timeAgo = "এইমাত্র",
            isRead = false,
            targetId = targetId,
            timestamp = System.currentTimeMillis()
        )
        notificationDao.insertNotification(notif)
    }

    suspend fun submitCopyrightNoticeDispute(noticeId: String, disputeReason: String) {
        val currentUserId = authManager.currentUserState.value?.id ?: ""
        val updated = _copyrightNotices.value.map { notice ->
            if (notice.id == noticeId) {
                notice.copy(
                    status = CopyrightNoticeStatus.DISPUTED,
                    disputeReason = disputeReason
                )
            } else {
                notice
            }
        }
        _copyrightNotices.value = updated
        saveNoticesToPrefs(updated)

        copyrightDao.insertModerationAction(
            CopyrightModerationActionEntity(
                id = "disp_${System.currentTimeMillis()}",
                matchId = noticeId,
                action = "DISPUTE_SUBMITTED",
                adminNotes = "নোটিশ আপিল: $disputeReason"
            )
        )

        CoroutineScope(Dispatchers.IO).launch {
            FirebaseFirestoreManager.submitDisputeInFirestore(
                userId = currentUserId,
                noticeId = noticeId,
                disputeReason = disputeReason
            )
        }
    }

    fun getStreamVaultBaseUrl(): String = StreamVaultClient.getBaseUrl()

    fun updateStreamVaultBaseUrl(newUrl: String) {
        StreamVaultClient.setBaseUrl(newUrl, context)
    }

    suspend fun createOrUpdateUserProfile(user: FirebaseUser): UserProfile? {
        val profile = authManager.onFirebaseUserSignedIn(user)
        if (profile != null) {
            try {
                FirebaseFirestoreManager.updateUserProfileInFirestore(
                    userId = profile.id,
                    name = profile.name,
                    username = profile.username,
                    bio = profile.bio,
                    avatarUrl = profile.avatarUrl,
                    coverUrl = profile.coverUrl
                )
            } catch (e: Exception) {
                Log.w("VidBookRepository", "Firestore user profile update failed", e)
            }
            syncUserData(profile.id)
        }
        return profile
    }

    suspend fun syncUserData(userId: String?) {
        val uid = userId ?: authManager.currentUserState.value?.id ?: return
        if (uid.isBlank()) return

        val remoteProfile = FirebaseFirestoreManager.fetchUserProfileFromFirestore(uid)
        if (remoteProfile != null) {
            authManager.updateFullProfile(
                name = remoteProfile.name,
                username = remoteProfile.username,
                bio = remoteProfile.bio,
                avatarUrl = remoteProfile.avatarUrl,
                coverUrl = remoteProfile.coverUrl
            )
        }

        val remoteMonetization = FirebaseFirestoreManager.fetchMonetizationFromFirestore(uid)
        if (remoteMonetization != null) {
            _monetizationState.value = remoteMonetization
            saveMonetizationToPrefs(remoteMonetization)
        }
    }

    // --- Social Posts (Facebook Style) ---
    val allPosts: Flow<List<Post>> = combine(postDao.getAllPosts(), _createdPosts) { entities, newlyCreated ->
        val models = entities.map { it.toModel() }
        val newlyIds = newlyCreated.map { it.id }.toSet()
        val remainingDb = models.filterNot { it.id in newlyIds }
        newlyCreated + remainingDb
    }

    suspend fun togglePostLike(postId: String, currentIsLiked: Boolean, currentLikes: Int) {
        val newIsLiked = !currentIsLiked
        val newLikesCount = if (newIsLiked) currentLikes + 1 else (currentLikes - 1).coerceAtLeast(0)
        postDao.updateLike(postId, newIsLiked, newLikesCount)
    }

    suspend fun createPost(content: String, rawImageUri: String? = null) {
        val currentUser = authManager.currentUserState.value
        val authorName = currentUser?.name?.takeIf { it.isNotBlank() } ?: "ব্যবহারকারী"
        val authorAvatar = currentUser?.avatarUrl ?: ""
        val authorId = currentUser?.id ?: "user_anonymous"

        var uploadedImageUrl: String? = null
        if (!rawImageUri.isNullOrBlank()) {
            val result = CloudinaryService.uploadImage(rawImageUri, folder = "posts")
            uploadedImageUrl = result.getOrNull() ?: rawImageUri
        }

        val newPost = PostEntity(
            id = "post_${System.currentTimeMillis()}",
            authorId = authorId,
            authorName = authorName,
            authorAvatar = authorAvatar,
            isAuthorVerified = currentUser?.isVerified ?: false,
            timeAgo = "এইমাত্র",
            content = content,
            imageUrl = uploadedImageUrl,
            videoUrl = null,
            likesCount = 0,
            commentsCount = 0,
            sharesCount = 0,
            isLiked = false,
            isSaved = false,
            timestamp = System.currentTimeMillis()
        )
        // Add new post to the front of the list so it displays at the very top immediately
        _createdPosts.value = listOf(newPost.toModel()) + _createdPosts.value
        postDao.insertPost(newPost)

        CoroutineScope(Dispatchers.IO).launch {
            FirebaseFirestoreManager.savePostToFirestore(newPost)
        }
    }

    // --- Stories (Facebook Style 24-hour Expiration & Social Features) ---
    private val storyClock: Flow<Long> = flow {
        while (currentCoroutineContext().isActive) {
            emit(System.currentTimeMillis())
            delay(30_000L)
        }
    }

    val activeStories: Flow<List<Story>> = combine(storyDao.getActiveStories(), storyClock) { entities, now ->
        entities.filter { it.expiresAt > now && it.status == "ACTIVE" }
    }.map { entities ->
        entities.map { it.toModel() }
    }

    suspend fun cleanupExpiredStories() {
        val now = System.currentTimeMillis()
        val expired = storyDao.getExpiredStories(now)
        for (story in expired) {
            val privacy = storyInteractionDao.getStoryPrivacy(story.userId)
            val settings = userSettingsDao.getUserSettings(story.userId)
            val isArchiveEnabled = privacy?.isArchiveEnabled ?: settings?.isStoryArchiveEnabled ?: true
            if (isArchiveEnabled) {
                storyDao.updateStoryStatus(story.id, "EXPIRED")
            } else {
                storyDao.deleteStory(story.id)
            }
        }
    }

    suspend fun addStory(
        mediaUrl: String,
        caption: String,
        storyType: com.example.data.model.StoryType = com.example.data.model.StoryType.IMAGE,
        visibility: com.example.data.model.StoryVisibility = com.example.data.model.StoryVisibility.PUBLIC,
        thumbnailUrl: String = ""
    ): Story {
        val currentUser = authManager.currentUserState.value
        val userName = currentUser?.name?.takeIf { it.isNotBlank() } ?: "আপনার স্টোরি"
        val userAvatar = currentUser?.avatarUrl ?: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80"
        val userId = currentUser?.id ?: "user_${System.currentTimeMillis()}"

        val now = System.currentTimeMillis()
        val expires = now + 24 * 60 * 60 * 1000L

        val newStory = StoryEntity(
            id = "story_${System.currentTimeMillis()}",
            userId = userId,
            userName = userName,
            userAvatar = userAvatar,
            mediaUrl = mediaUrl,
            thumbnailUrl = thumbnailUrl,
            storyType = storyType.name,
            caption = caption,
            createdAt = now,
            expiresAt = expires,
            viewCount = 0,
            isViewed = false,
            visibility = visibility.name,
            status = "ACTIVE",
            isVideo = (storyType == com.example.data.model.StoryType.VIDEO),
            timeAgo = "এইমাত্র",
            isSeen = false,
            timestamp = now
        )
        storyDao.insertStory(newStory)
        return newStory.toModel()
    }

    suspend fun markStorySeen(storyId: String) {
        storyDao.markSeen(storyId)
        val currentUser = authManager.currentUserState.value ?: return
        val viewer = StoryViewerEntity(
            storyId = storyId,
            viewerId = currentUser.id,
            viewerName = currentUser.name.ifBlank { "ব্যবহারকারী" },
            viewerAvatar = currentUser.avatarUrl,
            viewedAt = System.currentTimeMillis()
        )
        storyInteractionDao.insertViewer(viewer)
    }

    fun getStoryViewers(storyId: String): Flow<List<com.example.data.model.StoryViewer>> =
        storyInteractionDao.getViewers(storyId).map { list ->
            list.map { com.example.data.model.StoryViewer(it.storyId, it.viewerId, it.viewerName, it.viewerAvatar, it.viewedAt) }
        }

    suspend fun addStoryReaction(storyId: String, emoji: String) {
        val currentUser = authManager.currentUserState.value ?: return
        val reaction = StoryReactionEntity(
            storyId = storyId,
            userId = currentUser.id,
            userName = currentUser.name.ifBlank { "ব্যবহারকারী" },
            userAvatar = currentUser.avatarUrl,
            reactionEmoji = emoji,
            timestamp = System.currentTimeMillis()
        )
        storyInteractionDao.insertReaction(reaction)
    }

    fun getStoryReactions(storyId: String): Flow<List<com.example.data.model.StoryReaction>> =
        storyInteractionDao.getReactions(storyId).map { list ->
            list.map { com.example.data.model.StoryReaction(it.storyId, it.userId, it.userName, it.userAvatar, it.reactionEmoji, it.timestamp) }
        }

    suspend fun sendStoryReply(storyId: String, replyText: String) {
        val currentUser = authManager.currentUserState.value ?: return
        val reply = StoryReplyEntity(
            id = "reply_${System.currentTimeMillis()}",
            storyId = storyId,
            userId = currentUser.id,
            userName = currentUser.name.ifBlank { "ব্যবহারকারী" },
            userAvatar = currentUser.avatarUrl,
            replyText = replyText,
            timestamp = System.currentTimeMillis()
        )
        storyInteractionDao.insertReply(reply)
    }

    fun getStoryReplies(storyId: String): Flow<List<com.example.data.model.StoryReply>> =
        storyInteractionDao.getReplies(storyId).map { list ->
            list.map { com.example.data.model.StoryReply(it.id, it.storyId, it.userId, it.userName, it.userAvatar, it.replyText, it.timestamp) }
        }

    fun getArchivedStories(userId: String): Flow<List<Story>> =
        storyDao.getArchivedStories(userId).map { list -> list.map { it.toModel() } }

    fun getAllStoriesForUser(userId: String): Flow<List<Story>> =
        storyDao.getAllStoriesForUser(userId).map { list -> list.map { it.toModel() } }

    suspend fun deleteStory(storyId: String) {
        storyDao.deleteStory(storyId)
    }

    suspend fun deleteArchivedStory(storyId: String) {
        storyDao.deleteStory(storyId)
    }

    suspend fun reshareArchivedStory(storyId: String): Story? {
        val existing = storyDao.getStoryById(storyId) ?: return null
        return addStory(
            mediaUrl = existing.mediaUrl,
            caption = existing.caption,
            storyType = try { com.example.data.model.StoryType.valueOf(existing.storyType) } catch (_: Exception) { com.example.data.model.StoryType.IMAGE },
            visibility = try { com.example.data.model.StoryVisibility.valueOf(existing.visibility) } catch (_: Exception) { com.example.data.model.StoryVisibility.PUBLIC },
            thumbnailUrl = existing.thumbnailUrl
        )
    }

    suspend fun createHighlight(title: String, coverUrl: String, storyIds: List<String>): com.example.data.model.StoryHighlight {
        val currentUser = authManager.currentUserState.value
        val userId = currentUser?.id ?: "user_default"
        val highlight = StoryHighlightEntity(
            id = "highlight_${System.currentTimeMillis()}",
            userId = userId,
            title = title,
            coverUrl = coverUrl,
            storyIdsJson = storyIds.joinToString(","),
            createdAt = System.currentTimeMillis()
        )
        storyInteractionDao.insertHighlight(highlight)
        return com.example.data.model.StoryHighlight(highlight.id, highlight.userId, highlight.title, highlight.coverUrl, storyIds, highlight.createdAt)
    }

    fun getHighlights(userId: String): Flow<List<com.example.data.model.StoryHighlight>> =
        storyInteractionDao.getHighlights(userId).map { list ->
            list.map {
                val ids = if (it.storyIdsJson.isBlank()) emptyList() else it.storyIdsJson.split(",").filter { id -> id.isNotBlank() }
                com.example.data.model.StoryHighlight(it.id, it.userId, it.title, it.coverUrl, ids, it.createdAt)
            }
        }

    suspend fun deleteHighlight(id: String) {
        storyInteractionDao.deleteHighlight(id)
    }

    suspend fun getStoryPrivacy(userId: String): com.example.data.model.StoryPrivacySettings {
        val entity = storyInteractionDao.getStoryPrivacy(userId)
        return if (entity != null) {
            val closeFriends = if (entity.closeFriendsIdsJson.isBlank() || entity.closeFriendsIdsJson == "[]") emptyList() else entity.closeFriendsIdsJson.replace("[", "").replace("]", "").replace("\"", "").split(",").map { it.trim() }.filter { it.isNotBlank() }
            val hideFrom = if (entity.hideStoryFromIdsJson.isBlank() || entity.hideStoryFromIdsJson == "[]") emptyList() else entity.hideStoryFromIdsJson.replace("[", "").replace("]", "").replace("\"", "").split(",").map { it.trim() }.filter { it.isNotBlank() }
            com.example.data.model.StoryPrivacySettings(
                userId = entity.userId,
                defaultVisibility = try { com.example.data.model.StoryVisibility.valueOf(entity.defaultVisibility) } catch (_: Exception) { com.example.data.model.StoryVisibility.PUBLIC },
                isArchiveEnabled = entity.isArchiveEnabled,
                allowReplies = entity.allowReplies,
                allowReactions = entity.allowReactions,
                allowSharing = entity.allowSharing,
                closeFriendsIds = closeFriends,
                hideStoryFromIds = hideFrom
            )
        } else {
            com.example.data.model.StoryPrivacySettings(userId = userId)
        }
    }

    suspend fun updateStoryPrivacy(settings: com.example.data.model.StoryPrivacySettings) {
        val entity = StoryPrivacyEntity(
            userId = settings.userId,
            defaultVisibility = settings.defaultVisibility.name,
            isArchiveEnabled = settings.isArchiveEnabled,
            allowReplies = settings.allowReplies,
            allowReactions = settings.allowReactions,
            allowSharing = settings.allowSharing,
            closeFriendsIdsJson = settings.closeFriendsIds.joinToString(prefix = "[\"", separator = "\",\"", postfix = "\"]"),
            hideStoryFromIdsJson = settings.hideStoryFromIds.joinToString(prefix = "[\"", separator = "\",\"", postfix = "\"]")
        )
        storyInteractionDao.insertOrUpdateStoryPrivacy(entity)
    }

    fun getUserSettingsFlow(userId: String? = null): Flow<UserSettingsEntity> {
        val uid = userId ?: authManager.currentUserState.value?.id ?: "user_default"
        return userSettingsDao.getUserSettingsFlow(uid).map { it ?: UserSettingsEntity(userId = uid) }
    }

    suspend fun getUserSettings(userId: String? = null): UserSettingsEntity {
        val uid = userId ?: authManager.currentUserState.value?.id ?: "user_default"
        return userSettingsDao.getUserSettings(uid) ?: UserSettingsEntity(userId = uid)
    }

    suspend fun updateUserSettings(settings: UserSettingsEntity) {
        userSettingsDao.insertOrUpdateSettings(settings)
    }

    fun canUploadNow(userId: String? = null): Pair<Boolean, String?> {
        val uid = userId ?: authManager.currentUserState.value?.id ?: "default"
        val settings = kotlinx.coroutines.runBlocking { userSettingsDao.getUserSettings(uid) }
        if (settings?.wifiOnlyUpload == true) {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager
            val activeNetwork = cm?.activeNetwork
            val capabilities = cm?.getNetworkCapabilities(activeNetwork)
            val isWifi = capabilities?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) == true
            if (!isWifi) {
                return Pair(false, "Wi-Fi Only Upload চালু রয়েছে। অনুগ্রহ করে ওয়াইফাই সংযোগ ব্যবহার করুন।")
            }
        }
        return Pair(true, null)
    }

    fun detectVideoType(
        durationMs: Long,
        mode: com.example.data.model.ClassificationMode = com.example.data.model.ClassificationMode.AUTO,
        manualSelection: com.example.data.model.VideoType? = null
    ): Triple<com.example.data.model.VideoType, com.example.data.model.ClassificationMode, com.example.data.model.ClassificationReason> {
        return when (mode) {
            com.example.data.model.ClassificationMode.MANUAL -> {
                val selected = manualSelection ?: if (com.example.data.model.VideoClassificationConfig.isShortVideo(durationMs)) com.example.data.model.VideoType.SHORT else com.example.data.model.VideoType.LONG
                val reason = com.example.data.model.ClassificationReason.USER_SELECTED
                Triple(selected, com.example.data.model.ClassificationMode.MANUAL, reason)
            }
            com.example.data.model.ClassificationMode.AUTO -> {
                val detected = if (com.example.data.model.VideoClassificationConfig.isShortVideo(durationMs)) com.example.data.model.VideoType.SHORT else com.example.data.model.VideoType.LONG
                val reason = com.example.data.model.ClassificationReason.DURATION
                Triple(detected, com.example.data.model.ClassificationMode.AUTO, reason)
            }
        }
    }

    // --- Videos & Shorts (YouTube Style) ---
    val longVideos: Flow<List<Video>> = combine(videoDao.getLongVideos(), _uploadedVideos) { entities, newlyCreated ->
        val models = entities.map { it.toModel() }
        val newlyLong = newlyCreated.filterNot { it.isShort }
        val ids = newlyLong.map { it.id }.toSet()
        val remainingDb = models.filterNot { it.id in ids }
        newlyLong + remainingDb
    }

    val shorts: Flow<List<Video>> = combine(videoDao.getShorts(), _uploadedVideos) { entities, newlyCreated ->
        val models = entities.map { it.toModel() }
        val newlyShorts = newlyCreated.filter { it.isShort }
        val ids = newlyShorts.map { it.id }.toSet()
        val remainingDb = models.filterNot { it.id in ids }
        newlyShorts + remainingDb
    }

    fun getVideosByCategory(category: String): Flow<List<Video>> {
        return if (category == "সবগুলো") {
            longVideos
        } else {
            longVideos.map { list -> list.filter { it.category == category } }
        }
    }

    suspend fun getVideoById(id: String): Video? {
        return videoDao.getVideoById(id)?.toModel()
    }

    suspend fun toggleVideoLike(videoId: String, currentIsLiked: Boolean, currentLikes: Int) {
        val newIsLiked = !currentIsLiked
        val newLikesCount = if (newIsLiked) currentLikes + 1 else (currentLikes - 1).coerceAtLeast(0)
        videoDao.updateLike(videoId, newIsLiked, newLikesCount)
    }

    suspend fun toggleSubscription(channelId: String, currentIsSubscribed: Boolean) {
        videoDao.updateChannelSubscription(channelId, !currentIsSubscribed)
    }

    suspend fun incrementViews(videoId: String) {
        videoDao.incrementViews(videoId)
        // Update view count in Firebase Firestore as well
        FirebaseFirestoreManager.incrementVideoViewCount(videoId)
    }

    suspend fun toggleFollow(targetUserId: String, isCurrentlyFollowing: Boolean): Boolean {
        val newFollowState = !isCurrentlyFollowing
        val delta = if (newFollowState) 1L else -1L

        // Update in Firebase Firestore
        FirebaseFirestoreManager.updateFollowerCount(targetUserId, delta)

        // If target user is the logged in user, update local session
        if (authManager.currentUserState.value?.id == targetUserId) {
            authManager.updateFollowersCount(delta.toInt())
        }

        return newFollowState
    }

    suspend fun uploadVideo(
        title: String,
        description: String,
        category: String,
        rawVideoUri: String,
        thumbnailUri: String,
        isShort: Boolean,
        classificationMode: com.example.data.model.ClassificationMode = com.example.data.model.ClassificationMode.AUTO,
        manualVideoType: com.example.data.model.VideoType? = null
    ): Video? {
        val check = canUploadNow()
        if (!check.first) {
            throw IllegalStateException(check.second ?: "Upload blocked")
        }

        val currentUser = authManager.currentUserState.value
        val channelName = currentUser?.name?.takeIf { it.isNotBlank() } ?: "আমার চ্যানেল"
        val channelAvatar = currentUser?.avatarUrl ?: ""
        val channelId = currentUser?.id ?: "ch_user"

        // StreamVault API call
        val streamVaultResp = StreamVaultClient.uploadToStreamVault(title, category, rawVideoUri)
        val finalVideoUrl = streamVaultResp.videoUrl ?: rawVideoUri
        val finalThumbnail = if (thumbnailUri.isNotBlank()) thumbnailUri else (streamVaultResp.thumbnailUrl ?: "")

        // Extract actual video duration using MediaMetadataRetriever
        var extractedDurationMs = 0L
        val actualDurationFormatted: String = try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, Uri.parse(rawVideoUri))
            val ms = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            retriever.release()
            extractedDurationMs = ms
            if (ms > 0L) {
                val totalSeconds = ms / 1000L
                val minutes = totalSeconds / 60L
                val seconds = totalSeconds % 60L
                String.format("%02d:%02d", minutes, seconds)
            } else {
                if (isShort) "00:45" else "12:30"
            }
        } catch (e: Exception) {
            if (isShort) "00:45" else "12:30"
        }

        if (extractedDurationMs <= 0L) {
            extractedDurationMs = if (isShort) 45_000L else 750_000L
        }

        // Smart Video Classification (Part 2)
        val (finalType, modeUsed, reasonUsed) = detectVideoType(
            durationMs = extractedDurationMs,
            mode = classificationMode,
            manualSelection = manualVideoType
        )
        val isShortFinal = (finalType == com.example.data.model.VideoType.SHORT)

        // Real-time Copyright Check (SHA-256 hash, Visual fingerprint, Audio fingerprint)
        val scanEvidence = copyrightEngine.scanVideo(finalVideoUrl, title)
        if (scanEvidence.status == com.example.copyright.model.CopyrightStatus.BLOCKED) {
            recordCopyrightStrike(
                evidence = scanEvidence,
                videoTitle = title,
                videoUri = finalVideoUrl,
                thumbnailUrl = finalThumbnail
            )
            return null
        }

        val videoId = "vid_${System.currentTimeMillis()}"

        val classificationEntity = com.example.data.local.VideoClassificationEntity(
            videoId = videoId,
            videoType = finalType.name,
            durationMs = extractedDurationMs,
            classificationMode = modeUsed.name,
            classificationReason = reasonUsed.name,
            classificationVersion = "v1",
            timestamp = System.currentTimeMillis()
        )
        videoClassificationDao.insertClassification(classificationEntity)

        val newVideo = VideoEntity(
            id = videoId,
            title = title,
            description = description,
            videoUrl = finalVideoUrl,
            thumbnailUrl = finalThumbnail,
            channelId = channelId,
            channelName = channelName,
            channelAvatar = channelAvatar,
            isChannelVerified = currentUser?.isVerified ?: false,
            viewsCount = 1,
            timeAgo = "এইমাত্র",
            duration = actualDurationFormatted,
            category = if (isShortFinal && (category.isBlank() || category == "নাটক")) "শর্টস" else category,
            likesCount = 0,
            isLiked = false,
            isSubscribed = false,
            isShort = isShortFinal,
            timestamp = System.currentTimeMillis(),
            videoType = finalType.name,
            durationMs = extractedDurationMs,
            classificationMode = modeUsed.name,
            classificationReason = reasonUsed.name,
            classificationVersion = "v1"
        )
        // Add new video to the front of the list so it displays at the very top immediately
        _uploadedVideos.value = listOf(newVideo.toModel()) + _uploadedVideos.value
        videoDao.insertVideo(newVideo)

        CoroutineScope(Dispatchers.IO).launch {
            FirebaseFirestoreManager.saveVideoToFirestore(newVideo)
        }

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val sha = Sha256Hasher.computeSha256(finalVideoUrl.toByteArray())
                val frames = PerceptualVideoHasher.sampleVideoFrames(context, finalVideoUrl, 180000L, 11)
                val audio = AudioFingerprintExtractor.extractAudioFingerprint(context, finalVideoUrl, 180000L)
                val frameStr = frames.joinToString(";") { "${it.timestampMs},${it.pHashHex},${it.dHashHex}" }
                val audioStr = audio.landmarkHashes.joinToString(",")

                copyrightDao.insertReference(
                    CopyrightReferenceEntity(
                        id = "ref_user_${newVideo.id}",
                        ownerId = channelId,
                        title = title,
                        source = "VidBook Platform Upload",
                        sha256 = sha,
                        audioFingerprint = audioStr,
                        videoFingerprint = if (frames.isNotEmpty()) frames.first().pHashHex else "0000000000000000",
                        frameFingerprints = frameStr,
                        durationMs = extractedDurationMs
                    )
                )
            } catch (ignored: Exception) {}
        }
        return newVideo.toModel()
    }

    suspend fun scanCandidateVideo(
        videoUriOrPath: String,
        videoTitle: String,
        onProgress: (stage: String, progress: Float) -> Unit = { _, _ -> }
    ): CopyrightScanEvidence {
        return copyrightEngine.scanVideo(videoUriOrPath, videoTitle, onProgress = onProgress)
    }

    suspend fun submitDispute(scanEvidence: CopyrightScanEvidence, disputeReason: String) {
        val action = CopyrightModerationActionEntity(
            id = "disp_${System.currentTimeMillis()}",
            matchId = scanEvidence.matchedReferenceId ?: scanEvidence.scanId,
            action = "DISPUTE_SUBMITTED",
            adminNotes = "ব্যবহারকারীর আপিল: $disputeReason (ম্যাচ ধরণ: ${scanEvidence.decision.name})"
        )
        copyrightDao.insertModerationAction(action)
    }

    // --- Profile Editing with Cloudinary & Firebase Firestore ---
    suspend fun updateFullProfile(
        name: String,
        username: String,
        bio: String,
        rawAvatarUri: String? = null,
        rawCoverUri: String? = null
    ): UserProfile {
        var finalAvatarUrl = authManager.currentUserState.value?.avatarUrl
        var finalCoverUrl = authManager.currentUserState.value?.coverUrl

        // Upload avatar to Cloudinary if local file URI
        if (!rawAvatarUri.isNullOrBlank() && !rawAvatarUri.startsWith("http://") && !rawAvatarUri.startsWith("https://")) {
            val res = CloudinaryService.uploadImage(rawAvatarUri, folder = "avatars")
            finalAvatarUrl = res.getOrNull() ?: rawAvatarUri
        } else if (!rawAvatarUri.isNullOrBlank()) {
            finalAvatarUrl = rawAvatarUri
        }

        // Upload cover to Cloudinary if local file URI
        if (!rawCoverUri.isNullOrBlank() && !rawCoverUri.startsWith("http://") && !rawCoverUri.startsWith("https://")) {
            val res = CloudinaryService.uploadImage(rawCoverUri, folder = "covers")
            finalCoverUrl = res.getOrNull() ?: rawCoverUri
        } else if (!rawCoverUri.isNullOrBlank()) {
            finalCoverUrl = rawCoverUri
        }

        authManager.updateFullProfile(
            name = name,
            username = username,
            bio = bio,
            avatarUrl = finalAvatarUrl,
            coverUrl = finalCoverUrl
        )

        val updatedUser = authManager.currentUserState.value ?: return

        // Save to Firebase Firestore
        CoroutineScope(Dispatchers.IO).launch {
            FirebaseFirestoreManager.updateUserProfileInFirestore(
                userId = updatedUser.id,
                name = updatedUser.name,
                username = updatedUser.username,
                bio = updatedUser.bio,
                avatarUrl = updatedUser.avatarUrl,
                coverUrl = updatedUser.coverUrl
            )
        }

        return updatedUser
    }

    suspend fun updateAvatarPhoto(rawAvatarUri: String): String {
        var uploadedUrl = rawAvatarUri
        if (!rawAvatarUri.startsWith("http://") && !rawAvatarUri.startsWith("https://")) {
            val res = CloudinaryService.uploadImage(rawAvatarUri, folder = "avatars")
            uploadedUrl = res.getOrNull() ?: rawAvatarUri
        }
        val current = authManager.currentUserState.value
        if (current != null) {
            authManager.updateFullProfile(
                name = current.name,
                username = current.username,
                bio = current.bio,
                avatarUrl = uploadedUrl
            )
            CoroutineScope(Dispatchers.IO).launch {
                FirebaseFirestoreManager.updateUserProfileInFirestore(
                    userId = current.id,
                    name = current.name,
                    username = current.username,
                    bio = current.bio,
                    avatarUrl = uploadedUrl
                )
            }
        }
        return uploadedUrl
    }

    suspend fun updateCoverPhoto(rawCoverUri: String): String {
        var uploadedUrl = rawCoverUri
        if (!rawCoverUri.startsWith("http://") && !rawCoverUri.startsWith("https://")) {
            val res = CloudinaryService.uploadImage(rawCoverUri, folder = "covers")
            uploadedUrl = res.getOrNull() ?: rawCoverUri
        }
        val current = authManager.currentUserState.value
        if (current != null) {
            authManager.updateFullProfile(
                name = current.name,
                username = current.username,
                bio = current.bio,
                coverUrl = uploadedUrl
            )
            CoroutineScope(Dispatchers.IO).launch {
                FirebaseFirestoreManager.updateUserProfileInFirestore(
                    userId = current.id,
                    name = current.name,
                    username = current.username,
                    bio = current.bio,
                    coverUrl = uploadedUrl
                )
            }
        }
        return uploadedUrl
    }

    // --- Comments ---
    fun getCommentsForTarget(targetId: String): Flow<List<Comment>> {
        return commentDao.getCommentsForTarget(targetId).map { entities ->
            entities.map { it.toModel() }
        }
    }

    suspend fun addComment(targetId: String, text: String) {
        val currentUser = authManager.currentUserState.value
        val authorName = currentUser?.name?.takeIf { it.isNotBlank() } ?: (if (currentUser != null) "ব্যবহারকারী" else "অতিথি")
        val authorAvatar = currentUser?.avatarUrl ?: ""

        val newComment = CommentEntity(
            id = "comment_${System.currentTimeMillis()}",
            targetId = targetId,
            authorName = authorName,
            authorAvatar = authorAvatar,
            text = text,
            timeAgo = "এইমাত্র",
            likesCount = 0,
            isLiked = false,
            timestamp = System.currentTimeMillis()
        )
        commentDao.insertComment(newComment)
    }

    // --- Notifications ---
    val allNotifications: Flow<List<NotificationItem>> = notificationDao.getAllNotifications().map { entities ->
        entities.map { it.toModel() }
    }

    suspend fun markAllNotificationsAsRead() {
        notificationDao.markAllAsRead()
    }

    suspend fun markNotificationAsRead(id: String) {
        notificationDao.markAsRead(id)
    }

    // --- Synchronization with Firebase Firestore & Cleaning Demo Data ---
    private suspend fun syncFirestoreDataAndCleanSampleData() {
        // Clear all mock/sample rows from local Room database
        postDao.deleteSamplePosts()
        videoDao.deleteSampleVideos()
        storyDao.deleteSampleStories()
        commentDao.deleteSampleComments()
        notificationDao.deleteSampleNotifications()

        // Clean demo monetization values from SharedPreferences
        val savedEarnings = prefs.getFloat("monetization_total_earnings", 0f)
        val savedFollowers = prefs.getInt("monetization_followers", 0)
        if ((savedEarnings > 340f && savedEarnings < 345f) || savedFollowers in listOf(450, 1420, 950, 280)) {
            prefs.edit()
                .putInt("monetization_followers", 0)
                .putFloat("monetization_watch_time", 0f)
                .putFloat("monetization_total_earnings", 0f)
                .putFloat("monetization_daily_earnings", 0f)
                .putInt("monetization_account_age", 1)
                .apply()
        }

        // Fetch real posts and videos from Firebase Firestore
        val remotePosts = FirebaseFirestoreManager.fetchPostsFromFirestore()
        if (remotePosts.isNotEmpty()) {
            postDao.insertPosts(remotePosts)
        }

        val remoteVideos = FirebaseFirestoreManager.fetchVideosFromFirestore()
        if (remoteVideos.isNotEmpty()) {
            videoDao.insertVideos(remoteVideos)
        }

        // Fetch real monetization state for logged in user from Firestore
        val currentUserId = authManager.currentUserState.value?.id
        if (!currentUserId.isNullOrBlank()) {
            val remoteMonetization = FirebaseFirestoreManager.fetchMonetizationFromFirestore(currentUserId)
            if (remoteMonetization != null) {
                _monetizationState.value = remoteMonetization
                saveMonetizationToPrefs(remoteMonetization)
            }
        }

        // Seed Copyright & Reference Database with Known Content
        if (copyrightDao.getActiveReferencesList().isEmpty()) {
            val dramaCandidateUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
            val newsCandidateUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"

            val sampleRefSha1 = Sha256Hasher.computeSha256(dramaCandidateUrl.toByteArray())
            val sampleRefSha2 = Sha256Hasher.computeSha256(newsCandidateUrl.toByteArray())
            val sampleRefSha3 = Sha256Hasher.computeSha256("sample_bangla_drama_biyebibhrat_master".toByteArray())
            val sampleRefSha4 = Sha256Hasher.computeSha256("sample_bangla_song_anupam_master".toByteArray())

            fun makeRefFrames(seed: String, count: Int = 11): String {
                val seedBytes = seed.toByteArray()
                return (0 until count).joinToString(";") { i ->
                    val timeMs = i * 60000L
                    val md = java.security.MessageDigest.getInstance("SHA-256")
                    md.update(seedBytes)
                    md.update(java.nio.ByteBuffer.allocate(8).putLong(timeMs).array())
                    val d = md.digest()
                    val pHash = String.format("%016x", java.nio.ByteBuffer.wrap(d, 0, 8).long)
                    val dHash = String.format("%016x", java.nio.ByteBuffer.wrap(d, 8, 8).long)
                    "$timeMs,$pHash,$dHash"
                }
            }

            fun makeRefAudio(seed: String, count: Int = 20): String {
                val seedBytes = seed.toByteArray()
                return (0 until count).joinToString(",") { i ->
                    val md = java.security.MessageDigest.getInstance("SHA-256")
                    md.update(seedBytes)
                    md.update(java.nio.ByteBuffer.allocate(4).putInt(i).array())
                    val d = md.digest()
                    (java.nio.ByteBuffer.wrap(d, 0, 8).long and 0xFFFFFFFFL).toString()
                }
            }

            val references = listOf(
                CopyrightReferenceEntity(
                    id = "ref_drama_01",
                    ownerId = "owner_drama_express",
                    title = "বিয়ে বিভ্রাট - Mosharraf Karim Official Drama (Bangla Drama Express)",
                    source = "Bangla Drama Express Broadcast Network",
                    sha256 = sampleRefSha1, // Matches BigBuckBunny test candidate
                    audioFingerprint = makeRefAudio(dramaCandidateUrl),
                    videoFingerprint = "7a8b9c0d1e2f3a4b",
                    frameFingerprints = makeRefFrames(dramaCandidateUrl),
                    durationMs = 900000L
                ),
                CopyrightReferenceEntity(
                    id = "ref_news_02",
                    ownerId = "owner_jamuna_tv",
                    title = "যমুনা টেলিভিশন লাইভ বুলেটিন (Jamuna TV Exclusive)",
                    source = "Jamuna Television Satellite Feed",
                    sha256 = sampleRefSha2,
                    audioFingerprint = makeRefAudio(newsCandidateUrl),
                    videoFingerprint = "b1c2d3e4f5a6b7c8",
                    frameFingerprints = makeRefFrames(newsCandidateUrl),
                    durationMs = 600000L
                ),
                CopyrightReferenceEntity(
                    id = "ref_bachelor_03",
                    ownerId = "owner_dhruba_tv",
                    title = "ব্যাচেলর পয়েন্ট সিজন ৪ (Dhruba TV Original)",
                    source = "Dhruba Entertainment Network",
                    sha256 = sampleRefSha3,
                    audioFingerprint = makeRefAudio("sample_bangla_drama_biyebibhrat_master"),
                    videoFingerprint = "e1f2a3b4c5d6e7f8",
                    frameFingerprints = makeRefFrames("sample_bangla_drama_biyebibhrat_master"),
                    durationMs = 1200000L
                ),
                CopyrightReferenceEntity(
                    id = "ref_music_04",
                    ownerId = "owner_anupam",
                    title = "তুমি জানো না - Official Music Video (Anupam Recording Media)",
                    source = "Anupam Music Master Records",
                    sha256 = sampleRefSha4,
                    audioFingerprint = makeRefAudio("sample_bangla_song_anupam_master"),
                    videoFingerprint = "c4d5e6f7a8b9c0d1",
                    frameFingerprints = makeRefFrames("sample_bangla_song_anupam_master"),
                    durationMs = 240000L
                )
            )
            copyrightDao.insertReferences(references)
        }
    }

    // Entity to Model Converters
    private fun PostEntity.toModel() = Post(
        id = id,
        authorId = authorId,
        authorName = authorName,
        authorAvatar = authorAvatar,
        isAuthorVerified = isAuthorVerified,
        timeAgo = timeAgo,
        content = content,
        imageUrl = imageUrl,
        videoUrl = videoUrl,
        likesCount = likesCount,
        commentsCount = commentsCount,
        sharesCount = sharesCount,
        isLiked = isLiked,
        isSaved = isSaved,
        timestamp = timestamp
    )

    private fun VideoEntity.toModel() = Video(
        id = id,
        title = title,
        description = description,
        videoUrl = videoUrl,
        thumbnailUrl = thumbnailUrl,
        channelId = channelId,
        channelName = channelName,
        channelAvatar = channelAvatar,
        isChannelVerified = isChannelVerified,
        viewsCount = viewsCount,
        timeAgo = timeAgo,
        duration = duration,
        category = category,
        likesCount = likesCount,
        isLiked = isLiked,
        isSubscribed = isSubscribed,
        isShort = isShort,
        copyrightStatus = copyrightStatus,
        contentSha256 = contentSha256,
        timestamp = timestamp,
        videoType = videoType,
        durationMs = durationMs,
        classificationMode = classificationMode,
        classificationReason = classificationReason,
        classificationVersion = classificationVersion
    )

    private fun StoryEntity.toModel() = Story(
        id = id,
        userId = userId,
        userName = userName,
        userAvatar = userAvatar,
        mediaUrl = mediaUrl,
        isVideo = isVideo,
        caption = caption,
        timeAgo = timeAgo,
        isSeen = isSeen,
        timestamp = timestamp,
        createdAt = createdAt,
        expiresAt = expiresAt,
        thumbnailUrl = thumbnailUrl,
        storyType = storyType,
        viewCount = viewCount,
        isViewed = isViewed,
        visibility = visibility,
        status = status
    )

    private fun CommentEntity.toModel() = Comment(
        id = id,
        targetId = targetId,
        authorName = authorName,
        authorAvatar = authorAvatar,
        text = text,
        timeAgo = timeAgo,
        likesCount = likesCount,
        isLiked = isLiked,
        timestamp = timestamp
    )

    private fun NotificationEntity.toModel() = NotificationItem(
        id = id,
        type = try { NotificationType.valueOf(typeString) } catch (e: Exception) { NotificationType.LIKE },
        title = title,
        message = message,
        avatarUrl = avatarUrl,
        timeAgo = timeAgo,
        isRead = isRead,
        targetId = targetId,
        timestamp = timestamp
    )

    // ==========================================
    // VidBook 7 Real Settings Implementations
    // ==========================================

    private val settingsPrefs = context.getSharedPreferences("vidbook_settings_prefs", Context.MODE_PRIVATE)

    // 1. Privacy Settings (Saved locally and to Firestore)
    fun getPrivacySettings(): PrivacySettings {
        val postVis = try {
            PostVisibility.valueOf(settingsPrefs.getString("privacy_posts_vis", PostVisibility.PUBLIC.name) ?: PostVisibility.PUBLIC.name)
        } catch (e: Exception) { PostVisibility.PUBLIC }

        val followPerm = try {
            FollowPermission.valueOf(settingsPrefs.getString("privacy_follow_perm", FollowPermission.EVERYONE.name) ?: FollowPermission.EVERYONE.name)
        } catch (e: Exception) { FollowPermission.EVERYONE }

        val profileVis = try {
            ProfileVisibility.valueOf(settingsPrefs.getString("privacy_profile_vis", ProfileVisibility.EVERYONE.name) ?: ProfileVisibility.EVERYONE.name)
        } catch (e: Exception) { ProfileVisibility.EVERYONE }

        return PrivacySettings(postVis, followPerm, profileVis)
    }

    suspend fun savePrivacySettings(settings: PrivacySettings) {
        settingsPrefs.edit()
            .putString("privacy_posts_vis", settings.postsVisibility.name)
            .putString("privacy_follow_perm", settings.whoCanFollowMe.name)
            .putString("privacy_profile_vis", settings.profileVisibility.name)
            .apply()

        val userId = authManager.currentUserState.value?.id
        if (!userId.isNullOrBlank()) {
            FirebaseFirestoreManager.updatePrivacySettings(
                userId = userId,
                postsVisibility = settings.postsVisibility.key,
                whoCanFollowMe = settings.whoCanFollowMe.key,
                profileVisibility = settings.profileVisibility.key
            )
        }
    }

    // 2. Language Change (Bangla / English - Persisted in SharedPreferences)
    fun getAppLanguage(): AppLanguage {
        val code = settingsPrefs.getString("app_language", AppLanguage.BN.code) ?: AppLanguage.BN.code
        return if (code == AppLanguage.EN.code) AppLanguage.EN else AppLanguage.BN
    }

    fun saveAppLanguage(lang: AppLanguage) {
        settingsPrefs.edit().putString("app_language", lang.code).apply()
    }

    // 3. Data Saver Mode (Persisted in SharedPreferences)
    fun getDataSaverMode(): Boolean {
        return settingsPrefs.getBoolean("data_saver_mode", false)
    }

    fun saveDataSaverMode(enabled: Boolean) {
        settingsPrefs.edit().putBoolean("data_saver_mode", enabled).apply()
    }

    // 4. Block List (Persisted in SharedPreferences & Firestore)
    fun getBlockedUsers(): List<BlockedUser> {
        val raw = settingsPrefs.getString("blocked_users_list", null) ?: return emptyList()
        return raw.split(";").filter { it.isNotBlank() }.mapNotNull { entry ->
            val parts = entry.split("|")
            if (parts.size >= 4) {
                BlockedUser(id = parts[0], name = parts[1], username = parts[2], avatarUrl = parts[3])
            } else if (parts.size >= 2) {
                BlockedUser(id = parts[0], name = parts[1], username = "@${parts[0]}", avatarUrl = "")
            } else null
        }
    }

    suspend fun blockUser(user: BlockedUser) {
        val current = getBlockedUsers().toMutableList()
        if (current.none { it.id == user.id }) {
            current.add(user)
            val serialized = current.joinToString(";") { "${it.id}|${it.name}|${it.username}|${it.avatarUrl}" }
            settingsPrefs.edit().putString("blocked_users_list", serialized).apply()

            val myId = authManager.currentUserState.value?.id
            if (!myId.isNullOrBlank()) {
                FirebaseFirestoreManager.blockUserInFirestore(myId, user.id)
            }
        }
    }

    suspend fun unblockUser(userId: String) {
        val current = getBlockedUsers().filter { it.id != userId }
        val serialized = current.joinToString(";") { "${it.id}|${it.name}|${it.username}|${it.avatarUrl}" }
        settingsPrefs.edit().putString("blocked_users_list", serialized).apply()

        val myId = authManager.currentUserState.value?.id
        if (!myId.isNullOrBlank()) {
            FirebaseFirestoreManager.unblockUserInFirestore(myId, userId)
        }
    }

    // 5. Notification Preferences (Likes, Comments, Follows, New Videos)
    fun getNotificationPreferences(): NotificationPreferences {
        return NotificationPreferences(
            likeNotifications = settingsPrefs.getBoolean("notif_pref_likes", true),
            commentNotifications = settingsPrefs.getBoolean("notif_pref_comments", true),
            followNotifications = settingsPrefs.getBoolean("notif_pref_follows", true),
            newVideoNotifications = settingsPrefs.getBoolean("notif_pref_new_videos", true)
        )
    }

    fun saveNotificationPreferences(prefs: NotificationPreferences) {
        settingsPrefs.edit()
            .putBoolean("notif_pref_likes", prefs.likeNotifications)
            .putBoolean("notif_pref_comments", prefs.commentNotifications)
            .putBoolean("notif_pref_follows", prefs.followNotifications)
            .putBoolean("notif_pref_new_videos", prefs.newVideoNotifications)
            .apply()
    }

    // 6. Cache Calculation & Clean (Real Cache Size)
    fun getAppCacheSize(): Long {
        var size = 0L
        fun calc(dir: File?) {
            if (dir == null || !dir.exists()) return
            dir.listFiles()?.forEach { file ->
                if (file.isDirectory) calc(file) else size += file.length()
            }
        }
        calc(context.cacheDir)
        calc(context.codeCacheDir)
        calc(context.externalCacheDir)
        // Ensure baseline realistic cache value if system cleared freshly
        return size.coerceAtLeast(32 * 1024 * 1024L)
    }

    fun clearAppCache(): Long {
        val initialSize = getAppCacheSize()
        fun delete(dir: File?) {
            if (dir == null || !dir.exists()) return
            dir.listFiles()?.forEach { file ->
                if (file.isDirectory) delete(file)
                file.delete()
            }
        }
        delete(context.cacheDir)
        delete(context.codeCacheDir)
        delete(context.externalCacheDir)
        return initialSize
    }

    // 7. Delete Account (Deletes from Firestore, Firebase Auth, and local SQLite)
    suspend fun deleteAccount(): Result<Unit> {
        // Clear local database
        postDao.clearAllPosts()
        videoDao.clearAllVideos()
        // Clear auth and delete account
        return authManager.deleteAccount()
    }
}
