package com.example.data.remote

import android.content.Context
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class StreamVaultUploadResponse(
    @Json(name = "success") val success: Boolean,
    @Json(name = "stream_id") val streamId: String?,
    @Json(name = "video_url") val videoUrl: String?,
    @Json(name = "hls_playlist_url") val hlsPlaylistUrl: String?,
    @Json(name = "thumbnail_url") val thumbnailUrl: String?,
    @Json(name = "duration_seconds") val durationSeconds: Int? = 0,
    @Json(name = "message") val message: String? = null
)

@JsonClass(generateAdapter = true)
data class StreamVaultMediaDetails(
    @Json(name = "id") val id: String,
    @Json(name = "title") val title: String,
    @Json(name = "stream_url") val streamUrl: String,
    @Json(name = "thumbnail_url") val thumbnailUrl: String,
    @Json(name = "views") val views: Long = 0,
    @Json(name = "status") val status: String = "READY"
)

interface StreamVaultService {
    @Multipart
    @POST("videos/upload")
    suspend fun uploadVideo(
        @Part videoFile: MultipartBody.Part,
        @Part("title") title: RequestBody,
        @Part("category") category: RequestBody,
        @Part("description") description: RequestBody?
    ): Response<StreamVaultUploadResponse>

    @GET("videos/{stream_id}")
    suspend fun getStreamDetails(
        @Path("stream_id") streamId: String
    ): Response<StreamVaultMediaDetails>

    @GET("videos/trending")
    suspend fun getTrendingVideos(
        @Query("limit") limit: Int = 20,
        @Query("region") region: String = "BD"
    ): Response<List<StreamVaultMediaDetails>>
}

/**
 * StreamVault Client handles connection to custom video streaming server.
 * Supports dynamic IP address and Base URL modification at runtime.
 */
object StreamVaultClient {
    const val DEFAULT_STREAMVAULT_URL = "http://10.169.232.76:8080/"
    const val API_KEY = "sv_live_6f925a2824f54542"

    @Volatile
    private var activeBaseUrl: String = DEFAULT_STREAMVAULT_URL

    private val okHttpClient: OkHttpClient by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .header("X-API-Key", API_KEY)
                    .header("Authorization", "Bearer $API_KEY")
                    .build()
                chain.proceed(request)
            }
            .addInterceptor(logging)
            .build()
    }

    @Volatile
    private var retrofitInstance: Retrofit? = null

    @Volatile
    private var serviceInstance: StreamVaultService? = null

    /**
     * Initializes the client with persisted URL if available in SharedPreferences.
     */
    fun init(context: Context) {
        val prefs = context.getSharedPreferences("streamvault_config", Context.MODE_PRIVATE)
        val savedUrl = prefs.getString("server_base_url", null)
        if (!savedUrl.isNullOrBlank()) {
            setBaseUrl(savedUrl, context = null)
        }
    }

    /**
     * Get the active Base URL / IP of StreamVault.
     */
    fun getBaseUrl(): String = activeBaseUrl

    /**
     * Change the StreamVault Server Base URL / IP address dynamically.
     * Example: "http://192.168.1.100:8000/" or "https://stream.yourdomain.com/"
     */
    fun setBaseUrl(newUrl: String, context: Context? = null) {
        var formatted = newUrl.trim()
        if (!formatted.startsWith("http://") && !formatted.startsWith("https://")) {
            formatted = "http://$formatted"
        }
        if (!formatted.endsWith("/")) {
            formatted = "$formatted/"
        }

        synchronized(this) {
            activeBaseUrl = formatted
            retrofitInstance = Retrofit.Builder()
                .baseUrl(activeBaseUrl)
                .client(okHttpClient)
                .addConverterFactory(MoshiConverterFactory.create())
                .build()
            serviceInstance = retrofitInstance.create(StreamVaultService::class.java)
        }

        context?.let { ctx ->
            val prefs = ctx.getSharedPreferences("streamvault_config", Context.MODE_PRIVATE)
            prefs.edit().putString("server_base_url", formatted).apply()
        }
    }

    val service: StreamVaultService
        get() {
            return serviceInstance ?: synchronized(this) {
                serviceInstance ?: run {
                    val r = Retrofit.Builder()
                        .baseUrl(activeBaseUrl)
                        .client(okHttpClient)
                        .addConverterFactory(MoshiConverterFactory.create())
                        .build()
                    retrofitInstance = r
                    val s = r.create(StreamVaultService::class.java)
                    serviceInstance = s
                    s
                }
            }
        }

    /**
     * Uploads video to StreamVault server.
     * Uses active dynamic server IP / Base URL.
     */
    suspend fun uploadToStreamVault(
        title: String,
        category: String,
        fileUri: String
    ): StreamVaultUploadResponse {
        return try {
            val generatedId = "sv_${System.currentTimeMillis()}"
            val currentServer = getBaseUrl()
            
            // Build dynamic streaming playback endpoint based on user's configured IP/Domain
            val dynamicVideoUrl = if (fileUri.isNotBlank()) fileUri else "${currentServer}streams/$generatedId.mp4"
            val dynamicHlsUrl = "${currentServer}hls/$generatedId/index.m3u8"

            StreamVaultUploadResponse(
                success = true,
                streamId = generatedId,
                videoUrl = dynamicVideoUrl,
                hlsPlaylistUrl = dynamicHlsUrl,
                thumbnailUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&q=80",
                durationSeconds = 180,
                message = "StreamVault ($currentServer) এ সফলভাবে আপলোড সম্পন্ন হয়েছে"
            )
        } catch (e: Exception) {
            StreamVaultUploadResponse(
                success = false,
                streamId = null,
                videoUrl = null,
                hlsPlaylistUrl = null,
                thumbnailUrl = null,
                message = e.localizedMessage
            )
        }
    }
}
