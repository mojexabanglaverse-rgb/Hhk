package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.copyright.data.ContentMatchEntity
import com.example.copyright.data.CopyrightDao
import com.example.copyright.data.CopyrightModerationActionEntity
import com.example.copyright.data.CopyrightReferenceEntity
import com.example.copyright.data.CopyrightScanLogEntity

@Database(
    entities = [
        PostEntity::class,
        VideoEntity::class,
        StoryEntity::class,
        StoryViewerEntity::class,
        StoryReactionEntity::class,
        StoryReplyEntity::class,
        StoryHighlightEntity::class,
        StoryPrivacyEntity::class,
        VideoClassificationEntity::class,
        UserSettingsEntity::class,
        CommentEntity::class,
        NotificationEntity::class,
        CopyrightReferenceEntity::class,
        ContentMatchEntity::class,
        CopyrightScanLogEntity::class,
        CopyrightModerationActionEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class VidBookDatabase : RoomDatabase() {
    abstract fun postDao(): PostDao
    abstract fun videoDao(): VideoDao
    abstract fun storyDao(): StoryDao
    abstract fun storyInteractionDao(): StoryInteractionDao
    abstract fun videoClassificationDao(): VideoClassificationDao
    abstract fun userSettingsDao(): UserSettingsDao
    abstract fun commentDao(): CommentDao
    abstract fun notificationDao(): NotificationDao
    abstract fun copyrightDao(): CopyrightDao

    companion object {
        @Volatile
        private var INSTANCE: VidBookDatabase? = null

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Idempotent migration: add each column only when it is actually missing.
                fun hasColumn(table: String, column: String): Boolean {
                    db.query("PRAGMA table_info(`$table`)").use { cursor ->
                        val nameIndex = cursor.getColumnIndex("name")
                        while (cursor.moveToNext()) {
                            if (nameIndex >= 0 && cursor.getString(nameIndex) == column) return true
                        }
                    }
                    return false
                }

                fun addColumn(table: String, column: String, definition: String) {
                    if (!hasColumn(table, column)) {
                        db.execSQL("ALTER TABLE `$table` ADD COLUMN `$column` $definition")
                    }
                }

                addColumn("videos", "videoType", "TEXT NOT NULL DEFAULT 'LONG'")
                addColumn("videos", "durationMs", "INTEGER NOT NULL DEFAULT 0")
                addColumn("videos", "classificationMode", "TEXT NOT NULL DEFAULT 'AUTO'")
                addColumn("videos", "classificationReason", "TEXT NOT NULL DEFAULT 'DURATION'")
                addColumn("videos", "classificationVersion", "TEXT NOT NULL DEFAULT 'v1'")

                addColumn("stories", "thumbnailUrl", "TEXT NOT NULL DEFAULT ''")
                addColumn("stories", "storyType", "TEXT NOT NULL DEFAULT 'IMAGE'")
                addColumn("stories", "createdAt", "INTEGER NOT NULL DEFAULT 0")
                addColumn("stories", "viewCount", "INTEGER NOT NULL DEFAULT 0")
                addColumn("stories", "isViewed", "INTEGER NOT NULL DEFAULT 0")
                addColumn("stories", "visibility", "TEXT NOT NULL DEFAULT 'PUBLIC'")
                addColumn("stories", "status", "TEXT NOT NULL DEFAULT 'ACTIVE'")

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS story_viewers (
                        storyId TEXT NOT NULL, viewerId TEXT NOT NULL, viewerName TEXT NOT NULL,
                        viewerAvatar TEXT NOT NULL, viewedAt INTEGER NOT NULL,
                        PRIMARY KEY(storyId, viewerId)
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS story_reactions (
                        storyId TEXT NOT NULL, userId TEXT NOT NULL, userName TEXT NOT NULL,
                        userAvatar TEXT NOT NULL, reactionEmoji TEXT NOT NULL, timestamp INTEGER NOT NULL,
                        PRIMARY KEY(storyId, userId)
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS story_replies (
                        id TEXT NOT NULL PRIMARY KEY, storyId TEXT NOT NULL, userId TEXT NOT NULL,
                        userName TEXT NOT NULL, userAvatar TEXT NOT NULL, replyText TEXT NOT NULL, timestamp INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS story_highlights (
                        id TEXT NOT NULL PRIMARY KEY, userId TEXT NOT NULL, title TEXT NOT NULL,
                        coverUrl TEXT NOT NULL, storyIdsJson TEXT NOT NULL, createdAt INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS story_privacy (
                        userId TEXT NOT NULL PRIMARY KEY, defaultVisibility TEXT NOT NULL DEFAULT 'PUBLIC',
                        isArchiveEnabled INTEGER NOT NULL DEFAULT 1, allowReplies INTEGER NOT NULL DEFAULT 1,
                        allowReactions INTEGER NOT NULL DEFAULT 1, allowSharing INTEGER NOT NULL DEFAULT 1,
                        closeFriendsIdsJson TEXT NOT NULL DEFAULT '[]', hideStoryFromIdsJson TEXT NOT NULL DEFAULT '[]'
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS video_classifications (
                        videoId TEXT NOT NULL PRIMARY KEY, videoType TEXT NOT NULL, durationMs INTEGER NOT NULL,
                        classificationMode TEXT NOT NULL, classificationReason TEXT NOT NULL,
                        classificationVersion TEXT NOT NULL DEFAULT 'v1', timestamp INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS user_settings (
                        userId TEXT NOT NULL PRIMARY KEY, autoplay INTEGER NOT NULL DEFAULT 1,
                        wifiOnlyUpload INTEGER NOT NULL DEFAULT 0, uploadOverMobileData INTEGER NOT NULL DEFAULT 1,
                        defaultVideoQuality TEXT NOT NULL DEFAULT 'AUTO', defaultUploadType TEXT NOT NULL DEFAULT 'AUTO',
                        autoDetectShortLong INTEGER NOT NULL DEFAULT 1, isStoryArchiveEnabled INTEGER NOT NULL DEFAULT 1,
                        allowStoryReplies INTEGER NOT NULL DEFAULT 1, profileVisibility TEXT NOT NULL DEFAULT 'EVERYONE',
                        whoCanFollowMe TEXT NOT NULL DEFAULT 'EVERYONE', whoCanMessageMe TEXT NOT NULL DEFAULT 'EVERYONE',
                        whoCanComment TEXT NOT NULL DEFAULT 'EVERYONE', activityStatus INTEGER NOT NULL DEFAULT 1,
                        highContrast INTEGER NOT NULL DEFAULT 0, reduceMotion INTEGER NOT NULL DEFAULT 0,
                        textSizeScale REAL NOT NULL DEFAULT 1.0, downloadQuality TEXT NOT NULL DEFAULT 'HD',
                        autoDownload INTEGER NOT NULL DEFAULT 0, cacheSizeBytes INTEGER NOT NULL DEFAULT 0,
                        searchHistoryJson TEXT NOT NULL DEFAULT '[]', watchHistoryJson TEXT NOT NULL DEFAULT '[]',
                        notificationsJson TEXT NOT NULL DEFAULT '{}'
                    )
                """.trimIndent())

                db.execSQL("CREATE INDEX IF NOT EXISTS index_stories_userId ON stories(userId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_stories_status ON stories(status)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_stories_expiresAt ON stories(expiresAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_videos_isShort ON videos(isShort)")
            }
        }

        fun getDatabase(context: Context): VidBookDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VidBookDatabase::class.java,
                    "vidbook_database"
                )
                .addMigrations(MIGRATION_2_3)
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
