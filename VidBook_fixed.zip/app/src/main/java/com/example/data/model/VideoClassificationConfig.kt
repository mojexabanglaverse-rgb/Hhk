package com.example.data.model

/**
 * Central configuration and constants for video classification.
 */
object VideoClassificationConfig {
    const val SHORT_VIDEO_MAX_DURATION_MS: Long = 60_000L // 60 seconds
    const val SHORT_VIDEO_MAX_DURATION_SECONDS: Int = 60
    const val DEFAULT_CLASSIFICATION_VERSION: String = "v1"

    fun isShortVideo(durationMs: Long): Boolean {
        return durationMs in 1..SHORT_VIDEO_MAX_DURATION_MS
    }

    fun formatDuration(durationMs: Long): String {
        val totalSecs = (durationMs / 1000).coerceAtLeast(0)
        val mins = totalSecs / 60
        val secs = totalSecs % 60
        return String.format("%02d:%02d", mins, secs)
    }
}

enum class VideoType(val displayNameBn: String, val displayNameEn: String) {
    SHORT("শর্ট ভিডিও", "Short Video"),
    LONG("লং ভিডিও", "Long Video"),
    AUTO("অটো ডিটেক্ট", "Auto Detect")
}

enum class ClassificationMode {
    AUTO,
    MANUAL
}

enum class ClassificationReason {
    DURATION,
    USER_SELECTED,
    ADMIN_OVERRIDE
}
