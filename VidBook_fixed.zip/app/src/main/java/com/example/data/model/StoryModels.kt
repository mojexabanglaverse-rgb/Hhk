package com.example.data.model

enum class StoryType {
    IMAGE,
    VIDEO,
    TEXT
}

enum class StoryStatus {
    ACTIVE,
    EXPIRED,
    DELETED,
    ARCHIVED
}

enum class StoryVisibility(val titleBn: String, val titleEn: String) {
    PUBLIC("পাবলিক", "Public"),
    FOLLOWERS("ফলোয়ার্স", "Followers"),
    FRIENDS("বন্ধুরা", "Friends"),
    CUSTOM("কাস্টম", "Custom"),
    ONLY_ME("শুধু আমি", "Only Me"),
    CLOSE_FRIENDS("ক্লোজ ফ্রেন্ডস", "Close Friends")
}

data class StoryViewer(
    val storyId: String,
    val viewerId: String,
    val viewerName: String,
    val viewerAvatar: String,
    val viewedAt: Long = System.currentTimeMillis()
)

data class StoryReaction(
    val storyId: String,
    val userId: String,
    val userName: String,
    val userAvatar: String,
    val reactionEmoji: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class StoryReply(
    val id: String,
    val storyId: String,
    val userId: String,
    val userName: String,
    val userAvatar: String,
    val replyText: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class StoryHighlight(
    val id: String,
    val userId: String,
    val title: String,
    val coverUrl: String,
    val storyIds: List<String>,
    val createdAt: Long = System.currentTimeMillis()
)

data class StoryPrivacySettings(
    val userId: String,
    val defaultVisibility: StoryVisibility = StoryVisibility.PUBLIC,
    val isArchiveEnabled: Boolean = true,
    val allowReplies: Boolean = true,
    val allowReactions: Boolean = true,
    val allowSharing: Boolean = true,
    val closeFriendsIds: List<String> = emptyList(),
    val hideStoryFromIds: List<String> = emptyList()
)
